## 1.0.0-rc.1 – Erster Release Candidate
- Release-Paket aus dem letzten Beta-Stand vorbereitet; Versionskennung auf `1.0.0-rc.1` gesetzt.
- Freelancer-Testrolle aus der Admin-Oberfläche entfernt und serverseitig deaktiviert; alte Datenbankwerte werden nicht als Zugriff verwendet.
- Polizei-Testmodus bleibt verfügbar, startet standardmäßig ausgeschaltet und ist als Admin-Selbsttest vorgesehen.
- Admin-Selbstausstellung wurde vom Neueinstellungs-/Jobwechselpfad getrennt; der QBCore-Job des Admins soll unverändert bleiben.
- Persönliche Testfotos und nicht zum Resource-Produkt gehörende Blender-Modell-Dateien aus dem öffentlichen Paket entfernt.
- Destruktive Bereinigung fremder Organisations-PC-Datensätze beim Resource-Start entfernt.
- README, Kurzinstallation und Update-/Datensicherheitsdokumentation für Neuinstallation, Items, ACE, Targets, Standorte und Updateablauf überarbeitet.
- Fotostationen und Personalausweis-Abholstationen ausdrücklich als frei und unabhängig vom Polizeisystem platzierbare Standorte dokumentiert.
- Keine neue SQL-Migration vorgesehen.

# Änderungsprotokoll

## 1.4.7-beta.6 – Berechtigungsanzeigen und Release-Dokumentation
- Die Polizeimitglieder-Ansicht unterscheidet serverseitig zwischen fehlender Berechtigung und einer tatsächlich leeren Mitgliederliste.
- Ohne Berechtigung erscheint: „Du hast keine Berechtigung, Polizeimitglieder anzusehen. Bitte wende dich an deinen Vorgesetzten.“
- Die Schaltfläche „Organisationsverwaltung“ im Polizei-Tablet wird nur Serveradmins angezeigt; die serverseitige Adminprüfung bleibt bestehen.
- README_DE.md und INSTALLATION_QBCORE_DE.txt als vollständige Installations-, Konfigurations-, Update- und Testanleitung überarbeitet, inklusive server.cfg-Beispiel und QBCore-Iteminstallation.
- Keine Datenbankmigration und keine Änderung an bestehenden Spieler-/Dokumentdaten.

## 1.4.7-beta.5 – Spielerbefehle-Kachel
- Die Spielerbefehle-Kachel zeigt nur noch `/uiddocuments` und `/uidzeigen`.
- `/uidtablet`, `/uidgiveorg` und `/uidwaffenschein` wurden nur aus der Kachel entfernt; die Commands und ihre Funktionen bleiben registriert.
- Keine Änderung an Testmodus, Berechtigungsprüfung, SetJob-Zeitpunkt oder Datenbankstruktur.

## 1.4.7-beta.4 – Befehlsübersicht, Rechteprüfung und Neueinstellung
- Spielerbefehle und Polizei-/Ausstellerbefehle in der Systemverwaltung klar getrennt; vorhandene Kachelstruktur beibehalten.
- Entwickler- und Testbefehle-Kachel entfernt; `/uidresetmydocs` in die Adminbefehle verschoben.
- `/uidresetmydocs` serverseitig auf Serveradministratoren beschränkt.
- Den nicht mehr benötigten Befehl `/uidfototest` entfernt.
- Gespeicherte Rangrechte haben auch bei aktivem temporärem Polizei-Testmodus Vorrang; ohne gespeicherte Rangrechte bleibt der Testmodus für Tests offen.
- Bei Neueinstellungen wird `SetJob` weiterhin direkt beim Ausstellen des Dienstausweises ausgeführt, nicht erst bei der physischen Übergabe.
- Neueinstellungen dürfen nur einen niedrigeren QBCore-Rang als der Einsteller vergeben. Rangdaten werden dynamisch aus `QBCore.Shared.Jobs` gelesen.
- Bei bestehenden Polizeimitgliedern wird der Dienstausweisrang aus dem tatsächlichen QBCore-Jobrang übernommen, statt einen abweichenden Rang auf dem Ausweis zu speichern.



## 1.4.7-beta.3 – Admin-Testausstellung und Tablet-Aufräumen
- Admin-Tablet: doppelte Befehlsübersicht aus der Navigation entfernt; alle drei Befehlsgruppen bleiben als eigene Kacheln unter Systemeinstellungen verfügbar.
- Systemeinstellungen: Waffenschein-Gebühr, Polizei-Testmodus und Freelancer-Testrolle als jeweils eigene Kacheln mit separaten Ansichten.
- Polizei-Testmodus: Serveradmins dürfen ausschließlich für den eigenen Charakter Dokumente testen; serverseitige ACE/QBCore-Adminprüfung bei Öffnen, Suche und Ausstellung. Der QBCore-Job wird bei dieser Selbstausstellung nicht verändert.
- Dokumentenmappe: maximal zwei Karten nebeneinander, auf schmalen Bildschirmen eine Spalte; Vorzeigen-Schaltfläche setzt sich nach Anfrage zurück.
- Standortlisten: interne IDs bleiben für Löschaktionen erhalten, werden aber nicht mehr als sichtbarer Titel mit # angezeigt.
- Bestehende Datenbankdaten werden nicht zurückgesetzt.


## 1.4.7-beta.2 – Optimierung und Admin-Tablet
- Systemverwaltung: Spielerbefehle, Adminbefehle und Entwickler-/Testbefehle als drei getrennte Kacheln mit eigenen Übersichtsseiten.
- Stellvertretung und Bekanntmachungen stehen im oberen Übersichtsbereich nebeneinander; auf schmalen Displays werden sie untereinander dargestellt.
- Mitarbeiterfotos werden serverseitig in einem begrenzten Cache gehalten; beim Speichern eines neuen Fotos wird der jeweilige Cache-Eintrag invalidiert.
- Polizeimitarbeiter-Abfragen filtern die QBCore-Jobdaten bereits in SQL, statt alle Spielerdatensätze an Lua zu übertragen. Eintrittsdaten werden weiterhin gesammelt in einer Abfrage geladen.
- F10 bleibt die Standardbelegung für das Admin-Tablet und ist über die FiveM-Tastatureinstellungen frei änderbar. Der Server prüft die Adminberechtigung bei jedem Öffnungsversuch.
- Keine Datenbanktabellen oder bestehenden Dokument-/Spielerdaten werden durch diese Änderungen gelöscht.

## 1.4.7-beta.1 – Vorherige Beta-Korrekturen
- Standortanzeige bei Polizeimitgliedern entfernt.
- Bekanntmachungen in der Polizeiübersicht hervorgehoben.
- Kartendesign-Vorschau serverseitig auf Serveradmins beschränkt.
- Admin-Tablet-Tastenzuordnung und Befehlsübersicht ergänzt.

# Änderungsprotokoll

## 1.4.7-beta.1 (Beta)
- Live-Standortanzeige von Polizeimitgliedern inklusive Rechteoption, NUI-Karte und Server-Event entfernt.
- Bekanntmachungen-Kachel direkt neben Stellvertretung in der Polizeitablet-Übersicht platziert.
- `/uidphotostatus` serverseitig gegen normale Spieler und direkte Event-Aufrufe abgesichert.
- Eintrittsdaten für Polizeimitglieder in gebündelten Datenbankabfragen geladen (N+1-Abfragen entfernt).
- Bestehende Tabellen und gespeicherte Spieler-/Dokument-/Standortdaten werden nicht gelöscht.

## Version 1.4.6
- Polizeimitglieder-Standortfenster auf interaktive GTA-V-Karte umgestellt.
- Kartenansicht mit Zoomstufen, Verschieben, Zentrieren und Spieler-Marker.
- Kartenkacheln werden vom NUI-Client direkt vom externen, inoffiziellen Projekt VIRUXE GTA V Map Tiles geladen; kein serverabhängiger Koordinatenumbau erforderlich.
- Bestehende serverseitige Standort- und Rechteprüfung unverändert gelassen.

## Version 1.4.4
- Polizeimitglieder: Online-Standort kann aus der Mitgliederkarte in einem separaten Kartenfenster abgefragt werden.
- Standortdaten werden ausschließlich serverseitig über OneSync gelesen; Ziel muss aktuell zur konfigurierten Polizei-Organisation gehören.
- Neue, separat vergebbare Berechtigung `view_member_locations` in der Admin-Rechteverwaltung; jede Standortabfrage wird serverseitig erneut geprüft und begrenzt.
- Der Eintrag „Organisationsverwaltung“ unten links im Polizeitablet öffnet nun das Admin-Tablet. Der Server lässt den Aufruf ausschließlich für Serveradministratoren zu.
- Bestehende Tabellen und Spielerdaten bleiben unverändert; keine Datenbankmigration erforderlich.
- Hinweis: Die eingebaute Kartenfläche ist eine schematische Ingame-Übersicht mit Koordinatenmarker, keine native GTA-Pausenkarte.

# Changelog

## Version 1.4.3

- Korrektur der Anzeige von Datum und Uhrzeit: NUI liest den serverseitigen Zeitwert auch aus dem übergebenen Kontostand-/Tablet-Datenobjekt.
- Serverseitige Berechtigungsablehnungen werden zusätzlich als sichtbarer Hinweis im Organisations-Tablet angezeigt.
- Beschriftung der bestehenden Rangzuweisungsaktion auf „Rekrutieren“ vereinheitlicht; keine Änderung am Ablauf.

## Version 1.4.2
- Rechteverwaltung: „Stellvertretung“ ist jetzt eine eigene auswählbare Rolle mit separat speicherbaren Berechtigungsschaltern. Die Rechte werden serverseitig anhand der eingetragenen Stellvertretung geprüft.
- Polizeitablet-Kopfzeile überarbeitet: links stehen nur noch „Organisationsverwaltung“ und „Polizei Organisations System“; die Aussteller-/Zeitzeile wurde entfernt.
- Rechts unter „SYSTEM ONLINE“ wird Datum und Uhrzeit aus der Serverzeit angezeigt.
- `/uidzeigen dienstausweis` zeigt jetzt den tatsächlich ausgestellten Dienstausweis aus der Datenbank und damit den gespeicherten bzw. synchronisierten QBCore-Rang. `/uidpreview` bleibt die statische Designvorschau.
- Rang-Synchronisierung bevorzugt nun die offizielle Grade-Bezeichnung aus `QBCore.Shared.Jobs` und verwendet den PlayerData-Text nur als Rückfall.
- Keine Datenbankmigration und keine Löschung vorhandener Daten erforderlich; die Stellvertretungsrechte verwenden den reservierten Sonderwert `grade_level = -1` in der bestehenden Rechte-Tabelle.

## Version 1.4.1
- Fehlerkorrektur im Einstellungsablauf: Bei Spielern ohne Polizeijob wird die Neueinstellung automatisch erkannt, sobald der Aussteller die Einstellungsberechtigung besitzt.
- Das zusätzliche manuelle Häkchen „Mitarbeiter einstellen“ blockiert die Schaltfläche „Ausweis ausstellen“ nicht mehr.
- Serverseitig wird weiterhin zwingend geprüft, ob der Aussteller zur Neueinstellung berechtigt ist; unberechtigte Ausstellungen werden abgewiesen.
- Foto, gültiger und abgeholter Personalausweis, dessen Bestätigung sowie die Auswahl eines gültigen QBCore-Rangs bleiben Pflicht.
- `SetJob()` wird für den Bewerber weiterhin direkt bei der Ausstellung ausgeführt.

## Version 1.4.0
- Neue Admin-Einstellung „Freelancer-Testrolle“: Spieler mit `unemployed` oder `freelancer` können nach expliziter Admin-Freigabe im aktivierten Polizei-Testmodus als Test-Aussteller arbeiten.
- Freelancer-Testzugriff ist serverseitig und dauerhaft in `ui_system_settings` gespeichert; die Freigabe ist standardmäßig aus und funktioniert nur zusammen mit dem Polizei-Testmodus.
- Bei einer Neueinstellung wird `SetJob()` bereits beim Klick auf „Ausweis ausstellen“ für die eingegebene Server-ID und den ausgewählten QBCore-Rang ausgeführt und anschließend überprüft.
- Bei fehlgeschlagener Jobzuweisung wird der vorherige Job nach Möglichkeit wiederhergestellt und der Ausweisdatensatz als ungültig markiert.
- Die spätere Abholung und persönliche Übergabe betrifft nur noch den Ausweisgegenstand; Job und Rang werden dabei nicht erneut gesetzt.
- Bestehende Mitarbeiterverwaltung bleibt auf Spieler mit dem konfigurierten Polizeijob beschränkt.


## Version 1.3.6
- Dienstausweis-Rang wird serverseitig mit dem tatsächlichen QBCore-Jobrang synchronisiert – bei `/setjob`, Rekrutierung und Beförderung.
- Die Dokumentanzeige aktualisiert den gespeicherten Rang vor dem Öffnen des Dienstausweises.
- Admin-Tablet: neuer Bereich „Systemeinstellungen“ zum dauerhaften Ändern der Waffenschein-Gebühr.
- Die neue Gebühr wird sofort für die Ausstellung im Polizeisystem verwendet; Polizeimitglieder der konfigurierten Organisation bleiben kostenlos.
- Herabstufen-Schaltfläche und zugehörige Aktion entfernt.
- Testmodus bleibt für die laufenden Tests geöffnet.

## Version 1.3.5 – Waffenschein-Gebühr, Personalausweisprüfung und Rangzuordnung
- Waffenschein-Ausstellung über das Polizeitablet: Gebühr für Nichtmitglieder auf 6.500 $ erhöht. Die Zahlung wird weiterhin nicht automatisch abgezogen; der Aussteller bestätigt die persönliche Geldübergabe per Häkchen.
- Polizeimitglieder der in `config/config.lua` konfigurierten Organisationsjob-Bezeichnung erhalten den Waffenschein weiterhin kostenlos. Der Jobname muss nicht mehr fest `police` sein; weitere kostenlose Jobs können optional über `WeaponPermitFreeJobs` ergänzt werden.
- Bei Dienstausweis UND Waffenschein ist die Bestätigung erforderlich, dass ein gültiger, bereits abgeholter Personalausweis tatsächlich vorgezeigt wurde. Serverseitig geprüft, nicht nur über die Oberfläche.
- Dienstausweise speichern jetzt zusätzlich die tatsächliche QBCore-Grade-Stufe. Bei der persönlichen Übergabe wird genau dieser gespeicherte Rang gesetzt; die sichtbare Rangbezeichnung bleibt erhalten. Bestehende Dokumente werden durch die additive `rank_level`-Migration nicht gelöscht.
- Der Waffenschein-Ausstellungsdatensatz wird dem tatsächlichen Aussteller zugeordnet, damit dieser ihn an der Abholstation abholen kann.
- Testmodus bleibt vollständig offen; Admin-Tablet bleibt Admin-only.

## Version 1.3.4 – offene Spielersuche und Abholung im Testmodus
- Mitarbeitersuche im temporären Polizeitestmodus: Spieler mit jedem Job (auch `unemployed`) können anhand ihrer Server-ID gefunden und für Dokumentausstellungen ausgewählt werden.
- Dienstausweis- und Waffenschein-Ausgabe an der Polizei-Abholstation bleibt im Testmodus auch ohne Polizeijob, Rang oder Organisationszugehörigkeit möglich. Die Personalausweis-Abholung bleibt weiterhin jobunabhängig.
- Personalaktionen (Rekrutieren, Befördern, Herabstufen und Kündigen) werden bei gefundenen Nicht-Polizeimitgliedern weiterhin nicht angeboten.
- Außerhalb des Testmodus bleiben Mitarbeitersuche, Polizeiausgabe und Personalverwaltung geschützt.
- Admin-Tablet bleibt Admin-only; keine SQL-Migration und keine Löschung vorhandener Daten.

## Version 1.3.3 – vollständiger Polizei-Testzugang
- Korrektur des Testmodus: Das Polizeitablet und die Polizeifunktionen können jetzt auch ohne Polizeijob, Rang oder Organisationszugehörigkeit geöffnet und getestet werden.
- Serverseitige Zugangsprüfung für den temporären Testmodus angepasst; die Freigabe ist nicht nur eine Client-/UI-Freischaltung.
- Polizeiliche Ausgabestellen akzeptieren im Testmodus ebenfalls Spieler ohne Polizeijob.
- Allgemeine Personensuche und Personenprotokollsuche bleiben für alle Online-Spieler per Server-ID nutzbar.
- Mitarbeitersuche bleibt strikt auf Spieler mit dem Job `police` begrenzt; die normale Personalverwaltung verändert keine Zivilisten oder Spieler anderer Jobs.
- Selbst-Stellvertretung kann im Testmodus auch mit einer eigenen Server-ID geprüft werden.
- Admin-Tablet bleibt unverändert Admin-only.
- Keine SQL-Migration und keine Löschung vorhandener Daten erforderlich.
- **Wichtig:** Vor einem öffentlichen Release `PoliceTestMode`, `AllowTabletAccessWithoutJobForTesting` und die `AllowSelf*ForTesting`-Schalter deaktivieren.


## Version 1.3.1
- Dienstausweis: Die Organisationsbezeichnung wird lesbar als „Polizei“ angezeigt und direkt daneben steht immer die bei der Ausstellung gewählte Rangbezeichnung, z. B. „POLIZEI · OFFICER“ oder „POLIZEI · CHIEF“.
- Mitarbeiterverwaltung: Die Spielersuche blockiert keine Zivilisten oder Spieler mit anderem Job mehr. Dadurch können sie gefunden und anschließend regulär rekrutiert werden; die eigentliche Jobvergabe bleibt serverseitig berechtigt und geprüft.
- Mitarbeiterverwaltung: Neue Aktion „Herabstufen“ mit eigener Serverprüfung. Es sind ausschließlich niedrigere QBCore-Ränge zulässig; Beförderung akzeptiert weiterhin nur höhere Ränge.
- Testmodus: Selbsternennung als Stellvertretung (`AllowSelfDeputyForTesting`) ist aktiviert. Selbstausstellung (`AllowSelfIssueForTesting`) bleibt aktiviert. Selbst-Rekrutierung bleibt getrennt davon deaktiviert.
- Keine SQL-Migration erforderlich.

## Version 1.3.0
- Testmodus: `Config.Documents.AllowSelfIssueForTesting` ist aktiviert. Berechtigte Polizeileitung/Stellvertretung kann im Polizeisystem die eigene Server-ID auswählen und sich selbst Dienstausweis oder Waffenschein ausstellen.
- Sicherheitsprüfungen bleiben aktiv: passender Polizeijob, gespeicherte Rangberechtigung, bestätigtes Foto sowie gültiger und abgeholter Personalausweis.
- Selbst-Ausgabe/Übergabe des eigenen Dienstausweises bleibt im Testmodus möglich.
- Vor einem öffentlichen Release muss `AllowSelfIssueForTesting` in `config/config.lua` wieder auf `false` gesetzt werden.
- Keine SQL-Migration erforderlich.

## Version 1.2.9
- `/uidzeigen [Dokumenttyp]` öffnet jetzt genau eine Karte als lokale Selbsttest-Präsentation auf dem eigenen Bildschirm – ohne Empfänger und ohne anderen Spieler.
- Die bisherige Schreibweise `/uidzeigen [Server-ID] [Dokumenttyp]` wird für den Selbsttest rückwärtskompatibel interpretiert: Die Server-ID wird ignoriert und die Karte nur lokal angezeigt.
- Alle sechs Dokumenttypen sind einzeln testbar: Personalausweis, Dienstausweis, Waffenschein, Angelschein, Bootsführerschein und Pilotenschein. Ohne Typ werden weiterhin alle Testkarten in der Dokumentenmappe angezeigt.
- Die lokale Einzelkarten-Vorschau verwendet dasselbe Präsentationslayout wie das normale Vorzeigen an andere Spieler und nutzt den eigenen Charakternamen, das Geburtsdatum sowie das gespeicherte Foto.
- Digitale Unterschrift auf allen Ausweisen neu ausgerichtet: Die Signatur sitzt jetzt auf der Linie innerhalb des Unterschriftsfeldes.
- Keine SQL-Migration erforderlich.

## Version 1.2.8
- Fehlerkorrektur: Das Geburtsdatum wird jetzt bei sämtlichen sechs Dokumenttypen mitgeliefert und angezeigt (Personalausweis, Dienstausweis, Waffenschein, Angelschein, Bootsführerschein und Pilotenschein).
- Die Geburtsdatumsabfrage nutzt bei Bedarf zusätzlich den gespeicherten `players.charinfo`-Datensatz, falls QBCore `charinfo` das Feld nicht direkt bereitstellt.
- `/uidzeigen` ohne Parameter öffnet jetzt die Testansicht aller sechs Karten. Mit `/uidzeigen [Server-ID] [Dokumenttyp]` bleibt das Vorzeigen eines echten ausgestellten Dokuments möglich.
- `/uidpreview` bleibt als separater Vorschau-Befehl erhalten. Keine SQL-Migration erforderlich.

## Version 1.2.7
- Alle Dokumentenkarten zeigen jetzt einheitlich das Geburtsdatum unter dem Namen an: Personalausweis, Dienstausweis, Waffenschein, Angelschein, Bootsführerschein und Pilotenschein.
- Die Geburtsdaten werden weiterhin aus den QBCore-Charakterdaten geladen und auch bei der Vorzeigeansicht an den Empfänger übermittelt.
- Keine SQL-Migration erforderlich.

## Version 1.2.6
- Organisations-/Polizeitablet: skalierbares Fenster mit Ziehgriff unten rechts; Breite und Höhe lassen sich während der Nutzung anpassen.
- Dokumentenmappe: gültige Dokumente können über „Ausweis vorzeigen“ dem nächststehenden Spieler innerhalb von 3 Metern gezeigt werden; der Server prüft Dokumentbesitz, Status und Entfernung erneut.
- QBCore-Inventar-Items sind in der Integrationsvorlage jetzt als benutzbar markiert und öffnen die eigene Dokumentenmappe. Von dort kann das jeweilige Dokument vorgezeigt werden.
- Dokumentennummern werden auf keiner Ausweiskarte mehr angezeigt; die interne Nummer bleibt für Datenbankzuordnung und Audit erhalten.
- Waffenschein: zusätzliche Abschlusslinie unter dem Unterschriftsfeld.
- Admin-Tablet-Titel ergänzt: „Pol - Administration System“.
- `qb-target` und `ox_target` bleiben beide unterstützt; `auto` bevorzugt weiterhin `qb-target`, bei Bedarf kann `ox_target` in der Config ausgewählt werden.
- Keine SQL-Migration erforderlich.

## Version 1.2.5
- Organisations- und Polizeisystem: serverseitiger Zugriff setzt jetzt immer den exakt konfigurierten Organisationsjob und einen gültigen QBCore-Jobrang voraus.
- Rangfunktionen prüfen die in `ui_org_rank_permissions` gespeicherten Freigaben; ein Test-/Fallback-Zugriff kann diese Prüfungen nicht mehr umgehen.
- Direkte Server-Event-Aufrufe ohne passenden Organisationsjob oder gültigen Rang erhalten keine Organisationsdaten und können keine Organisationsaktionen ausführen.
- Selbsttest-, Job-Bypass- und Remote-Anzeige-Testschalter sind standardmäßig deaktiviert.
- Admin-Tablet bleibt separat geschützt: Datenabfragen und Aktionen benötigen weiterhin serverseitig bestätigte ACE-/QBCore-Adminrechte.
- `qb-target` bleibt erhalten; `ox_target` wird weiterhin zusätzlich unterstützt. Keine SQL-Migration erforderlich.

## Version 1.2.4
- `ox_target` wird zusätzlich zu `qb-target` unterstützt. Im Modus `auto` wird `qb-target` bevorzugt (Bestandsschutz); ist es nicht gestartet, wird `ox_target` verwendet. Die Auswahl kann in `Config.Documents.TargetSystem` fest auf `qb-target` oder `ox_target` gesetzt werden.
- Admin-Tablet-Anfragen und sämtliche Admin-Tablet-Aktionen werden serverseitig über ACE/QBCore-Adminrechte autorisiert; direkte Event-Aufrufe durch normale Spieler erhalten keine Admin-Daten und können keine Admin-Aktionen ausführen.
- Fotostationen-Refresh ist jetzt ein rein internes Server-Event und kann nicht mehr von Clients direkt ausgelöst werden.
- Bestehende Dokumenten-, Organisations- und Datenbankfunktionen wurden nicht strukturell umgebaut.
- Keine SQL-Migration erforderlich.

## Version 1.2.3
- Admin-Tablet: dekorative Kamera am oberen Tablet-Rahmen entfernt.
- Ausweisbezeichnungen besitzen nur noch eine einzelne Unterstreichung.
- Polizeimitglieder werden nach Rangstufe absteigend sortiert (höchster Rang zuerst).
- Polizei-System: Rangfilter in der Mitgliederübersicht ergänzt; vorhandene Foto-, Status- und Eintrittsdatumsanzeige bleibt erhalten.
- Rangstufe wird zusätzlich zu Rangbezeichnung an die NUI übergeben, damit Sortierung und Filter auch bei gleichen/ähnlichen Rangnamen korrekt arbeiten.

## Version 1.2.2
- Polizei-Ausgabestellen werden unter qb-target unabhängig von der lokalen Rang-Erkennung registriert.
- Abholaktionen verwenden direkt das qb-target-Callback-Feld `action`; Berechtigungen bleiben serverseitig geprüft.
- Veraltete, verschachtelte Kopie der Version 1.2.0 aus dem Release-Paket entfernt.

# Changelog

## 1.2.1
- Waffenschein zeigt jetzt die Dokumentenbezeichnung „Waffenschein“ über dem Namen.
- Dokumentennummer und digitale Unterschrift werden bei Personalausweis, Dienstausweis und Waffenschein einheitlich dargestellt.
- Die jeweilige Dokumentenbezeichnung ist auf allen drei Karten unterstrichen.


## Unreleased – Karten, Berechtigungsanzeige und Update-Sicherheit
- Waffenschein-Kartenkopf verwendet nun „UNIVERSAL IDENTITY“ und darunter „WAFFENBERECHTIGUNG“.
- Angaben „Erlaubnisart“ und „Geltungsbereich“ aus der Waffenschein-Karte entfernt.
- Digitale Unterschrift wird auch auf Personal- und Dienstausweisen angezeigt.
- Passfoto-Rahmen deutlich verschlankt und Portraitfeld vergrößert.
- Hinweis für fehlende Veröffentlichungsrechte verweist nun auf die Rechtevergabe im Admin-Tablet, statt feste Rollen zu nennen.
- Update- und Datensicherheitsregeln in `UPDATE_SYSTEM_DE.md` dokumentiert. Diese Version benötigt keine SQL-Migration.


## Version 1.3.8 – Mitarbeitersuche und Neueinstellung korrigiert
- Mitarbeitersuche und Dokumenten-/Neueinstellungssuche serverseitig getrennt: Die Mitarbeiterverwaltung akzeptiert ausschließlich Spieler mit dem konfigurierten Polizei-Job; Zivilisten und Spieler anderer Jobs werden abgewiesen.
- Die allgemeine Personensuche bleibt weiterhin für alle Online-Spieler anhand der Server-ID verfügbar.
- Dokumenten-/Neueinstellungssuche erlaubt Spieler ohne Polizeijob nur im aktivierten Polizei-Testmodus oder mit der Admin-seitig vergebenen Berechtigung „Mitarbeiter einstellen“.
- Fehler beim gesperrten Button „Dienstausweis erstellen“ behoben: Eine Rang-Auswahl aktualisiert jetzt zuverlässig die Button-Freigabe. Die Freigabe prüft Foto, gültigen Personalausweis, Bestätigung, Rang und gegebenenfalls Neueinstellungsberechtigung.
- Übergabe prüft den ausgewählten QBCore-Jobrang anhand von `QBCore.Shared.Jobs[job].grades`, ruft `SetJob()` mit dem passenden Grade-Schlüssel auf und kontrolliert anschließend, ob Job und Rang tatsächlich übernommen wurden.
- Schlägt `SetJob()` fehl oder wird ein anderer Rang gesetzt, werden Ausweis und Datenbankstatus soweit möglich zurückgebucht; der Vorgang wird protokolliert.
- Keine neue SQL-Migration erforderlich. Vorhandene Spieler-, Foto-, Dokumenten-, Stations- und Protokolldaten bleiben erhalten.

## Version 1.3.7 – Personal-Testmodus und Neueinstellung
- Admin-Tablet: Polizei-Testmodus dauerhaft ein-/ausschaltbar; Einstellung wird serverseitig gespeichert.
- Rechteverwaltung: separate Berechtigung „Mitarbeiter einstellen“ zusätzlich zu „Ränge verwalten“.
- Polizeisystem: Option „Mitarbeiter einstellen“ bei der Dienstausweis-Ausstellung für Spieler ohne Polizeijob.
- Neueinstellungen werden erst nach persönlicher Übergabe des abgeholten Dienstausweises per QBCore `SetJob()` aktiviert.
- Additive Datenbankmigration für `is_recruitment`; bestehende Dokumente bleiben unverändert.
- Im Polizeitablet wird der aktive Testmodus sichtbar gekennzeichnet.
