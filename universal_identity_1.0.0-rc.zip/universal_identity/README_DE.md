# Universal Identity – QBCore

**Version:** 1.0.0-rc.1  
**Status:** Release Candidate – vor öffentlicher Stable-Freigabe Ingame testen  
**Framework:** QBCore (kein ESX)  
**Datenbank:** oxmysql mit MySQL/MariaDB

Universal Identity verbindet Charakterfotos mit Personalausweisen und weiteren Dokumentkarten. Enthalten sind ein Dokumentensystem, ein Polizei-Tablet und ein separates, serverseitig geschütztes Admin-Tablet.

> **Release-Candidate-Hinweis:** Die Dateien und Konfiguration wurden statisch geprüft. Ein echter FiveM-Live-Test auf einer frischen Installation und ein Update-Test mit einer Kopie einer Bestandsdatenbank sind nicht Bestandteil dieser Paketprüfung. Bitte vor öffentlicher Verteilung die Checkliste am Ende abarbeiten.

## Inhalt

1. Voraussetzungen
2. Neuinstallation
3. Startreihenfolge und Adminrechte
4. QBCore-Items und Bilder
5. Konfiguration
6. Polizei-Job und Ränge
7. Fotostationen und Abholstationen
8. Polizei-Tablet und Berechtigungen
9. Admin-Tablet und Testmodus
10. Dokumente und Befehle
11. Update einer bestehenden Installation
12. Daten, Fotos und Datenschutz
13. Fehlerbehebung
14. Release-Testcheckliste

## 1. Voraussetzungen

Erforderlich:

- FiveM-Server mit QBCore
- `oxmysql` und MySQL/MariaDB
- `screenshot-basic` für die Charakterfotoaufnahme
- QBCore-Inventar mit Unterstützung für einzigartige Items und Metadaten

Optional:

- `qb-target` oder `ox_target`. Bei `TargetSystem = 'auto'` wird `qb-target` bevorzugt, danach `ox_target`. Ohne Target-System verwendet die Resource Marker-/E-Interaktionen.

## 2. Neuinstallation

1. ZIP entpacken. Der enthaltene Ordner heißt `universal_identity`.
2. Den Ordner nach beispielsweise `resources/[local]/universal_identity` kopieren.
3. Prüfen, dass `fxmanifest.lua` direkt in `universal_identity/` liegt.
4. Startreihenfolge und ACE-Adminrecht aus Abschnitt 3 in `server.cfg` ergänzen.
5. Die sechs Itemdefinitionen aus `integrations/qbcore_items.lua` in die bestehende QBCore-Itemtabelle übernehmen.
6. Die sechs PNG-Dateien aus `integrations/item_images/` in den Bilderordner des Inventars kopieren.
7. `config/config.lua` an den Jobnamen und die Serverumgebung anpassen.
8. Die SQL-Installationsdatei `sql/install.sql` nur bei einer wirklich neuen Installation in die dafür vorgesehene Datenbank importieren. Bei bestehenden Installationen nicht erneut importieren.
9. Server vollständig neu starten und Konsole prüfen.

**Wichtig:** Niemals die komplette `qb-core/shared/items.lua` ersetzen. Nur die sechs Itemeinträge ergänzen und doppelte Itemnamen vermeiden.

## 3. Startreihenfolge und Adminrechte

Beispiel für `server.cfg` (Pfade und Gruppen an den eigenen Server anpassen):

```cfg
ensure oxmysql
ensure qb-core
ensure screenshot-basic

# Nur das verwendete Target-System starten:
ensure qb-target
# ensure ox_target

ensure universal_identity

# Serveradmin-Zugriff:
add_ace group.admin universal_identity.admin allow
```

Wenn ausschließlich `ox_target` verwendet wird, `ensure qb-target` auskommentieren und `ensure ox_target` aktivieren.

Die Resource prüft Adminzugriff serverseitig über `universal_identity.admin`, `group.admin` und die QBCore-Berechtigungen `admin`/`god`. Beispiel für eine zusätzliche Gruppe:

```cfg
add_ace group.superadmin universal_identity.admin allow
add_principal identifier.license:DEINE_LICENSE group.superadmin
```

`DEINE_LICENSE` durch die echte Lizenzkennung ersetzen. Die Organisationsverwaltung im Polizeitablet wird für Nicht-Admins vollständig verborgen. Zusätzlich prüft der Server jeden geschützten Aufruf; das Verstecken der Schaltfläche ist keine alleinige Sicherheitsmaßnahme.

## 4. QBCore-Items und Inventarbilder

Die Resource verwendet diese sechs Items:

- `universal_personal_id` – Personalausweis
- `universal_org_id` – Dienstausweis
- `universal_weapon_permit` – Waffenschein
- `universal_fishing_license` – Angelschein
- `universal_boat_license` – Bootsführerschein
- `universal_pilot_license` – Pilotenschein

Die Definitionen stehen in `integrations/qbcore_items.lua`. In die vorhandene `Items`-Tabelle von `qb-core/shared/items.lua` einfügen. Die zugehörigen PNG-Dateien aus `integrations/item_images/` in den Inventar-Bilderordner kopieren (bei qb-inventory üblicherweise `qb-inventory/html/images/`). Dateinamen exakt beibehalten. Danach den Server vollständig neu starten.

## 5. Konfiguration

Die serverbetreiberspezifischen Einstellungen liegen in `config/config.lua`.

| Einstellung | Zweck |
|---|---|
| `Config.AdminAcePermission` | ACE-Berechtigung für Serveradmins |
| `Config.Documents.TargetSystem` | `auto`, `qb-target` oder `ox_target` |
| `Config.Documents.UseTarget` | Target-Interaktionen ein-/ausschalten |
| `Config.Documents.PoliceTestMode` | Startzustand des Polizei-Admin-Selbsttests; Standard `false` |
| `Config.Documents.AllowSelfIssueForTesting` | Admin-Selbstausstellung im Testmodus; Standard `true` |
| `Config.Documents.WeaponPermitApplicationPrice` | Preis für selbst beantragte Waffenscheine |
| `Config.Documents.WeaponPermitTabletFee` | Standardgebühr bei Ausstellung über das Polizeitablet; Admin-Tablet kann sie ändern |
| `Config.Documents.Organisations.police.job` | Exakter QBCore-Jobschlüssel |
| `Config.Documents.Organisations.police.minimumGrade` | Numerischer Mindest-/Leitungsrang gemäß QBCore-Grade-Level |

Beispiel für einen Server mit Jobschlüssel `lspd`:

```lua
Organisations = {
    police = {
        label = 'LSPD',
        job = 'lspd',
        minimumGrade = 4,
        documentRanks = nil
    }
}
```

Der interne Organisationsschlüssel bleibt `police`; `job` muss exakt einem Eintrag in `QBCore.Shared.Jobs` entsprechen. Rangnamen und Grade-Level werden aus QBCore gelesen. Keine Rangnamen im Script fest einprogrammieren.

## 6. Polizei-Job und Ränge

In `qb-core/shared/jobs.lua` den tatsächlichen Jobnamen und die numerischen Grade-Level prüfen. `minimumGrade` auf den gewünschten Leitungsrang setzen. Die Grade-Level sollten mit zunehmender Ranghöhe steigen. Die Dienstausweise bestehender Polizeimitglieder orientieren sich am tatsächlichen QBCore-Job und Rang; externe Jobänderungen werden über den QBCore-Jobupdate-Hook synchronisiert.

## 7. Fotostationen und Abholstationen

Alle Standortbefehle benötigen Serveradminrechte. Der Admin stellt sich an die gewünschte Position und führt den Befehl aus.

| Befehl | Zweck |
|---|---|
| `/setphotostation` | Fotostation an der aktuellen Position erstellen |
| `/listphotostations` | Fotostationen auflisten |
| `/deletephotostation ID` | Fotostation anhand der ID löschen |
| `/setidpickup [Name]` | Personalausweis-Abholstation erstellen |
| `/setorgpc police [Name]` | Polizei-Organisations-PC erstellen |
| `/uidlocations` | gespeicherte Standorte auflisten/aktualisieren |
| `/uiddeletelocation photo ID` | Fotostation löschen |
| `/uiddeletelocation pickup ID` | Personalausweis-Abholstation löschen |
| `/uiddeletelocation pc ID` | Organisations-PC löschen |
| `/uidphotostatus` | Foto-/Datenbankstatus prüfen |

### Wichtiger Hinweis zur Standortfreiheit

**Fotostationen und Personalausweis-Abholstationen können völlig unabhängig von der Polizei platziert werden.** Sie sind eigenständige Standorte und müssen weder bei einer Polizei-Ausgabestelle noch bei einem Organisations-PC liegen. Das Fotosystem speichert das Charakterfoto; dieses Foto wird anschließend vom Personalausweis- und Dokumentensystem verwendet. Ein Server kann beispielsweise eine Fotostation im Bürgeramt und eine Personalausweis-Abholstation im Rathaus platzieren, ohne dafür das Polizeisystem einzurichten.

Polizei-Ausgabestellen und Organisations-PCs sind davon getrennte Standorte für die polizeilichen Abläufe.

## 8. Polizei-Tablet und Berechtigungen

Das Polizei-Tablet wird über den konfigurierten Polizei-Organisations-PC geöffnet. Im normalen Betrieb müssen Job, QBCore-Rang und die im Admin-Tablet vergebenen Rechte passen.

Die Rechteverwaltung kann unter anderem folgende Aktionen pro Rang steuern:

- Polizeimitglieder ansehen
- Dienstausweise/Waffenscheine ausstellen
- Mitarbeiter einstellen
- Mitarbeiter verwalten/befördern
- Mitarbeiter kündigen
- Stellvertretung verwalten
- Protokolle ansehen
- Bekanntmachungen verwalten

Fehlt die Berechtigung zum Ansehen der Polizeimitglieder, erscheint die verständliche Berechtigungsmeldung. Eine tatsächlich leere Liste wird davon getrennt angezeigt. Der Eintrag **Organisationsverwaltung** unten links ist ausschließlich für Serveradmins sichtbar; der Server prüft Adminrechte zusätzlich bei jedem Aufruf.

Eine Neueinstellung benötigt die Berechtigung **Mitarbeiter einstellen**. Bei erfolgreicher Dienstausweis-Ausstellung wird der QBCore-Job des Zielspielers sofort gesetzt – nicht erst bei der späteren physischen Übergabe. Der ausgewählte Rang muss in den QBCore-Jobgraden vorhanden und niedriger als der Rang des Ausstellers sein. Bestehende Mitglieder erhalten den tatsächlichen QBCore-Rang auf ihrem Dienstausweis.

Für Dienstausweis und Waffenschein muss der Zielspieler ein bestätigtes Foto und einen gültigen, bereits abgeholten Personalausweis besitzen. Die Vorzeige-Bestätigung ist ebenfalls erforderlich.

## 9. Admin-Tablet und Polizei-Testmodus

Das Admin-Tablet ist ausschließlich für serverseitig bestätigte Serveradmins verfügbar.

### Polizei-Testmodus

Die Kachel **Polizei-Testmodus** bleibt im Release enthalten. Sie ist standardmäßig ausgeschaltet. Ein Serveradmin kann sie bei Bedarf einschalten, um ausschließlich die eigenen Dokumente zu testen (Dienstausweis/Waffenschein). Die Admin-Selbstausstellung ändert den eigenen QBCore-Job nicht.

Der Testmodus gibt normalen Spielern keine Adminrechte und erlaubt keine Neueinstellung anderer Spieler. Normale Polizeimitglieder müssen weiterhin einen gültigen QBCore-Job/Rang und die zugewiesenen Berechtigungen besitzen. Die Freigabe wird serverseitig geprüft.

### Freelancer-Testrolle

Die separate Freelancer-Testrolle ist in diesem öffentlichen Paket nicht enthalten. Ein alter Datenbankeintrag aus einer Beta-Version wird nicht als Berechtigung ausgewertet. Die zugehörigen historischen Daten werden nicht pauschal gelöscht.

### Waffenscheingebühr

Die Standardgebühr beträgt 6.500 $, kann im Admin-Tablet angepasst werden. Polizeimitglieder erhalten den Waffenschein kostenlos. Es erfolgt kein automatischer Geldabzug: Der Aussteller bestätigt, dass die Gebühr persönlich übergeben wurde.

## 10. Dokumente und Befehle

Enthaltene Dokumenttypen:

- Personalausweis
- Dienstausweis
- Waffenschein
- Angelschein
- Pilotenschein
- Bootsführerschein

Spielerbefehle:

| Befehl | Funktion |
|---|---|
| `/uiddocuments` | eigene Dokumente anzeigen |
| `/uidzeigen [Dokumenttyp]` | eigenes ausgestelltes Dokument vorzeigen |

Weitere Admin-/Standortbefehle sind in Abschnitt 7 und im Admin-Tablet aufgeführt. Interne Ausstellerbefehle wie `/uidgiveorg SERVER-ID` bleiben für den vorgesehenen Übergabeablauf registriert, werden aber nicht als allgemeine Spielerbefehle beworben.

## 11. Update einer bestehenden Installation

1. Server stoppen.
2. Vollständiges Backup der Datenbank und des bisherigen Resource-Ordners erstellen.
3. `config/config.lua`, `photos/` und alle serverindividuellen Dateien separat sichern.
4. Nur den Programmordner aus dem neuen Paket aktualisieren. Vorhandene Datenordner und Betreiberkonfiguration nicht blind überschreiben.
5. Neue Konfigurationsoptionen anhand dieser README übernehmen; bestehende Werte nicht durch Beispielwerte ersetzen.
6. QBCore-Items nicht doppelt eintragen. Bereits installierte Items und Bilder bleiben bestehen.
7. Server starten und Konsole prüfen.

Für diesen Release Candidate ist keine neue SQL-Migration vorgesehen. `sql/install.sql` bei einer bestehenden Installation **nicht erneut importieren**. Die Resource legt erforderliche Tabellen mit `CREATE TABLE IF NOT EXISTS` an und verwendet gezielte additive Spaltenmigrationen. Bestehende Datensätze sollen erhalten bleiben.

## 12. Daten, Fotos und Datenschutz

Das öffentliche Paket enthält **keine persönlichen Spielerfotos, keine Server-Spieler, keine Dokumentdatensätze und keine individuellen Standortdatensätze**. Der Ordner `photos/` enthält nur eine leere `.gitkeep`-Datei als Platzhalter. Fotos werden erst auf dem jeweiligen Server aufgenommen.

Fotostationen, Personalausweis-Abholstationen, Polizei-Ausgabestellen und Organisations-PCs werden serverindividuell in der Datenbank gespeichert. Sie werden nicht in die öffentliche ZIP exportiert. Bei Updates bleiben vorhandene Standortdatensätze erhalten.

Vor jedem Update Datenbank, Resource-Konfiguration und `photos/` sichern. Keine pauschalen `DROP`, `TRUNCATE` oder Datenbank-Neuanlagen durchführen. Alte Beta-Einstellungen werden nicht als Berechtigungen übernommen. Die Resource löscht beim Start keine bestehenden Organisations-PC-Datensätze anderer Schlüssel.

## 13. Fehlerbehebung

**Resource startet nicht:** Startreihenfolge, Ordnerstruktur, `oxmysql`, `qb-core` und `screenshot-basic` kontrollieren.

**Fotoaufnahme schlägt fehl:** `screenshot-basic`, NUI-/Clientkonsole, Datenbankverbindung und Fotoordner prüfen.

**Inventar zeigt unbekanntes Item:** Itemdefinitionen in `qb-core/shared/items.lua` prüfen; keine doppelten Namen; Server vollständig neu starten.

**Inventarbild fehlt:** PNG-Datei im richtigen Inventar-Bilderordner und exakten Dateinamen prüfen.

**Target fehlt:** `Config.Documents.TargetSystem` und gestartete Target-Resource prüfen. Ohne Target sollten Marker-/E-Interaktionen verfügbar sein.

**Polizei-Tablet öffnet nicht:** tatsächlichen QBCore-Jobnamen, Rang, `Config.Documents.Organisations.police.job` und PC-Standort prüfen.

**Admin-Tablet öffnet nicht:** ACE-Eintrag und QBCore-Adminstatus prüfen. Die Resource verweigert Nicht-Admins den Zugriff auch bei direkten Event-Aufrufen.

## 14. Release-Testcheckliste

### Installation und Rechte
- [ ] Neuinstallation auf frischem QBCore-Testserver ohne Konsolenfehler
- [ ] Admin-Tablet nur für Serveradmins erreichbar
- [ ] Organisationsverwaltung für normale Spieler vollständig verborgen
- [ ] Direkte Admin-Events für normale Spieler serverseitig abgewiesen
- [ ] Freelancer-Testrolle erscheint nicht und gewährt keinen Zugriff

### Foto und Personalausweis
- [ ] Fotostation frei platzierbar und nutzbar
- [ ] Foto wird gespeichert und auf Dokumentkarten angezeigt
- [ ] Personalausweis-Abholstation unabhängig von Polizei platzierbar
- [ ] Personalausweis wird korrekt ins Inventar gelegt
- [ ] Fotos bleiben nach Resource-/Serverneustart erhalten

### Polizei
- [ ] Polizei-Tablet am Organisations-PC erreichbar
- [ ] Rangberechtigungen werden serverseitig angewendet
- [ ] Polizeimitglieder: Berechtigungsfehler und leere Liste werden unterschieden
- [ ] Dienstausweis-Ausstellung verlangt Foto, gültigen Personalausweis und Vorzeige-Bestätigung
- [ ] Neueinstellung mit zweitem Spieler setzt Job/Rang sofort bei Ausstellung
- [ ] Dienstausweis zeigt den QBCore-Rang und aktualisiert sich nach externem Jobwechsel
- [ ] Waffenschein-Gebühr, persönliche Zahlungsbestätigung und Polizeibefreiung prüfen
- [ ] Übergabe und Kündigung inkl. Widerruf/Protokoll prüfen

### Admin-Selbsttest und Persistenz
- [ ] Polizei-Testmodus standardmäßig AUS
- [ ] Admin kann ihn einschalten und ausschließlich eigene Dokumente testen
- [ ] Admin-Selbstausstellung ändert den eigenen QBCore-Job nicht
- [ ] Normaler Spieler kann den Testmodus nicht einschalten oder missbrauchen
- [ ] Fotostationen, Abholstationen, Fotos, Dokumente und Protokolle bleiben nach Neustart erhalten
- [ ] Update auf einer Kopie einer Bestandsdatenbank ohne Datenverlust
- [ ] `qb-target` und `ox_target` jeweils separat testen
- [ ] CPU-/Server-Tick-Verhalten mit mehreren Spielern prüfen

---

**Freigabestatus:** Erst nach erfolgreichem Ingame-Test und Update-Test sollte der Release Candidate als stabile Version `1.0.0` veröffentlicht werden.
