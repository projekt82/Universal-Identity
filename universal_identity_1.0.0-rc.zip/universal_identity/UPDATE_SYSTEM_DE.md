# Universal Identity – Update- und Datensicherheitskonzept

## Grundregeln
- Vor jedem Update Datenbank, Resource-Ordner, `config/config.lua` und `photos/` sichern.
- Betreiberkonfiguration und serverindividuelle Daten nicht blind durch Release-Beispiele ersetzen.
- `sql/install.sql` ausschließlich bei Neuinstallationen importieren.
- Bestehende Spieler-, Foto-, Dokument-, Stations-, Organisations-, Protokoll- und Berechtigungsdaten nicht löschen.
- Keine pauschalen `DROP TABLE`, `TRUNCATE` oder Reset-Importe.
- Neue Datenbankänderungen müssen gezielt, dokumentiert und wiederholbar sein.

## Updateablauf
1. Server stoppen.
2. Datenbank- und Dateisicherung erstellen.
3. `config/config.lua` und `photos/` sichern.
4. Release-Dateien aktualisieren.
5. Neue Konfigurationsoptionen manuell übernehmen, bestehende Werte beibehalten.
6. SQL-Migrationen nur ausführen, wenn die konkrete Version dies ausdrücklich verlangt.
7. Server starten und Konsole kontrollieren.
8. Foto-, Dokument-, Standort- und Tablet-Funktionen prüfen.

## Datenumfang im öffentlichen Paket
Das Paket enthält keine persönlichen Charakterfotos, keine Spieler- oder Dokumentdatensätze und keine serverindividuellen Stationen. `photos/` enthält nur `.gitkeep`. Foto- und Standortdaten werden erst auf dem jeweiligen Server erzeugt und in dessen Datenbank/Dateisystem gespeichert.

Fotostationen und Personalausweis-Abholstationen sind eigenständige, frei platzierbare Standorte und nicht an Polizei-Ausgabestellen oder Organisations-PCs gebunden.

## Release Candidate 1.0.0-rc.1
- Öffentliche Freelancer-Testrolle entfernt und serverseitig deaktiviert; vorhandene Legacy-Einstellung wird nicht als Berechtigung ausgewertet.
- Polizei-Testmodus bleibt als Admin-Selbsttest erhalten und ist standardmäßig ausgeschaltet.
- Admin-Selbstausstellung ist auf den eigenen Charakter beschränkt und darf den QBCore-Job nicht ändern.
- Nicht benötigte personenbezogene Fotos und das externe Blender-Modell wurden aus dem öffentlichen Paket entfernt.
- Destruktive Bereinigung von Organisations-PC-Datensätzen beim Start entfernt.
- Keine neue SQL-Migration vorgesehen. Bestehende Datenbank nicht neu importieren.

## Freigabe
Dieser RC wurde statisch geprüft. Vor der stabilen Version `1.0.0` müssen frische Installation, Update auf einer Datenbankkopie, Rechteprüfungen, Foto-/Dokumentenabläufe, beide Target-Systeme und Mehrspieler-Verhalten ingame getestet werden.
