-- QBCore adapter: this resource only needs the character identifier.
local QBCore = exports['qb-core']:GetCoreObject()

Bridge = Bridge or {}

function Bridge.GetIdentifier(source)
    local player = QBCore.Functions.GetPlayer(tonumber(source))
    if not player then
        return nil
    end

    local playerData = player.PlayerData or {}
    return playerData.citizenid
end

print('[Universal Photos] QBCore bridge loaded.')
