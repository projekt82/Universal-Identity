local QBCore = exports['qb-core']:GetCoreObject()
local pickupLocations, orgPcs = {}, {}
local tabletOpen, tabletOrgKey = false, nil
local documentsOpen = false
local oxTargetZoneIds = {}
local qbTargetZoneNames = {}
local targetMode = false
local policeTestModeEnabled = Config.Documents and Config.Documents.PoliceTestMode == true
local adminPoliceTestAccess = false

local function notify(message, kind) QBCore.Functions.Notify(message, kind or 'primary', 6000) end

local function hasValidPoliceRank()
    if adminPoliceTestAccess == true and policeTestModeEnabled == true then return true end
    local data = QBCore.Functions.GetPlayerData()
    local job = data and data.job
    local policeOrg = Config.Documents and Config.Documents.Organisations and Config.Documents.Organisations.police or {}
    local policeJob = tostring(policeOrg.job or 'police')
    if not job or job.name ~= policeJob then return false end
    local grade = tonumber((job.grade or {}).level or job.grade)
    if not grade then return false end
    local sharedJob = QBCore.Shared and QBCore.Shared.Jobs and QBCore.Shared.Jobs[policeJob]
    local grades = sharedJob and sharedJob.grades
    return type(grades) == 'table' and (grades[tostring(grade)] ~= nil or grades[grade] ~= nil)
end

local function clearOxTargetZones()
    if GetResourceState('ox_target') == 'started' then
        for _, zoneId in ipairs(oxTargetZoneIds) do pcall(function() exports.ox_target:removeZone(zoneId) end) end
    end
    if GetResourceState('qb-target') == 'started' then
        for _, zoneName in ipairs(qbTargetZoneNames) do pcall(function() exports['qb-target']:RemoveZone(zoneName) end) end
    end
    oxTargetZoneIds, qbTargetZoneNames = {}, {}
end

RegisterNetEvent('universal_identity:policeTestModeState', function(enabled)
    policeTestModeEnabled = enabled == true
    if not policeTestModeEnabled then adminPoliceTestAccess = false end
    SendNUIMessage({ action = 'policeTestModeState', enabled = policeTestModeEnabled })
end)

CreateThread(function()
    Wait(1500)
    TriggerServerEvent('universal_identity:requestPoliceTestModeState')
end)

RegisterNetEvent('universal_identity:documentLocations', function(pickups, pcs)
    pickupLocations = pickups or {}
    orgPcs = pcs or {}
    clearOxTargetZones()
    local qbStarted = GetResourceState('qb-target') == 'started'
    local oxStarted = GetResourceState('ox_target') == 'started'
    local requestedTarget = tostring(Config.Documents.TargetSystem or 'auto'):lower()
    local useOxTarget = requestedTarget == 'ox_target' and oxStarted
        or requestedTarget == 'auto' and not qbStarted and oxStarted
    local useQbTarget = requestedTarget == 'qb-target' and qbStarted
        or requestedTarget == 'auto' and qbStarted
    targetMode = Config.Documents.UseTarget == true and (useOxTarget or useQbTarget)
    if not targetMode then return end
    for _, loc in ipairs(pickupLocations) do
        local isPersonal = tostring(loc.station_type or 'police') == 'personal'
        local zoneId
        local options
        if isPersonal then
            options = {{ name = ('ui_pickup_personal_%s'):format(loc.id), icon = 'fa-solid fa-id-card', label = 'Personalausweis abholen', onSelect = function() TriggerServerEvent('universal_identity:collectPersonalId') end }}
        else
            -- Target-Zone immer registrieren. Die Client-Rangprüfung darf die Zone
            -- nicht unterdrücken (z.B. abweichende QBCore-Grade-Strukturen).
            -- Die Server-Events prüfen Job, Rang und Berechtigung verbindlich erneut.
            options = {
                { name = ('ui_pickup_org_%s'):format(loc.id), icon = 'fas fa-id-card', label = 'Dienstausweis abholen', action = function() TriggerServerEvent('universal_identity:collectOrgDocument') end },
                { name = ('ui_pickup_weapon_%s'):format(loc.id), icon = 'fas fa-shield-alt', label = 'Waffenschein abholen', action = function() TriggerServerEvent('universal_identity:collectWeaponPermit') end }
            }
        end
        if options and useOxTarget then
            zoneId = exports.ox_target:addSphereZone({
                coords = vector3(tonumber(loc.x) or 0, tonumber(loc.y) or 0, tonumber(loc.z) or 0),
                radius = Config.Documents.PickupInteractionDistance or 2.0,
                debug = false,
                options = options
            })
            if zoneId then oxTargetZoneIds[#oxTargetZoneIds + 1] = zoneId end
        elseif options then
            local name = ('ui_pickup_%s'):format(loc.id)
            local qbOptions = {}
            for _, option in ipairs(options) do
                qbOptions[#qbOptions + 1] = {
                    icon = option.icon,
                    label = option.label,
                    action = option.action or option.onSelect
                }
            end
            exports['qb-target']:AddBoxZone(name, vector3(tonumber(loc.x) or 0, tonumber(loc.y) or 0, tonumber(loc.z) or 0), 1.0, 1.0, { name = name, heading = tonumber(loc.heading) or 0, debugPoly = false, minZ = (tonumber(loc.z) or 0) - 0.8, maxZ = (tonumber(loc.z) or 0) + 0.8 }, { options = qbOptions, distance = Config.Documents.PickupInteractionDistance or 2.0 })
            qbTargetZoneNames[#qbTargetZoneNames + 1] = name
        end
    end
    for _, pc in ipairs(orgPcs) do
        local orgKey = pc.org_key
        local org = Config.Documents.Organisations[orgKey]
        local zoneId
        if useOxTarget then
            zoneId = exports.ox_target:addSphereZone({
            coords = vector3(tonumber(pc.x) or 0, tonumber(pc.y) or 0, tonumber(pc.z) or 0),
            radius = Config.Documents.OrgPcInteractionDistance or 2.0,
            debug = false,
            options = {{ name = ('ui_orgpc_%s'):format(pc.id), icon = 'fa-solid fa-tablet-screen-button', label = (orgKey == 'police' and 'Pol - Organisation öffnen' or ((org and org.label or 'Organisations-Tablet') .. ' öffnen')), onSelect = function() TriggerServerEvent('universal_identity:openOrgTablet', orgKey) end }}
            })
            if zoneId then oxTargetZoneIds[#oxTargetZoneIds + 1] = zoneId end
        else
            local name = ('ui_orgpc_%s'):format(pc.id)
            exports['qb-target']:AddBoxZone(name, vector3(tonumber(pc.x) or 0, tonumber(pc.y) or 0, tonumber(pc.z) or 0), 1.0, 1.0, { name = name, heading = tonumber(pc.heading) or 0, debugPoly = false, minZ = (tonumber(pc.z) or 0) - 0.8, maxZ = (tonumber(pc.z) or 0) + 0.8 }, { options = {{ icon = 'fas fa-tablet-alt', label = (orgKey == 'police' and 'Pol - Organisation öffnen' or ((org and org.label or 'Organisations-Tablet') .. ' öffnen')), action = function() TriggerServerEvent('universal_identity:openOrgTablet', orgKey) end }}, distance = Config.Documents.OrgPcInteractionDistance or 2.0 })
            qbTargetZoneNames[#qbTargetZoneNames + 1] = name
        end
    end
end)

RegisterNetEvent('universal_identity:showOrgTablet', function(orgKey, orgLabel, issuerName, deputy, balances)
    tabletOpen, tabletOrgKey = true, orgKey
    adminPoliceTestAccess = balances and balances.adminSelfIssue == true and balances.testMode == true or false
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openOrgTablet', orgKey = orgKey, orgLabel = orgLabel, issuerName = issuerName, serverId = GetPlayerServerId(PlayerId()), deputy = deputy or {}, balances = balances or {}, serverDateTime = balances and balances.serverDateTime or nil, testMode = balances and balances.testMode == true, adminSelfIssue = balances and balances.adminSelfIssue == true, isServerAdmin = balances and balances.isServerAdmin == true })
    TriggerServerEvent('universal_identity:requestOrgAnnouncements', orgKey)
end)

RegisterNetEvent('universal_identity:tabletLookupResult', function(result)
    SendNUIMessage({ action = 'orgLookupResult', result = result })
end)
RegisterNetEvent('universal_identity:orgEmployeeManagementLookupResult', function(result)
    SendNUIMessage({ action = 'orgEmployeeManagementLookupResult', result = result or {} })
end)
RegisterNetEvent('universal_identity:tabletIssueResult', function(result)
    SendNUIMessage({ action = 'orgIssueResult', result = result })
end)
RegisterNetEvent('universal_identity:orgPermissionDenied', function(message)
    SendNUIMessage({ action = 'orgPermissionDenied', message = tostring(message or 'Du bist für diese Aktion nicht berechtigt.') })
end)


-- Organisationszugriff sofort beenden, wenn der Charakter den erforderlichen Job verliert.
-- QBCore löst dieses Ereignis auch bei Jobänderungen durch andere Ressourcen aus.
RegisterNetEvent('QBCore:Client:OnJobUpdate', function(newJob)
    if not tabletOpen or not tabletOrgKey then return end
    local org = Config.Documents.Organisations and Config.Documents.Organisations[tabletOrgKey]
    if not org then return end
    local jobName = type(newJob) == 'table' and newJob.name or nil
    if jobName ~= org.job and not (adminPoliceTestAccess == true and policeTestModeEnabled == true) then
        tabletOpen, tabletOrgKey = false, nil
        adminPoliceTestAccess = false
        SendNUIMessage({ action = 'closeOrgTablet' })
        SetNuiFocus(false, false)
        notify('Der Zugriff auf dieses Organisationssystem wurde beendet, weil du nicht mehr zur Organisation gehörst.', 'error')
    end
end)

RegisterNUICallback('requestOrgPoliceMembers', function(_, cb)
    if tabletOpen and tabletOrgKey then TriggerServerEvent('universal_identity:requestOrgPoliceMembers', tabletOrgKey) end
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:orgPoliceMembersData', function(members, authorized, message)
    SendNUIMessage({ action = 'orgPoliceMembersData', members = members or {}, authorized = authorized == true, message = message })
end)
RegisterNUICallback('requestOpenAdminTablet', function(_, cb)
    -- Das Polizeisystem vollständig schließen, bevor das Admin-Tablet angefordert wird.
    -- So liegen niemals zwei NUI-Tablets übereinander und es bleibt kein NUI-Fokus hängen.
    tabletOpen, tabletOrgKey = false, nil
    adminPoliceTestAccess = false
    SendNUIMessage({ action = 'closeOrgTablet' })
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    TriggerServerEvent('universal_identity:requestOpenAdminTablet')
    cb({ success = true })
end)

RegisterNUICallback('closeOrgTablet', function(_, cb)
    tabletOpen, tabletOrgKey = false, nil
    adminPoliceTestAccess = false
    SetNuiFocus(false, false)
    cb({ success = true })
end)
RegisterNUICallback('lookupOrgDeputyCandidate', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:lookupOrgDeputyCandidate', tabletOrgKey, tonumber(data and data.serverId))
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:tabletDeputyCandidateResult', function(result)
    SendNUIMessage({ action = 'orgDeputyCandidateResult', result = result })
end)
RegisterNUICallback('manageOrgDeputy', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:manageOrgDeputy', tabletOrgKey, tonumber(data and data.serverId), tostring(data and data.action or ''))
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:tabletDeputyResult', function(result)
    SendNUIMessage({ action = 'orgDeputyResult', result = result })
end)
RegisterNUICallback('searchOrgPersonProtocol', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:searchOrgPersonProtocol', tabletOrgKey, tonumber(data and data.serverId))
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:orgPersonProtocolResult', function(result)
    SendNUIMessage({ action = 'orgPersonProtocolResult', result = result or {} })
end)
RegisterNUICallback('fireOrgEmployee', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:fireOrgEmployee', tabletOrgKey, tonumber(data and data.serverId), tostring(data and data.reason or ''))
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:tabletFireResult', function(result)
    SendNUIMessage({ action = 'orgFireResult', result = result })
end)
RegisterNUICallback('requestOrgTerminationLogs', function(_, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:requestOrgTerminationLogs', tabletOrgKey)
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:orgTerminationLogs', function(data)
    SendNUIMessage({ action = 'orgTerminationLogs', data = data or {} })
end)
RegisterNUICallback('requestOrgIssueLogs', function(_, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:requestOrgIssueLogs', tabletOrgKey)
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:orgIssueLogs', function(data)
    SendNUIMessage({ action = 'orgIssueLogs', data = data or {} })
end)

RegisterNUICallback('archiveAllOrgProtocols', function(_, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:archiveAllOrgProtocols', tabletOrgKey); cb({ success = true })
end)
RegisterNUICallback('requestOrgArchiveMonths', function(_, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:requestOrgArchiveMonths', tabletOrgKey); cb({ success = true })
end)
RegisterNUICallback('requestOrgArchiveEntries', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:requestOrgArchiveEntries', tabletOrgKey, tostring(data and data.month or '')); cb({ success = true })
end)
RegisterNUICallback('archiveOrgProtocol', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:archiveOrgProtocol', tabletOrgKey, tostring(data and data.sourceType or ''), tonumber(data and data.sourceId)); cb({ success = true })
end)
RegisterNetEvent('universal_identity:orgArchiveMonths', function(data) SendNUIMessage({ action = 'orgArchiveMonths', data = data or {} }) end)
RegisterNetEvent('universal_identity:orgArchiveEntries', function(data) SendNUIMessage({ action = 'orgArchiveEntries', data = data or {} }) end)

RegisterNUICallback('lookupOrgEmployee', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:lookupOrgEmployee', tabletOrgKey, tonumber(data and data.serverId))
    cb({ success = true })
end)
RegisterNUICallback('lookupOrgEmployeeManagement', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:lookupOrgEmployeeManagement', tabletOrgKey, tonumber(data and data.serverId))
    cb({ success = true })
end)

RegisterNUICallback('lookupGeneralPerson', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:lookupGeneralPerson', tabletOrgKey, tonumber(data and data.serverId))
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:generalPersonResult', function(result)
    SendNUIMessage({ action = 'generalPersonResult', result = result or {} })
end)
RegisterNetEvent('universal_identity:orgEmployeeRankUpdated', function(data)
    data = data or {}
    data.isCurrentUser = tonumber(data.targetId) == GetPlayerServerId(PlayerId())
    SendNUIMessage({ action = 'orgEmployeeRankUpdated', data = data })
end)

RegisterNUICallback('manageOrgEmployeeJob', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:manageOrgEmployeeJob', tabletOrgKey, tonumber(data and data.serverId), tostring(data and data.action or ''), tonumber(data and data.gradeLevel))
    cb({ success = true })
end)
RegisterNUICallback('deleteOrgAnnouncement', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:deleteOrgAnnouncement', tabletOrgKey, tonumber(data and data.id))
    cb({ success = true })
end)

RegisterNUICallback('publishOrgAnnouncement', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:publishOrgAnnouncement', tabletOrgKey, tostring(data and data.title or ''), tostring(data and data.body or ''))
    cb({ success = true })
end)
RegisterNUICallback('markOrgAnnouncementsRead', function(_, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:markOrgAnnouncementsRead', tabletOrgKey)
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:orgAnnouncementsData', function(rows, canPublish, published, unreadCount)
    SendNUIMessage({ action = 'orgAnnouncementsData', rows = rows or {}, canPublish = canPublish == true, published = published == true, unreadCount = tonumber(unreadCount) or 0 })
end)
RegisterNetEvent('universal_identity:orgAnnouncementDeleteResult', function(success, announcementId, message)
    SendNUIMessage({ action = 'orgAnnouncementDeleteResult', success = success == true, announcementId = tonumber(announcementId), message = tostring(message or '') })
end)
RegisterNUICallback('submitOrgNote', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:submitOrgNote', tabletOrgKey, tonumber(data and data.serverId), '', tostring(data and data.note or ''))
    cb({ success = true })
end)
RegisterNetEvent('universal_identity:orgNoteResult', function(result)
    SendNUIMessage({ action = 'orgNoteResult', result = result or {} })
end)
RegisterNetEvent('universal_identity:tabletEmployeeJobResult', function(result)
    SendNUIMessage({ action = 'orgEmployeeJobResult', result = result or {} })
end)

RegisterNUICallback('issueOrgEmployee', function(data, cb)
    if not tabletOpen or not tabletOrgKey then cb({ success = false }); return end
    TriggerServerEvent('universal_identity:issueOrgDocument', tabletOrgKey, tonumber(data and data.serverId), tostring(data and data.rankLabel or ''), tostring(data and data.documentType or 'organisation_id'), data and data.personalIdConfirmed == true, data and data.permitFeeHandedOver == true, data and data.recruitment == true)
    cb({ success = true })
end)


RegisterCommand('uidtestpersonalausweis', function()
    if Config.Documents.PreviewEnabled == false then notify('Kartenvorschau ist deaktiviert.', 'error'); return end
    TriggerServerEvent('universal_identity:requestCardPreview', 'personal_id')
end, false)

RegisterCommand('uidtestdienstausweis', function()
    if Config.Documents.PreviewEnabled == false then notify('Kartenvorschau ist deaktiviert.', 'error'); return end
    TriggerServerEvent('universal_identity:requestCardPreview', 'organisation_id')
end, false)

RegisterCommand('uidpreview', function()
    if Config.Documents.PreviewEnabled == false then notify('Kartenvorschau ist deaktiviert.', 'error'); return end
    TriggerServerEvent('universal_identity:requestCardPreview', nil)
end, false)

local function drawText3D(x, y, z, text)
    local onScreen, sx, sy = World3dToScreen2d(x, y, z)
    if not onScreen then return end
    SetTextScale(0.34, 0.34); SetTextFont(4); SetTextProportional(1)
    SetTextColour(255, 255, 255, 230); SetTextCentre(true); SetTextOutline()
    BeginTextCommandDisplayText('STRING'); AddTextComponentSubstringPlayerName(text); EndTextCommandDisplayText(sx, sy)
end

CreateThread(function()
    Wait(1800)
    TriggerServerEvent('universal_identity:requestDocumentLocations')
    while true do
        local sleep = 1000
        if not tabletOpen and not documentsOpen then
            if not targetMode then
            local ped = PlayerPedId()
            local coords = GetEntityCoords(ped)
            local maxDraw = Config.Documents.PickupDrawDistance or 20.0
            for _, loc in ipairs(pickupLocations) do
                local pos = vector3(tonumber(loc.x) or 0, tonumber(loc.y) or 0, tonumber(loc.z) or 0)
                local dist = #(coords - pos)
                if dist <= maxDraw then
                    sleep = 0
                    if Config.PhotoStation.Marker then DrawMarker(2, pos.x, pos.y, pos.z + 0.12, 0.0,0.0,0.0,0.0,180.0,0.0,0.22,0.22,0.22,60,170,255,180,false,true,2,false,nil,nil,false) end
                    if dist <= (Config.Documents.PickupInteractionDistance or 2.0) then
                        if tostring(loc.station_type or 'police') == 'personal' then
                            drawText3D(pos.x, pos.y, pos.z + 0.04, '[H] Personalausweis abholen')
                            if IsControlJustReleased(0, 74) then TriggerServerEvent('universal_identity:collectPersonalId'); Wait(700) end
                        elseif hasValidPoliceRank() then
                            drawText3D(pos.x, pos.y, pos.z + 0.22, '[E] Dienstausweis abholen')
                            drawText3D(pos.x, pos.y, pos.z + 0.04, '[G] Waffenschein abholen')
                            if IsControlJustReleased(0, 38) then TriggerServerEvent('universal_identity:collectOrgDocument'); Wait(700)
                            elseif IsControlJustReleased(0, 47) then TriggerServerEvent('universal_identity:collectWeaponPermit'); Wait(700) end
                        end
                    end
                end
            end
            for _, pc in ipairs(orgPcs) do
                local pos = vector3(tonumber(pc.x) or 0, tonumber(pc.y) or 0, tonumber(pc.z) or 0)
                local dist = #(coords - pos)
                if dist <= (Config.Documents.OrgPcDrawDistance or 20.0) then
                    sleep = 0
                    if Config.PhotoStation.Marker then DrawMarker(2, pos.x, pos.y, pos.z + 0.12, 0.0,0.0,0.0,0.0,180.0,0.0,0.22,0.22,0.22,180,180,255,180,false,true,2,false,nil,nil,false) end
                    if dist <= (Config.Documents.OrgPcInteractionDistance or 2.0) then
                        local org = Config.Documents.Organisations[pc.org_key]
                        drawText3D(pos.x, pos.y, pos.z + 0.4, '[E] '..(org and org.label or pc.name or 'Organisations-Tablet'))
                        if IsControlJustReleased(0, 38) then TriggerServerEvent('universal_identity:openOrgTablet', pc.org_key); Wait(700) end
                    end
                end
            end
            end
        else
            sleep = 0
            DisableControlAction(0, 1, true); DisableControlAction(0, 2, true)
            DisableControlAction(0, 200, true)
        end
        Wait(sleep)
    end
end)

RegisterCommand('uidwaffenschein', function() TriggerServerEvent('universal_identity:applyWeaponPermit') end, false)

RegisterCommand('uidgiveorg', function(_, args)
    local targetId = tonumber(args[1])
    if not targetId then
        notify('Verwendung: /uidgiveorg [Server-ID des vorgesehenen Mitarbeiters]', 'error')
        return
    end
    TriggerServerEvent('universal_identity:giveOrgDocument', targetId)
end, false)

RegisterCommand('uidtablet', function(_, args)
    local orgKey = args[1]
    if not orgKey then notify('Verwendung: /uidtablet organisationsKey', 'error'); return end
    TriggerServerEvent('universal_identity:openOrgTablet', orgKey)
end, false)

CreateThread(function()
    Wait(2000)
    TriggerServerEvent('universal_identity:requestDocumentLocations')
end)


-- Admin tablet callbacks (all destructive actions are re-authorized server-side).
RegisterNetEvent('universal_identity:openAdminTablet', function()
    -- Nur ein echtes Server-Event darf das Admin-Tablet öffnen; lokale TriggerEvent-Aufrufe werden ignoriert.
    if source ~= 65535 then return end
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openAdminTablet' })
    TriggerServerEvent('universal_identity:adminTabletRequest')
end)
RegisterNetEvent('universal_identity:adminTabletData', function(data)
    SendNUIMessage({ action = 'adminTabletData', data = data or {} })
end)
RegisterNetEvent('universal_identity:adminTabletFeedback', function(message, success)
    SendNUIMessage({ action = 'adminTabletFeedback', message = message or '', success = success == true })
end)
RegisterNetEvent('universal_identity:adminOrgNoteAdded', function(note)
    SendNUIMessage({ action = 'adminOrgNoteAdded', note = note or {} })
end)
RegisterNUICallback('closeAdminTablet', function(_, cb)
    -- Das Polizeisystem wurde vor dem Öffnen des Admin-Tablets geschlossen.
    -- Beim Schließen des Admin-Tablets daher immer den NUI-Fokus vollständig freigeben.
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    cb({ success = true })
end)
RegisterNUICallback('adminTabletAction', function(data, cb)
    TriggerServerEvent('universal_identity:adminTabletAction', data or {})
    cb({ success = true })
end)
-- Persönliche Dokumentenmappe / Kartenansicht
-- Öffnet die echte Dokumentenmappe des Charakters (keine Testkarten-Vorschau).
RegisterCommand('uidzeigen', function(_, args)
    local first = tostring(args[1] or ''):lower()
    local requestedType = tonumber(first) and tostring(args[2] or ''):lower() or first
    if requestedType == '' then
        TriggerEvent('universal_identity:openMyDocuments')
        return
    end
    local aliases = {
        personalausweis = 'personal_id', personal_id = 'personal_id',
        dienstausweis = 'organisation_id', organisation_id = 'organisation_id',
        waffenschein = 'weapon_permit', weapon_permit = 'weapon_permit',
        angelschein = 'fishing_license', fishing_license = 'fishing_license',
        bootsfuehrerschein = 'boat_license', boot = 'boat_license', boat_license = 'boat_license',
        pilotenschein = 'pilot_license', pilot_license = 'pilot_license'
    }
    local docType = aliases[requestedType]
    if not docType then
        notify('Verwendung: /uidzeigen [personalausweis|dienstausweis|waffenschein|angelschein|bootsfuehrerschein|pilotenschein]', 'error')
        return
    end
    TriggerServerEvent('universal_identity:requestOwnDocumentView', docType)
end, false)

RegisterNetEvent('universal_identity:openShownDocument', function(data)
    documentsOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openMyDocuments' })
    SendNUIMessage({ action = 'myDocumentsData', data = data or {} })
end)

RegisterCommand('uiddocuments', function()
    TriggerEvent('universal_identity:openMyDocuments')
end, false)

RegisterNetEvent('universal_identity:openMyDocuments', function()
    documentsOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openMyDocuments' })
    TriggerServerEvent('universal_identity:requestMyDocuments')
end)
RegisterNetEvent('universal_identity:myDocumentsData', function(data)
    SendNUIMessage({ action = 'myDocumentsData', data = data or {} })
end)

RegisterNUICallback('showDocumentToNearbyPlayer', function(data, cb)
    local requestedType = tostring(data and data.documentType or '')
    local myPed = PlayerPedId()
    local myCoords = GetEntityCoords(myPed)
    local closestServerId, closestDistance = nil, 3.0
    for _, player in ipairs(GetActivePlayers()) do
        if player ~= PlayerId() then
            local ped = GetPlayerPed(player)
            if ped and ped ~= 0 then
                local distance = #(GetEntityCoords(ped) - myCoords)
                if distance < closestDistance then
                    closestDistance = distance
                    closestServerId = GetPlayerServerId(player)
                end
            end
        end
    end
    if not closestServerId then
        notify('Kein anderer Spieler in deiner Nähe (maximal 3 Meter).', 'error')
        cb({ success = false })
        return
    end
    TriggerServerEvent('universal_identity:showDocumentToPlayer', closestServerId, requestedType)
    cb({ success = true })
end)

RegisterNUICallback('closeMyDocuments', function(_, cb)
    documentsOpen = false
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    cb({ success = true })
end)


