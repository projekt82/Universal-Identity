print('[Universal Photos] Client loaded.')

CreateThread(function()
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    SendNUIMessage({ action = 'close' })
end)

local function Notify(message)
    local ok, QBCore = pcall(function()
        return exports['qb-core']:GetCoreObject()
    end)

    if ok and QBCore and QBCore.Functions and QBCore.Functions.Notify then
        QBCore.Functions.Notify(tostring(message), 'primary', 5000)
    else
        print('[Universal Photos] ' .. tostring(message))
    end
end

RegisterCommand('setphotostation', function()
    TriggerServerEvent('universal_identity:adminSetPhotoStation')
end, false)

RegisterCommand('listphotostations', function()
    TriggerServerEvent('universal_identity:adminListPhotoStations')
end, false)

RegisterCommand('deletephotostation', function(_, args)
    local stationId = tonumber(args[1])
    if not stationId or stationId < 1 or stationId % 1 ~= 0 then
        Notify('Verwendung: /deletephotostation ID — zuerst /listphotostations nutzen.')
        return
    end
    TriggerServerEvent('universal_identity:adminDeletePhotoStation', stationId)
end, false)

RegisterCommand('uidphotostatus', function()
    TriggerServerEvent('universal_identity:requestPhotoStatus')
end, false)

RegisterNetEvent('universal_identity:stationCommandResult', function(message)
    Notify(message)
end)

-- Eigenständige, vom Server autorisierte Taste für das Admin-Tablet.
-- Die Serverprüfung bleibt maßgeblich; normale Spieler erhalten keinen Zugriff.
RegisterCommand('uid_admin_tablet', function()
    TriggerServerEvent('universal_identity:requestOpenAdminTablet')
end, false)
RegisterKeyMapping('uid_admin_tablet', 'Universal Identity: Admin-Tablet öffnen', 'keyboard', 'F10')
