
-- =========================================================
-- UNIVERSAL IDENTITY
-- FOTOSTATION, FOTO-SPEICHERUNG UND FOTO-LADEN
-- CLIENT
-- =========================================================

local PhotoStations = {}
local PhotoStationLoaded = false

local CameraActive = false
local TestCamera = nil

local PhotoProcessing = false
local PhotoPreviewActive = false
local PhotoSaving = false
local CurrentPhoto = nil
local SavedPhotoPanelActive = false

local INTERACTION_DISTANCE = 2.0
local DRAW_DISTANCE = 20.0

-- =========================================================
-- FOTOSTATIONEN ANFORDERN
-- =========================================================

CreateThread(function()
    Wait(1000)

    print('[Universal Identity] Fotostationsystem wird gestartet.')
    TriggerServerEvent('universal_identity:requestPhotoStations')
    print('[Universal Identity] Fordere Fotostationen vom Server an.')
end)

-- =========================================================
-- FOTOSTATIONEN EMPFANGEN
-- =========================================================

RegisterNetEvent('universal_identity:receivePhotoStations', function(stations)
    PhotoStations = stations or {}
    PhotoStationLoaded = true

    print(('[Universal Identity] %s Fotostation(en) geladen.'):format(
        #PhotoStations
    ))
end)

RegisterNetEvent('universal_identity:photoStationCreated', function(_stationId)
    print('[Universal Identity] Fotostation erstellt.')

    -- Die aktuelle Stationsliste wird serverseitig an alle Clients gesendet.
    -- Deshalb hier keine zweite Anfrage auslösen.
end)

-- =========================================================
-- 3D-TEXT
-- =========================================================

local function DrawText3D(x, y, z, text)
    local onScreen, screenX, screenY = World3dToScreen2d(x, y, z)

    if not onScreen then
        return
    end

    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 255)
    SetTextCentre(true)
    SetTextOutline()

    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(screenX, screenY)
end

-- =========================================================
-- FOTOSTATION-MARKER
-- =========================================================

local function DrawPhotoStationMarker(x, y, z)
    DrawMarker(
        2,
        x, y, z + 0.15,
        0.0, 0.0, 0.0,
        0.0, 180.0, 0.0,
        0.25, 0.25, 0.25,
        255, 255, 255, 180,
        false, true, 2, false, nil, nil, false
    )
end

-- =========================================================
-- KAMERA-HILFSTEXT
-- =========================================================

local function DrawCameraHelpText()
    SetTextFont(4)
    SetTextScale(0.45, 0.45)
    SetTextColour(255, 255, 255, 255)
    SetTextCentre(true)
    SetTextOutline()

    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(
        '[E] Foto aufnehmen    [BACKSPACE] Abbrechen'
    )
    EndTextCommandDisplayText(0.5, 0.92)
end

-- =========================================================
-- KAMERA SCHLIESSEN
-- =========================================================

local function CloseTestCamera()
    if not CameraActive then
        return
    end

    CameraActive = false
    PhotoProcessing = false
    PhotoPreviewActive = false
    PhotoSaving = false

    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)

    local playerPed = PlayerPedId()

    RenderScriptCams(false, true, 500, true, true)

    if TestCamera then
        DestroyCam(TestCamera, false)
        TestCamera = nil
    end

    FreezeEntityPosition(playerPed, false)

    DisplayHud(true)
    DisplayRadar(true)

    SendNUIMessage({
        action = 'closePhotoPreview'
    })

    CurrentPhoto = nil

    print('[Universal Identity] Testkamera geschlossen.')
end

-- =========================================================
-- FOTO-VORSCHAU ÖFFNEN
-- =========================================================

local function OpenPhotoPreview(photoData)
    if not photoData then
        PhotoProcessing = false
        print('[Universal Identity] Fehler: Keine Bilddaten für die Vorschau.')
        return
    end

    CurrentPhoto = nil
    PhotoProcessing = true
    PhotoPreviewActive = false

    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)

    SendNUIMessage({
        action = 'preparePhotoCrop',
        image = photoData
    })

    print('[Universal Identity] Foto wird auf festen 7:9-Ausschnitt zugeschnitten.')
end

-- =========================================================
-- FOTO BESTÄTIGEN UND AN SERVER SENDEN
-- =========================================================

local function ConfirmPhoto()
    if not PhotoPreviewActive or not CurrentPhoto or PhotoSaving then
        return false
    end

    PhotoSaving = true

    SendNUIMessage({
        action = 'photoSaving',
        message = 'Foto wird gespeichert ... bitte warten.'
    })

    print('[Universal Identity] Foto wurde bestätigt.')
    print('[Universal Identity] Gespeichert wird exakt der Vorschau-Ausschnitt.')
    print('[Universal Identity] Sende Foto zum Speichern an den Server ...')

    TriggerServerEvent(
        'universal_identity:saveCharacterPhoto',
        CurrentPhoto
    )

    return true
end

-- =========================================================
-- FOTO VERWERFEN
-- =========================================================

local function RejectPhoto()
    if not PhotoPreviewActive or PhotoSaving then
        return false
    end

    print('[Universal Identity] Foto wurde verworfen.')

    PhotoPreviewActive = false
    CurrentPhoto = nil
    PhotoProcessing = false

    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)

    SendNUIMessage({
        action = 'closePhotoPreview'
    })

    if TestCamera and CameraActive then
        SetCamActive(TestCamera, true)
        RenderScriptCams(true, false, 0, true, true)
    end

    return true
end

-- =========================================================
-- NUI: ZUGESCHNITTENES FOTO EMPFANGEN
-- =========================================================

RegisterNUICallback('photoCropped', function(data, cb)
    if not data or type(data.image) ~= 'string' then
        print('[Universal Identity] Fehler: Kein zugeschnittenes Foto erhalten.')

        PhotoProcessing = false
        cb({ success = false })
        return
    end

    CurrentPhoto = data.image
    PhotoProcessing = false
    PhotoPreviewActive = true

    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)

    print('[Universal Identity] Fester Fotoausschnitt wurde erstellt.')
    print('[Universal Identity] Vorschau verwendet exakt den späteren Fotoausschnitt.')

    cb({ success = true })
end)

-- =========================================================
-- NUI: FOTO BESTÄTIGEN
-- =========================================================

RegisterNUICallback('confirmPhoto', function(data, cb)
    local success = ConfirmPhoto()
    cb({ success = success == true })
end)

-- =========================================================
-- NUI: FOTO VERWERFEN
-- =========================================================

RegisterNUICallback('rejectPhoto', function(data, cb)
    local success = RejectPhoto()
    cb({ success = success == true })
end)

-- =========================================================
-- GESPEICHERTES CHARAKTERFOTO EMPFANGEN
-- =========================================================

RegisterNetEvent('universal_identity:savedPhotoLoaded', function(photoData)
    if not photoData then
        print('[Universal Identity] Für diesen Charakter wurde kein gespeichertes Foto gefunden.')

        SendNUIMessage({
            action = 'savedPhotoResult',
            success = false,
            message = 'Kein gespeichertes Foto gefunden.'
        })

        return
    end

    if type(photoData) ~= 'string'
        or not photoData:match('^data:image/jpeg;base64,') then

        print('[Universal Identity] Fehler: Der Server hat ungültige Fotodaten zurückgegeben.')

        SendNUIMessage({
            action = 'savedPhotoResult',
            success = false,
            message = 'Das geladene Foto hat ein ungültiges Format.'
        })

        return
    end

    CurrentPhoto = photoData
    SavedPhotoPanelActive = true

    print('[Universal Identity] Gespeichertes Charakterfoto erfolgreich vom Server empfangen.')

    SendNUIMessage({
        action = 'showSavedPhoto',
        image = photoData
    })
end)

-- Der frühere Testbefehl /uidfototest wurde entfernt.

-- =========================================================
-- GESPEICHERTES FOTO-FENSTER SCHLIESSEN
-- =========================================================

RegisterNUICallback('closeSavedPhoto', function(data, cb)
    SavedPhotoPanelActive = false
    CurrentPhoto = nil

    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)

    SendNUIMessage({
        action = 'closeSavedPhoto'
    })

    cb({ success = true })

    print('[Universal Identity] Gespeicherte Fotoansicht geschlossen.')
end)

-- =========================================================
-- SERVER-ANTWORT AUF FOTO-SPEICHERUNG
-- =========================================================

RegisterNetEvent('universal_identity:photoSaveResult', function(success, result)
    PhotoSaving = false

    if success then
        print(('[Universal Identity] Foto erfolgreich gespeichert: %s'):format(
            tostring(result)
        ))

        SendNUIMessage({
            action = 'photoStatus',
            success = true,
            message = 'Foto erfolgreich gespeichert.'
        })

        CloseTestCamera()
        return
    end

    print(('[Universal Identity] FEHLER beim Speichern des Fotos: %s'):format(
        tostring(result or 'Unbekannter Fehler')
    ))

    PhotoPreviewActive = true

    SetNuiFocus(true, true)
    SetNuiFocusKeepInput(false)

    SendNUIMessage({
        action = 'photoStatus',
        success = false,
        message = 'Speichern fehlgeschlagen: ' .. tostring(result or 'Unbekannter Fehler')
    })
end)

-- =========================================================
-- FOTO AUFNEHMEN
-- =========================================================

local function TakePhoto()
    if not CameraActive or PhotoProcessing or PhotoSaving then
        return
    end

    -- Aufnahme sofort sperren.
    -- Dadurch zeichnet der Kameraloop den Hilfstext nicht mehr.
    PhotoProcessing = true

    print('[Universal Identity] Fotoaufnahme gestartet.')

    -- Dem Spiel einige Frames Zeit geben, den Hilfstext auszublenden.
    Wait(300)

    exports['screenshot-basic']:requestScreenshot({
        encoding = 'jpg',
        quality = 0.92
    }, function(data)
        if not data then
            PhotoProcessing = false
            print('[Universal Identity] FEHLER: Foto konnte nicht aufgenommen werden.')
            return
        end

        print('[Universal Identity] Foto aufgenommen.')

        -- Kameraansicht beenden
        RenderScriptCams(false, false, 0, true, true)

        -- Foto-Vorschau öffnen
        OpenPhotoPreview(data)
    end)
end

-- =========================================================
-- TESTKAMERA ÖFFNEN
-- =========================================================

local function OpenTestCamera()
    if CameraActive or SavedPhotoPanelActive then
        return
    end

    local playerPed = PlayerPedId()

    if not DoesEntityExist(playerPed) then
        return
    end

    CameraActive = true
    PhotoProcessing = false
    PhotoPreviewActive = false
    PhotoSaving = false
    CurrentPhoto = nil

    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)

    FreezeEntityPosition(playerPed, true)

    local playerCoords = GetEntityCoords(playerPed)
    local playerHeading = GetEntityHeading(playerPed)
    local headingRadians = math.rad(playerHeading)

    local cameraDistance = 1.0
    local cameraHeight = 0.70
    local targetHeight = 0.70

    local cameraX = playerCoords.x
        - math.sin(headingRadians) * cameraDistance

    local cameraY = playerCoords.y
        + math.cos(headingRadians) * cameraDistance

    local cameraZ = playerCoords.z + cameraHeight

    TestCamera = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)

    SetCamCoord(TestCamera, cameraX, cameraY, cameraZ)

    PointCamAtCoord(
        TestCamera,
        playerCoords.x,
        playerCoords.y,
        playerCoords.z + targetHeight
    )

    SetCamFov(TestCamera, 50.0)
    SetCamActive(TestCamera, true)

    RenderScriptCams(true, true, 500, true, true)

    DisplayHud(false)
    DisplayRadar(false)

    print('[Universal Identity] Testkamera geöffnet.')
end

-- =========================================================
-- KAMERA- UND VORSCHAU-LOOP
-- =========================================================

CreateThread(function()
    while true do
        if PhotoPreviewActive then
            Wait(0)

            -- Blockiert Spielsteuerung und Mausblick im Hintergrund.
            -- Die Maus kann weiterhin die fokussierte NUI bedienen.
            DisableAllControlActions(0)

        elseif CameraActive then
            Wait(0)

            -- WICHTIG:
            -- Hilfstext nicht zeichnen, solange die Aufnahme läuft.
            if not PhotoProcessing then
                DrawCameraHelpText()
            end

            if IsControlJustReleased(0, 38) and not PhotoProcessing then
                TakePhoto()
            end

            if IsControlJustReleased(0, 177) and not PhotoProcessing then
                CloseTestCamera()
            end

        else
            Wait(500)
        end
    end
end)

-- =========================================================
-- FOTOSTATION-INTERAKTION
-- =========================================================

CreateThread(function()
    while true do
        local sleep = 1000

        if PhotoStationLoaded
            and #PhotoStations > 0
            and not CameraActive
            and not SavedPhotoPanelActive then

            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)

            local closestStation = nil
            local closestDistance = nil

            for _, station in ipairs(PhotoStations) do
                local stationX = tonumber(station.x)
                local stationY = tonumber(station.y)
                local stationZ = tonumber(station.z)

                if stationX and stationY and stationZ then
                    local stationCoords = vector3(stationX, stationY, stationZ)
                    local distance = #(playerCoords - stationCoords)

                    if distance <= DRAW_DISTANCE then
                        sleep = 0

                        DrawPhotoStationMarker(stationX, stationY, stationZ)

                        if not closestDistance or distance < closestDistance then
                            closestDistance = distance
                            closestStation = station
                        end
                    end
                end
            end

            if closestStation
                and closestDistance
                and closestDistance <= INTERACTION_DISTANCE then

                sleep = 0

                local stationX = tonumber(closestStation.x)
                local stationY = tonumber(closestStation.y)
                local stationZ = tonumber(closestStation.z)

                DrawText3D(
                    stationX,
                    stationY,
                    stationZ + 0.5,
                    '[E] Fotostation benutzen'
                )

                if IsControlJustReleased(0, 38) then
                    print('[Universal Identity] Fotostation mit E aktiviert.')

                    print(('[Universal Identity] Fotostation ID: %s'):format(
                        tostring(closestStation.id)
                    ))

                    print(('[Universal Identity] Position: %.4f, %.4f, %.4f'):format(
                        stationX,
                        stationY,
                        stationZ
                    ))

                    OpenTestCamera()
                end
            end
        end

        Wait(sleep)
    end
end)