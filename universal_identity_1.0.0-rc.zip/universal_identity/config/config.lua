Config = Config or {}

Config.Debug = false
Config.AdminAcePermission = 'universal_identity.admin'

Config.PhotoStation = {
    InteractionDistance = 2.0,
    DrawDistance = 20.0,
    Marker = true
}

Config.Photo = {
    Width = 700,
    Height = 900,
    MaxDataUrlBytes = 1500000,
    MaxImageBytes = 1100000,
    SaveCooldownSeconds = 5
}

-- Personal ID is created as soon as a character photo has been confirmed.
Config.Documents = {
    PersonalIdItem = 'universal_personal_id',
    OrganisationIdItem = 'universal_org_id',
    PreviewEnabled = true,
    DeleteLocationDistance = 1.5,
    UseTarget = true, -- uses qb-target/ox_target when started; otherwise falls back to E + marker
    TargetSystem = 'auto', -- 'auto' (qb-target preferred), 'qb-target' or 'ox_target'
    PickupInteractionDistance = 2.0,
    PickupDrawDistance = 20.0,
    OrgPcInteractionDistance = 2.0,
    OrgPcDrawDistance = 20.0,
    RequirePhotoForOrganisationId = true,
    RequirePersonalIdForOrganisationId = true,
    RequireSameOrganisationForIssuer = true,
    -- Release-Standard: Testmodus AUS. Ein Serveradmin kann ihn im Admin-Tablet
    -- gezielt aktivieren, um ausschließlich eigene Dokumente zu testen.
    -- Die Freelancer-Testrolle ist im öffentlichen Paket nicht verfügbar.
    PoliceTestMode = false,
    AllowSelfIssueForTesting = true,
    AllowSelfRecruitForTesting = false,
    AllowSelfPromoteForTesting = false,
    AllowSelfTerminationForTesting = false,
    AllowSelfDeputyForTesting = false,
    AllowRemoteDocumentShowForTesting = false,
    -- Gebühren für einen selbst beantragten Waffenschein. Polizeijob ist kostenlos.
    WeaponPermitApplicationPrice = 6500,
    -- Bei Ausstellung über das Polizeitablet wird kein Geld automatisch abgezogen.
    -- Der Aussteller muss bestätigen, dass der Spieler die Gebühr persönlich übergeben hat.
    WeaponPermitTabletFee = 6500,
    WeaponPermitFreeJobs = {}, -- Der konfigurierte Organisationsjob ist automatisch kostenlos; weitere Jobs optional hier ergänzen.
    OtherTypes = {
        -- Aktuell gewünschte zusätzliche Dokumenttypen. Führerscheine sind vorerst deaktiviert.
        weapon_permit = { label = 'Waffenschein', issuerJobs = {}, item = 'universal_weapon_permit' },
        fishing_license = { label = 'Angelschein', issuerJobs = {}, item = 'universal_fishing_license' },
        boat_license = { label = 'Bootsführerschein', issuerJobs = {}, item = 'universal_boat_license' },
        pilot_license = { label = 'Pilotenschein', issuerJobs = {}, item = 'universal_pilot_license' }
    },
    -- Each key is an organisation key used by /setorgpc.
    -- 'job' must exactly match a key in QBCore.Shared.Jobs (the server's shared/jobs.lua).
    -- Grade IDs and labels are read dynamically from that job's .grades table; do not hardcode rank names.
    -- Example for a server whose police job is named 'lspd': police = { label = 'LSPD', job = 'lspd', minimumGrade = 4 }
    Organisations = {
        police = { label = 'Polizei', job = 'police', minimumGrade = 4, documentRanks = nil } -- Optional: documentRanks = { { grade = 0, label = 'Anwärter' }, { grade = 1, label = 'Officer' } }
    }
}
