fx_version 'cerulean'
game 'gta5'

author 'Universal Identity'
description 'QBCore identity photos, personal IDs and organisation documents'
version '1.0.0-rc.1'

lua54 'yes'

shared_scripts {
    'config/config.lua'
}

client_scripts {
    'client/main.lua',
    'client/photostation.lua',
    'client/documents.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'bridges/qbcore.lua',
    'server/framework.lua',
    'server/main.lua',
    'server/photostations.lua',
    'server/photos.lua',
    'server/documents.lua'
}

ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/style.css',
    'nui/app.js',
}

dependencies {
    'qb-core',
    'oxmysql',
    'screenshot-basic'
}
