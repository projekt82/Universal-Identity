# Integrationen für bestehende Ausweis-Ressourcen

Das Fotosystem stellt folgende serverseitige Exports bereit:

- `GetCharacterPhotoForPlayer(playerSource, callback)` – bevorzugte Methode; holt die CitizenID aus QBCore.
- `GetCharacterPhoto(identifier, callback)` – Foto anhand einer gültigen CitizenID abrufen.

Beide Callbacks erhalten `(photoDataUrl, photoPath)`. `photoDataUrl` ist eine `data:image/jpeg;base64,...`-URL oder `nil`. Die Bilddatei ist ein 700×900-JPEG. Das NUI des Dokumentensystems kann sie mit CSS `object-fit: cover` in sein eigenes Fotofeld einpassen.

Es gibt keinen universellen Weg, fremde Ausweis-Ressourcen ohne Anpassung automatisch zu verändern. Für ein Plug-and-Play-Angebot werden je unterstütztem Ausweis-Script geprüfte Adapter benötigt. Bitte für jeden Adapter den exakten Ressourcennamen und die tatsächliche API/NUI des Drittanbieter-Scripts prüfen.


## QBCore-Items (wichtig gegen "Item fehlt / Inventar voll")

Die Datei `qbcore_items.lua` enthält die sechs Items für die Karten. Kopiere nur die einzelnen Einträge in die bestehende `qb-core/shared/items.lua` innerhalb der vorhandenen Items-Tabelle. Ersetze nicht die ganze Datei. Falls ein Eintrag mit demselben Namen bereits existiert, führe ihn zusammen statt ihn doppelt anzulegen.

Danach `restart qb-core` ist je nach Serveraufbau nicht immer ausreichend; sicherer ist ein kompletter Serverneustart, damit QBCore die Itemdefinitionen neu lädt.

## Vorschau und Admin-Werkzeuge

- `/uidpreview` – zeigt alle sechs Kartendesigns als Vorschau. Nutzt das gespeicherte Charakterfoto, falls vorhanden; die Vorschau stellt keine echten Dokumente aus.
- `/uidhistory` – Admin-only: letzte protokollierte Ausstellungsaktionen.
- `/uidhistory SERVER-ID-ODER-CITIZENID` – Admin-only: Filter nach Identifier oder Namensfragment (bei Online-Spielern ist die CitizenID am zuverlässigsten).
- `/uidrestore DOKUMENT-ID SERVER-ID` – Admin-only: gibt einem online befindlichen Besitzer ein bereits ausgestelltes Dokument erneut, falls es fehlt. Prüft Besitzer, Dokumentstatus und doppelte Items.
- `/uidadmin` – Admin-Tablet; im Dokumente-Bereich ist der letzte Verlauf sichtbar.

Dokumentverlauf wird in `ui_document_audit` protokolliert. Vorhandene Tabellen bleiben erhalten; die Resource legt die Audit-Tabelle selbst an und ergänzt `issued_by_name` bei Bedarf.

## Stationsschutz

Fotostationen, Ausgabestellen und Organisations-PCs können über das Admin-Tablet nur gelöscht werden, wenn der Admin direkt am betreffenden Eintrag steht (standardmäßig maximal 1,5 m). Koordinaten werden in der Tablet-Liste nicht mehr angezeigt.


## Kartenbilder für QBCore-Inventar

Die sechs PNG-Dateien liegen unter `integrations/item_images/`. Kopiere sie nach:

`qb-inventory/html/images/`

Wenn dein Server ein anderes Inventar nutzt, kopiere die PNG-Dateien in dessen Inventar-Bildordner. Die Dateinamen müssen exakt zu `image = '…'` in `qb-core/shared/items.lua` passen.

Die Bilder sind Inventar-Icons im Querformat 512 × 324 Pixel (Seitenverhältnis ca. 1,58:1). Sie enthalten eine neutrale Foto-Platzhalterfläche. Das eigentliche Charakterfoto wird vom Dokumenten-/Fotosystem geladen und nicht in diese statischen Item-Icons eingebrannt.
