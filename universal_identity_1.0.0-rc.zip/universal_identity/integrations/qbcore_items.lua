-- UNIVERSAL IDENTITY: QBCore items
-- Diese Einträge in qb-core/shared/items.lua in die bestehende Items-Tabelle einfügen.
-- Nicht die gesamte items.lua ersetzen. Wenn ein Itemname schon existiert, keinen zweiten Eintrag anlegen.

['universal_personal_id'] = {
    name = 'universal_personal_id', label = 'Personalausweis', weight = 0, type = 'item',
    image = 'universal_personal_id.png', unique = true, useable = true, shouldClose = true,
    description = 'Persönlicher Ausweis mit Charakterfoto und eindeutiger Dokumentennummer.'
},
['universal_org_id'] = {
    name = 'universal_org_id', label = 'Dienstausweis', weight = 0, type = 'item',
    image = 'universal_org_id.png', unique = true, useable = true, shouldClose = true,
    description = 'Organisationsausweis mit Organisation, Rang und Charakterfoto.'
},
['universal_weapon_permit'] = {
    name = 'universal_weapon_permit', label = 'Waffenschein', weight = 0, type = 'item',
    image = 'universal_weapon_permit.png', unique = true, useable = true, shouldClose = true,
    description = 'Ausgestellter Waffenschein.'
},
['universal_fishing_license'] = {
    name = 'universal_fishing_license', label = 'Angelschein', weight = 0, type = 'item',
    image = 'universal_fishing_license.png', unique = true, useable = true, shouldClose = true,
    description = 'Ausgestellter Angelschein.'
},
['universal_boat_license'] = {
    name = 'universal_boat_license', label = 'Bootsführerschein', weight = 0, type = 'item',
    image = 'universal_boat_license.png', unique = true, useable = true, shouldClose = true,
    description = 'Ausgestellter Bootsführerschein.'
},
['universal_pilot_license'] = {
    name = 'universal_pilot_license', label = 'Pilotenschein', weight = 0, type = 'item',
    image = 'universal_pilot_license.png', unique = true, useable = true, shouldClose = true,
    description = 'Ausgestellter Pilotenschein.'
},
