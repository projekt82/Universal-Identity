
"use strict";

// =========================================================
// UNIVERSAL IDENTITY - NUI
// FOTO-VORSCHAU UND GESPEICHERTES CHARAKTERFOTO
// =========================================================

const testPanel = document.getElementById("test");

const photoPreview = document.getElementById("photoPreview");
const photoImage = document.getElementById("photoImage");
const confirmPhotoButton = document.getElementById("confirmPhotoButton");
const rejectPhotoButton = document.getElementById("rejectPhotoButton");
const photoPreviewStatus = document.getElementById("photoPreviewStatus");

const savedPhotoPanel = document.getElementById("savedPhotoPanel");
const savedPhotoImage = document.getElementById("savedPhotoImage");
const savedPhotoContainer = document.getElementById("savedPhotoContainer");
const savedPhotoMessage = document.getElementById("savedPhotoMessage");
const savedPhotoStatus = document.getElementById("savedPhotoStatus");
const closeSavedPhotoButton = document.getElementById("closeSavedPhotoButton");
const savedPhotoCloseAction = document.getElementById("savedPhotoCloseAction");
const orgTablet = document.getElementById("orgTablet");
const orgTabletTitle = document.getElementById("orgTabletTitle");
const closeOrgTabletButton = document.getElementById("closeOrgTablet");
const orgResizeHandle = document.getElementById("orgResizeHandle");
if (orgResizeHandle && orgTablet) {
  let resizeState = null;
  orgResizeHandle.addEventListener("pointerdown", (event) => {
    const device = orgResizeHandle.closest(".org-device");
    if (!device) return;
    const rect = device.getBoundingClientRect();
    resizeState = { x: event.clientX, y: event.clientY, width: rect.width, height: rect.height };
    orgResizeHandle.setPointerCapture?.(event.pointerId);
    event.preventDefault();
  });
  orgResizeHandle.addEventListener("pointermove", (event) => {
    if (!resizeState) return;
    const device = orgResizeHandle.closest(".org-device");
    if (!device) return;
    const width = Math.max(900, Math.min(window.innerWidth - 48, resizeState.width + event.clientX - resizeState.x));
    const height = Math.max(580, Math.min(window.innerHeight - 48, resizeState.height + event.clientY - resizeState.y));
    device.style.width = `${width}px`; device.style.height = `${height}px`;
    event.preventDefault();
  });
  const stopOrgResize = () => { resizeState = null; };
  orgResizeHandle.addEventListener("pointerup", stopOrgResize);
  orgResizeHandle.addEventListener("pointercancel", stopOrgResize);
}

const orgTargetId = document.getElementById("orgTargetId");
const orgLookupButton = document.getElementById("orgLookupButton");
const orgLookupStatus = document.getElementById("orgLookupStatus");
const orgPreview = document.getElementById("orgPreview");
const orgPreviewPhoto = document.getElementById("orgPreviewPhoto");
const orgPreviewName = document.getElementById("orgPreviewName");
const orgPreviewOrg = document.getElementById("orgPreviewOrg");
const orgPreviewRank = document.getElementById("orgPreviewRank");
const orgPreviewDocument = document.getElementById("orgPreviewDocument");
const orgIssueButton = document.getElementById("orgIssueButton");
const orgDocumentRank = document.getElementById("orgDocumentRank");
const orgDocumentType = document.getElementById("orgDocumentType");
const orgHireEmployee = document.getElementById("orgHireEmployee");
const orgPersonalIdConfirmed = document.getElementById("orgPersonalIdConfirmed");
const orgPermitFeeReceived = document.getElementById("orgPermitFeeReceived");
const orgPermitFeeInfo = document.getElementById("orgPermitFeeInfo");
let orgTargetJobName = "";
let orgTargetIsOrgMember = false;
let orgAdminSelfTest = false;
let orgTargetCanRecruit = false;
let orgWeaponPermitFee = 6500;
let orgPersonalIdValid = false;

function updateOrgIssueButtonState() {
    if (!orgIssueButton) return;
    const isOrgId = String(orgDocumentType?.value || "organisation_id") === "organisation_id";
    const rankReady = !!orgDocumentRank && !orgDocumentRank.disabled && String(orgDocumentRank.value || "").trim() !== "";
    const recruitmentReady = orgTargetIsOrgMember || orgTargetCanRecruit;
    const feeReady = orgTargetIsOrgMember || orgWeaponPermitFee <= 0 || orgPermitFeeReceived?.checked === true;
    const ready = orgTargetCanIssue === true
        && orgPersonalIdValid === true
        && orgPersonalIdConfirmed?.checked === true
        && (isOrgId ? rankReady && recruitmentReady : feeReady);
    orgIssueButton.disabled = !ready;
}
const orgDeputyId = document.getElementById("orgDeputyId");
const orgVerifyDeputyButton = document.getElementById("orgVerifyDeputyButton");
const orgDeputyCandidateStatus = document.getElementById("orgDeputyCandidateStatus");
const orgAppointDeputyButton = document.getElementById("orgAppointDeputyButton");
const orgRemoveDeputyButton = document.getElementById("orgRemoveDeputyButton");
const orgDeputyStatus = document.getElementById("orgDeputyStatus");
let orgTargetCanIssue = false;
let orgLastTargetId = null;

let cropInProgress = false;
let photoSaveInProgress = false;

// =========================================================
// NUI-CALLBACK AN LUA SENDEN
// =========================================================

async function postNui(callbackName, payload = {}) {
    try {
        const resourceName =
            typeof GetParentResourceName === "function"
                ? GetParentResourceName()
                : "universal_identity";

        const response = await fetch(
            `https://${resourceName}/${callbackName}`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json; charset=UTF-8"
                },
                body: JSON.stringify(payload)
            }
        );

        return await response.json();
    } catch (error) {
        console.error(
            `[Universal Identity] NUI-Callback "${callbackName}" fehlgeschlagen:`,
            error
        );

        return { success: false };
    }
}

// =========================================================
// ELEMENTE EIN- UND AUSBLENDEN
// =========================================================

function showElement(element, displayValue = "") {
    if (!element) return;

    element.classList.remove("hidden");
    element.style.display = displayValue;
}

function hideElement(element) {
    if (!element) return;

    element.classList.add("hidden");
    element.style.display = "none";
}

// =========================================================
// STATUS DER FOTO-VORSCHAU
// =========================================================

function setPreviewStatus(message, isError = false) {
    if (!photoPreviewStatus) return;

    photoPreviewStatus.textContent = message || "";
    photoPreviewStatus.style.color = isError ? "#ff8a8a" : "";
}

function setPreviewButtonsDisabled(disabled) {
    if (confirmPhotoButton) {
        confirmPhotoButton.disabled = disabled;
        confirmPhotoButton.textContent = disabled
            ? "Foto wird gespeichert ..."
            : "Foto bestätigen";
    }

    if (rejectPhotoButton) {
        rejectPhotoButton.disabled = disabled;
    }
}

// =========================================================
// FOTO ZUSCHNEIDEN
// Festes Seitenverhältnis 7:9
// =========================================================

function cropPhoto(imageData) {
    return new Promise((resolve, reject) => {
        const image = new Image();

        image.onload = () => {
            try {
                const targetWidth = 700;
                const targetHeight = 900;
                const targetRatio = targetWidth / targetHeight;

                let sourceX = 0;
                let sourceY = 0;
                let sourceWidth = image.naturalWidth;
                let sourceHeight = image.naturalHeight;

                const sourceRatio = sourceWidth / sourceHeight;

                if (sourceRatio > targetRatio) {
                    sourceWidth = sourceHeight * targetRatio;
                    sourceX = (image.naturalWidth - sourceWidth) / 2;
                } else {
                    sourceHeight = sourceWidth / targetRatio;
                    sourceY = (image.naturalHeight - sourceHeight) / 2;
                }

                const canvas = document.createElement("canvas");
                canvas.width = targetWidth;
                canvas.height = targetHeight;

                const context = canvas.getContext("2d");

                if (!context) {
                    reject(new Error("Canvas-Kontext konnte nicht erstellt werden."));
                    return;
                }

                context.drawImage(
                    image,
                    sourceX,
                    sourceY,
                    sourceWidth,
                    sourceHeight,
                    0,
                    0,
                    targetWidth,
                    targetHeight
                );

                resolve(canvas.toDataURL("image/jpeg", 0.92));
            } catch (error) {
                reject(error);
            }
        };

        image.onerror = () => {
            reject(new Error("Das aufgenommene Bild konnte nicht geladen werden."));
        };

        image.src = imageData;
    });
}

// =========================================================
// VORSCHAU ANZEIGEN
// =========================================================

function showPhotoPreview(imageData) {
    if (!photoImage || !photoPreview) {
        console.error("[Universal Identity] Vorschau-Elemente fehlen in index.html.");
        return;
    }

    photoImage.src = imageData;

    photoSaveInProgress = false;
    setPreviewButtonsDisabled(false);
    setPreviewStatus("Überprüfe den Bildausschnitt.");

    showElement(photoPreview, "flex");
}

function closePhotoPreview() {
    hideElement(photoPreview);

    if (photoImage) {
        photoImage.removeAttribute("src");
    }

    cropInProgress = false;
    photoSaveInProgress = false;

    setPreviewButtonsDisabled(false);
    setPreviewStatus("");
}

// =========================================================
// FOTO BESTÄTIGEN
// =========================================================

async function confirmPhoto() {
    if (cropInProgress || photoSaveInProgress) return;

    if (!photoImage || !photoImage.src || !photoImage.complete) {
        setPreviewStatus("Das Foto ist noch nicht bereit.", true);
        return;
    }

    photoSaveInProgress = true;
    setPreviewButtonsDisabled(true);
    setPreviewStatus("Foto wird gespeichert ... bitte warten.");

    const result = await postNui("confirmPhoto");

    if (!result || result.success !== true) {
        photoSaveInProgress = false;
        setPreviewButtonsDisabled(false);
        setPreviewStatus(
            "Die Bestätigung konnte nicht gestartet werden. Bitte erneut versuchen.",
            true
        );
    }
}

// =========================================================
// FOTO VERWERFEN
// =========================================================

async function rejectPhoto() {
    if (cropInProgress || photoSaveInProgress) return;

    setPreviewButtonsDisabled(true);
    setPreviewStatus("Vorschau wird geschlossen ...");

    const result = await postNui("rejectPhoto");

    if (!result || result.success !== true) {
        setPreviewButtonsDisabled(false);
        setPreviewStatus(
            "Die Vorschau konnte nicht geschlossen werden. Bitte erneut versuchen.",
            true
        );
    }
}

// =========================================================
// GESPEICHERTES FOTO: STATUS UND ANZEIGE
// =========================================================

function setSavedPhotoMessage(message, isError = false) {
    if (!savedPhotoMessage) return;

    savedPhotoMessage.textContent = message || "";
    savedPhotoMessage.style.color = isError ? "#ff8a8a" : "";
}

function showSavedPhoto(imageData) {
    if (!savedPhotoImage || !savedPhotoContainer) {
        console.error("[Universal Identity] Elemente für gespeichertes Foto fehlen.");
        return;
    }

    savedPhotoImage.onload = () => {
        showElement(savedPhotoContainer, "flex");
        hideElement(savedPhotoMessage);

        if (savedPhotoStatus) {
            savedPhotoStatus.textContent = "Charakterfoto geladen";
        }
    };

    savedPhotoImage.onerror = () => {
        hideElement(savedPhotoContainer);
        showElement(savedPhotoMessage, "block");
        setSavedPhotoMessage("Das gespeicherte Foto konnte nicht angezeigt werden.", true);

        if (savedPhotoStatus) {
            savedPhotoStatus.textContent = "Fehler beim Anzeigen";
        }
    };

    hideElement(savedPhotoContainer);
    showElement(savedPhotoMessage, "block");
    setSavedPhotoMessage("Gespeichertes Foto wird angezeigt ...");

    savedPhotoImage.src = imageData;
    showElement(savedPhotoPanel, "flex");
}

async function closeSavedPhoto() {
    const result = await postNui("closeSavedPhoto");

    if (!result || result.success !== true) {
        console.error("[Universal Identity] Schließen der Fotoansicht wurde nicht bestätigt.");
    }
}

// =========================================================
// BUTTON-EVENTS
// =========================================================

if (confirmPhotoButton) {
    confirmPhotoButton.addEventListener("click", confirmPhoto);
}

if (rejectPhotoButton) {
    rejectPhotoButton.addEventListener("click", rejectPhoto);
}

if (closeSavedPhotoButton) {
    closeSavedPhotoButton.addEventListener("click", closeSavedPhoto);
}

if (savedPhotoCloseAction) {
    savedPhotoCloseAction.addEventListener("click", closeSavedPhoto);
}

// =========================================================
// NUI-NACHRICHTEN VON LUA
// =========================================================

function updateDeputyOverview(deputy) {
  const data = deputy || {};
  const name = document.getElementById("orgDeputyOverviewName");
  const status = document.getElementById("orgDeputyOverviewStatus");
  const dot = document.getElementById("orgDeputyOverviewDot");
  const hasDeputy = Boolean(data.name);
  if (name) name.textContent = hasDeputy ? data.name : "Keine Stellvertretung";
  if (status) status.textContent = hasDeputy ? `Rang: ${data.rank || "Rang unbekannt"} · ${data.online ? "Online" : "Offline"}` : "Es ist niemand eingetragen";
  if (dot) {
    dot.classList.remove("online", "offline", "unknown");
    dot.classList.add(hasDeputy ? (data.online ? "online" : "offline") : "unknown");
  }
}

window.addEventListener("message", async (event) => {
    const data = event.data;

    if (!data || typeof data.action !== "string") {
        return;
    }

    switch (data.action) {
        case "open":
            showElement(testPanel, "block");
            break;

        case "closeAdminTablet":
            hideElement(adminTablet);
            break;

        case "openAdminTablet":
            showElement(adminTablet, "flex");
            document.querySelectorAll(".admin-page").forEach(page => page.classList.toggle("hidden", page.id !== "adminPage-overview"));
            document.querySelectorAll(".admin-nav-btn").forEach(btn => btn.classList.toggle("active", btn.dataset.page === "overview"));
            adminFeedbackSet("Admin-Tablet geöffnet.", true);
            break;

        case "adminTabletData":
            renderAdminData(data.data || {});
            break;

        case "adminTabletFeedback":
            adminFeedbackSet(data.message || "Aktion abgeschlossen.", data.success === true);
            break;
        case "orgPoliceMembersData": renderPoliceMembers(data.members || [], "orgPoliceMembers", data.authorized === true, data.message || ""); break;
        case "orgAnnouncementsData": renderOrgAnnouncements(data.rows || [], data.canPublish === true, Number(data.unreadCount || 0)); if (data.published) { const status = document.getElementById("orgAnnouncementStatus"); if (status) status.textContent = "Bekanntmachung veröffentlicht und für Polizeimitglieder sichtbar."; const titleField = document.getElementById("orgAnnouncementTitle"); if (titleField) titleField.value = ""; const bodyField = document.getElementById("orgAnnouncementText"); if (bodyField) bodyField.value = ""; } break;
        case "orgAnnouncementDeleteResult": { const status = document.getElementById("orgAnnouncementStatus"); if (status) status.textContent = data.message || (data.success ? "Bekanntmachung gelöscht." : "Bekanntmachung konnte nicht gelöscht werden."); if (!data.success) { const buttons = document.querySelectorAll(".announcement-delete-button"); buttons.forEach(button => { if (button.disabled && button.textContent === "Wird gelöscht …") { button.disabled = false; button.textContent = "Bekanntmachung löschen"; } }); } break; }
        case "adminOrgNoteAdded": {
            const note = data.note || {};
            if (!Array.isArray(adminTabletData.notes)) adminTabletData.notes = [];
            if (!adminTabletData.notes.some(item => Number(item.id) === Number(note.id))) adminTabletData.notes.unshift(note);
            adminTabletData.notes = adminTabletData.notes.slice(0, 100);
            renderAdminOrgNotes(adminTabletData.notes);
            break;
        }

        case "openMyDocuments":
            showElement(myDocumentsPanel, "flex");
            myDocumentsStatus.textContent = "Dokumente werden geladen …";
            myDocumentsGrid.replaceChildren();
            break;

        case "myDocumentsData":
            renderMyDocuments(data.data || {});
            break;

        case "policeTestModeState": {
            const testPill = document.getElementById("orgTestModePill"); if (testPill) testPill.classList.toggle("hidden", data.enabled !== true);
            if (data.enabled !== true) { const adminSelfNotice = document.getElementById("orgAdminSelfTestNotice"); if (adminSelfNotice) adminSelfNotice.classList.add("hidden"); orgAdminSelfTest = false; }
            break;
        }

        case "closeOrgTablet":
            hideElement(orgTablet);
            break;

        case "openOrgTablet":
            { const adminEntry = document.getElementById("orgAdminEntry"); if (adminEntry) adminEntry.classList.toggle("hidden", data.isServerAdmin !== true); }
            { const testPill = document.getElementById("orgTestModePill"); if (testPill) testPill.classList.toggle("hidden", data.testMode !== true); }
            { const adminSelfNotice = document.getElementById("orgAdminSelfTestNotice"); if (adminSelfNotice) adminSelfNotice.classList.toggle("hidden", data.adminSelfIssue !== true); }
            if (data.adminSelfIssue === true && orgTargetId && data.serverId) orgTargetId.value = String(data.serverId);
            { const idField = document.getElementById("orgNoteServerId"); if (idField) idField.value = ""; const noteField = document.getElementById("orgNoteText"); if (noteField) noteField.value = ""; const noteStatus = document.getElementById("orgNoteStatus"); if (noteStatus) { noteStatus.textContent = "Die Notiz wird mit deinem Charakter und dem Zeitpunkt gespeichert."; noteStatus.style.color = ""; } const noteButton = document.getElementById("orgNoteSubmit"); if (noteButton) noteButton.disabled = false; }
            orgTargetCanIssue = false;
            orgTargetCanRecruit = false;
            orgTargetIsOrgMember = false;
            orgAdminSelfTest = false;
            if (orgHireEmployee) { orgHireEmployee.checked = false; orgHireEmployee.disabled = true; }
            const hireOptionReset = document.getElementById("orgRecruitmentOption"); if (hireOptionReset) hideElement(hireOptionReset);
            orgLastTargetId = null;
            orgPersonalIdValid = false;
            if (orgPersonalIdConfirmed) { orgPersonalIdConfirmed.checked = false; orgPersonalIdConfirmed.disabled = true; }
            orgTargetId.value = "";
            hideElement(orgPreview);
            orgIssueButton.disabled = true;
            if (orgDocumentRank) { orgDocumentRank.replaceChildren(new Option("Zuerst Mitarbeiter suchen", "")); orgDocumentRank.disabled = true; }
            orgLookupStatus.textContent = data.adminSelfIssue === true ? "Serveradmin-Testmodus: Deine eigene Server-ID ist vorausgefüllt. Bitte suche dich selbst." : "Bitte Mitarbeiter anhand der Server-ID suchen.";
            orgLookupStatus.style.color = "";
            if (data.adminSelfIssue === true && data.serverId) orgTargetId.value = String(data.serverId);
            const peopleStatus = document.getElementById("orgPeopleStatus");
            const fireButton = document.getElementById("orgFireEmployeeButton");
            if (peopleStatus) { peopleStatus.textContent = "Noch kein Mitarbeiter geprüft."; peopleStatus.style.color = ""; }
            if (fireButton) fireButton.disabled = true;
            const peopleActions = document.getElementById("orgPeopleActions"); if (peopleActions) hideElement(peopleActions);
            const firePanel = document.getElementById("orgPeopleFirePanel"); if (firePanel) hideElement(firePanel);
            const jobPanel = document.getElementById("orgPeopleJobPanel"); if (jobPanel) hideElement(jobPanel);
            const reasonField = document.getElementById("orgTerminationReason");
            if (reasonField) reasonField.value = "";
            postNui("requestOrgTerminationLogs");
            orgDeputyVerifiedId = null;
            if (orgAppointDeputyButton) orgAppointDeputyButton.disabled = true;
            if (orgDeputyCandidateStatus) { orgDeputyCandidateStatus.textContent = "Bitte zuerst die Server-ID prüfen."; orgDeputyCandidateStatus.style.color = ""; }
            updateDeputyOverview(data.deputy);
            orgTabletTitle.textContent = "Polizei Organisations System";
            const welcome = document.getElementById("orgWelcomeName"); if (welcome) welcome.textContent = `Willkommen zurück, ${data.issuerName || "Mitarbeiter"}!`;
            const money = data.balances || {}; const cash = document.getElementById("orgCashBalance"); const bank = document.getElementById("orgBankBalance");
            if (cash) cash.textContent = new Intl.NumberFormat("de-DE", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(Number(money.cash || 0));
            if (bank) bank.textContent = new Intl.NumberFormat("de-DE", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(Number(money.bank || 0));
            const currentRank = document.getElementById("orgCurrentUserRank"); if (currentRank) currentRank.textContent = money.rank || "Nicht hinterlegt";
            const hireDate = document.getElementById("orgCurrentUserHireDate"); if (hireDate) hireDate.textContent = `Eintrittsdatum: ${money.hiredAt ? formatDocumentDate(money.hiredAt) : "Nicht hinterlegt"}`;
            if (orgSidebarOrg) orgSidebarOrg.textContent = data.orgLabel || "Organisation";
            showOrgPage("overview");
            const serverClock = document.getElementById("orgServerDateTime");
            if (serverClock) serverClock.textContent = data.serverDateTime || money.serverDateTime || "Serverzeit nicht verfügbar";
            showElement(orgTablet, "flex");
            postNui("requestOrgArchiveMonths");
            break;

        case "orgPermissionDenied": {
            const message = String(data.message || "Du bist für diese Aktion nicht berechtigt.");
            let notice = document.getElementById("orgPermissionNotice");
            if (!notice) {
                notice = document.createElement("div");
                notice.id = "orgPermissionNotice";
                notice.className = "org-permission-notice";
                notice.setAttribute("role", "alert");
                const tablet = document.getElementById("orgTablet");
                (tablet || document.body).appendChild(notice);
            }
            notice.textContent = message;
            notice.classList.add("visible");
            if (notice._hideTimer) clearTimeout(notice._hideTimer);
            notice._hideTimer = setTimeout(() => notice.classList.remove("visible"), 5500);
            break;
        }
        case "orgLookupResult": {
            const result = data.result || {};
            orgLookupStatus.textContent = result.message || (result.success ? "Spieler gefunden." : "Suche fehlgeschlagen.");
            orgLookupStatus.style.color = result.success && result.canIssue ? "#8ee6a1" : "#ff9b9b";
            orgPersonalIdValid = result.success === true && result.personalIdValid === true;
            if (orgPersonalIdConfirmed) { orgPersonalIdConfirmed.checked = false; orgPersonalIdConfirmed.disabled = !orgPersonalIdValid; }
            orgTargetCanIssue = result.success === true && result.canIssue === true && orgPersonalIdValid;
            orgLastTargetId = result.targetId || null;
            orgTargetJobName = String(result.jobName || "unemployed");
            if (Number.isFinite(Number(result.weaponPermitFee))) orgWeaponPermitFee = Math.max(0, Number(result.weaponPermitFee));
            orgTargetIsOrgMember = result.isOrganisationMember === true;
            orgAdminSelfTest = result.adminSelfIssue === true;
            orgTargetCanRecruit = result.canRecruit === true;
            const hireOption = document.getElementById("orgRecruitmentOption");
            const hireCheckbox = document.getElementById("orgHireEmployee");
            if (hireOption) hireOption.classList.toggle("hidden", orgTargetIsOrgMember || orgAdminSelfTest);
            if (hireCheckbox) { hireCheckbox.checked = !orgTargetIsOrgMember && !orgAdminSelfTest && orgTargetCanRecruit; hireCheckbox.disabled = true; }
            const feeLabel = document.querySelector('#orgPermitFeeReceived')?.parentElement;
            if (feeLabel) feeLabel.lastChild.textContent = ` Gebühr von ${orgWeaponPermitFee.toLocaleString("de-DE")} $ persönlich vom Spieler erhalten.`;
            if (orgPermitFeeReceived) { orgPermitFeeReceived.checked = false; orgPermitFeeReceived.disabled = orgTargetIsOrgMember || orgWeaponPermitFee <= 0; }
            if (orgPermitFeeInfo) orgPermitFeeInfo.textContent = (orgTargetIsOrgMember || orgWeaponPermitFee <= 0) ? "Für diesen Spieler ist der Waffenschein kostenlos; eine Gebührenbestätigung ist nicht nötig." : `Für Spieler außerhalb der Polizei sind ${orgWeaponPermitFee.toLocaleString("de-DE")} $ fällig. Das Geld wird nicht automatisch abgezogen: Der Spieler muss es dem Aussteller persönlich übergeben. Erst danach darfst du dieses Häkchen setzen.`;
            if (orgDocumentRank) {
                orgDocumentRank.replaceChildren();
                const options = Array.isArray(result.rankOptions) ? result.rankOptions : [];
                if (options.length) {
                    orgDocumentRank.add(new Option("Rang / Bezeichnung auswählen", ""));
                    options.forEach(option => orgDocumentRank.add(new Option(String(option.label || option.value), String(option.value))));
                    orgDocumentRank.disabled = false;
                } else {
                    orgDocumentRank.add(new Option("Keine QBCore-Job-Ränge gefunden", ""));
                    orgDocumentRank.disabled = true;
                }
            }
            if (result.success) {
                orgPreviewName.textContent = result.name || "Unbekannter Charakter";
                orgPreviewOrg.textContent = `Organisation: ${result.organisation || "—"}`;
                orgPreviewRank.textContent = `Rang: ${result.rank || "—"}`;
                orgPreviewDocument.textContent = result.personalIdValid ? "Personalausweis: gültig und abgeholt" : (result.hasPersonalId ? "Personalausweis: vorhanden, aber nicht gültig/abgeholt" : "Personalausweis: fehlt");
                if (result.photo) { orgPreviewPhoto.src = result.photo; orgPreviewPhoto.style.display = "block"; }
                else { orgPreviewPhoto.removeAttribute("src"); orgPreviewPhoto.style.display = "none"; }
                showElement(orgPreview, "flex");
            } else {
                hideElement(orgPreview);
                orgLastTargetId = null;
                orgTargetCanIssue = false;
                orgTargetCanRecruit = false;
                orgTargetIsOrgMember = false;
                orgPersonalIdValid = false;
            }
            updateOrgIssueButtonState();
            break;
        }

        case "orgEmployeeManagementLookupResult": {
            const result = data.result || {};
            const peopleStatus = document.getElementById("orgPeopleStatus");
            const fireButton = document.getElementById("orgFireEmployeeButton");
            const peoplePreview = document.getElementById("orgPeoplePreview");
            const peoplePhoto = document.getElementById("orgPeoplePhoto");
            const peopleName = document.getElementById("orgPeopleName");
            const peopleIdLabel = document.getElementById("orgPeopleIdLabel");
            const peopleRank = document.getElementById("orgPeopleRank");
            const peopleOrg = document.getElementById("orgPeopleOrg");
            const isOrganisationMember = result.success === true && result.isOrganisationMember === true;
            if (peopleStatus) {
                peopleStatus.textContent = result.success
                    ? `Polizeimitarbeiter gefunden: ${result.name || "Unbekannter Spieler"} (Server-ID ${result.targetId}) · Rang: ${result.rank || "Unbekannt"}`
                    : (result.message || "Es wurde kein bestehendes Polizeimitglied gefunden.");
                peopleStatus.style.color = isOrganisationMember ? "#8ee6a1" : "#ff9b9b";
            }
            if (fireButton) { fireButton.disabled = !(isOrganisationMember && result.targetId); fireButton.dataset.serverId = isOrganisationMember ? String(result.targetId) : ""; }
            const peopleActions = document.getElementById("orgPeopleActions");
            const firePanel = document.getElementById("orgPeopleFirePanel");
            const jobPanel = document.getElementById("orgPeopleJobPanel");
            const gradeSelect = document.getElementById("orgPeopleJobGrade");
            if (peopleActions) isOrganisationMember ? showElement(peopleActions, "block") : hideElement(peopleActions);
            if (firePanel) hideElement(firePanel);
            if (jobPanel) hideElement(jobPanel);
            if (gradeSelect) {
                gradeSelect.replaceChildren(new Option("Zielrang auswählen", ""));
                (Array.isArray(result.jobGradeOptions) ? result.jobGradeOptions : []).forEach(option => gradeSelect.add(new Option(String(option.label || option.value), String(option.value))));
                gradeSelect.disabled = !Array.isArray(result.jobGradeOptions) || result.jobGradeOptions.length === 0;
            }
            const jobApply = document.getElementById("orgPeopleJobApply");
            if (jobApply) { jobApply.disabled = true; jobApply.dataset.serverId = isOrganisationMember ? String(result.targetId) : ""; }
            if (peoplePreview && isOrganisationMember) {
                if (peopleName) peopleName.textContent = result.name || "Unbekannter Spieler";
                if (peopleIdLabel) peopleIdLabel.textContent = `Eingestellt am: ${formatDocumentDate(result.hiredAt)}`;
                if (peopleRank) peopleRank.textContent = `Rang: ${result.rank || "Unbekannt"}`;
                if (peopleOrg) peopleOrg.textContent = `Organisation: ${result.organisation || "—"}`;
                if (result.photo && peoplePhoto) { peoplePhoto.src = result.photo; peoplePhoto.style.display = "block"; }
                else if (peoplePhoto) { peoplePhoto.removeAttribute("src"); peoplePhoto.style.display = "none"; }
                showElement(peoplePreview, "flex");
            } else if (peoplePreview) {
                hideElement(peoplePreview);
                if (peoplePhoto) peoplePhoto.removeAttribute("src");
            }
            break;
        }

        case "orgDeputyCandidateResult": {
            const result = data.result || {};
            orgDeputyVerifiedId = result.success ? Number(result.targetId) : null;
            if (orgDeputyCandidateStatus) {
                orgDeputyCandidateStatus.textContent = result.message || (result.success ? "Person geprüft." : "Prüfung fehlgeschlagen.");
                orgDeputyCandidateStatus.style.color = result.success ? "#8ee6a1" : "#ff9b9b";
            }
            if (orgAppointDeputyButton) orgAppointDeputyButton.disabled = !orgDeputyVerifiedId;
            const candidatePreview = document.getElementById("orgDeputyCandidatePreview");
            const candidatePhoto = document.getElementById("orgDeputyCandidatePhoto");
            const candidateName = document.getElementById("orgDeputyCandidateName");
            const candidateId = document.getElementById("orgDeputyCandidateIdLabel");
            const candidateRank = document.getElementById("orgDeputyCandidateRank");
            if (result.success) {
                if (candidateName) candidateName.textContent = result.name || "Unbekannter Spieler";
                if (candidateId) candidateId.textContent = `Server-ID: ${result.targetId || "—"}`;
                if (candidateRank) candidateRank.textContent = `Rang: ${result.rank || "Unbekannt"}`;
                if (candidatePhoto && result.photo) { candidatePhoto.src = result.photo; candidatePhoto.style.display = "block"; }
                else if (candidatePhoto) { candidatePhoto.removeAttribute("src"); candidatePhoto.style.display = "none"; }
                if (candidatePreview) showElement(candidatePreview, "flex");
            } else if (candidatePreview) hideElement(candidatePreview);
            break;
        }

        case "orgTerminationLogs": {
            renderOrgTerminationLogs(data.data || []);
            break;
        }
        case "orgIssueLogs": {
            renderOrgIssueLogs(data.data || []);
            break;
        }
        case "orgArchiveMonths": {
            const box = document.getElementById("orgArchiveMonths"); if (box) { box.replaceChildren(); const rows = data.data || []; if (!rows.length) { const empty = document.createElement("div"); empty.className = "message-box"; empty.textContent = "Noch keine Protokolle archiviert."; box.append(empty); } rows.forEach(row => { const btn = document.createElement("button"); btn.type = "button"; btn.className = "org-protocol-tile"; const date = String(row.archive_month || ""); const parts = date.split("-"); const label = parts.length === 2 ? new Date(Number(parts[0]), Number(parts[1])-1, 1).toLocaleDateString("de-DE", { month: "long", year: "numeric" }) : date; const strong = document.createElement("strong"); strong.textContent = label.charAt(0).toUpperCase() + label.slice(1); const small = document.createElement("small"); small.textContent = `${row.entry_count || 0} archivierte Einträge`; btn.append(strong, small); btn.addEventListener("click", () => postNui("requestOrgArchiveEntries", { month: date })); box.append(btn); }); } break;
        }
        case "orgArchiveEntries": {
            const box = document.getElementById("orgArchiveEntries"); if (box) { box.replaceChildren(); const rows = data.data || []; if (!rows.length) { const empty = document.createElement("div"); empty.className = "message-box"; empty.textContent = "In diesem Monat sind keine Einträge vorhanden."; box.append(empty); } rows.forEach(row => { const item = document.createElement("article"); item.className = "org-protocol-row"; const title = document.createElement("strong"); title.textContent = row.title || "Archivierter Vorgang"; const details = document.createElement("small"); const payload = row.payload || {}; details.textContent = `Archiviert von: ${row.archived_by_name || "Unbekannt"} · ${formatDocumentDate(row.archived_at)}\nOriginaldaten: ${payload.reason || payload.details || payload.action || "Archivierter Protokolleintrag"}`; item.append(title, details); box.append(item); }); } break;
        }

        case "generalPersonResult": {
            const result = data.result || {};
            const status = document.getElementById("orgGeneralPersonStatus");
            const box = document.getElementById("orgGeneralPersonResult");
            if (status) { status.textContent = result.message || (result.success ? "Spieler gefunden." : "Spieler konnte nicht gefunden werden."); status.style.color = result.success ? "#8ee6a1" : "#ff9b9b"; }
            if (result.success && box) {
                const set = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
                set("orgGeneralPersonName", result.name || "Unbekannt");
                set("orgGeneralPersonJob", `Job und Rang: ${result.job || "Unbekannt"} · ${result.rank || "Unbekannt"}`);
                set("orgGeneralPersonBirthdate", `Geburtsdatum: ${result.birthdate || "—"}`);
                set("orgGeneralPersonGender", `Geschlecht: ${result.gender || "—"}`);
                set("orgGeneralPersonNationality", `Nationalität: ${result.nationality || "—"}`);
                const img = document.getElementById("orgGeneralPersonPhoto"); if (img) { if (result.photo) { img.src = result.photo; img.style.display = "block"; } else { img.removeAttribute("src"); img.style.display = "none"; } }
                showElement(box, "flex");
            } else if (box) hideElement(box);
            break;
        }
        case "orgEmployeeRankUpdated": {
            const update = data.data || {};
            if (update.deputy) updateDeputyOverview(update.deputy);
            const peopleId = Number(document.getElementById("orgPeopleJobApply")?.dataset.serverId || 0);
            if (peopleId && peopleId === Number(update.targetId)) {
                const rank = document.getElementById("orgPeopleRank"); if (rank) rank.textContent = `Rang: ${update.rank || "Unbekannt"}`;
                const org = document.getElementById("orgPeopleOrg"); if (org && update.jobLabel) org.textContent = `Organisation: ${update.jobLabel}`;
                const status = document.getElementById("orgPeopleStatus"); if (status) status.textContent = `${update.name || "Mitarbeiter"} · Rang aktualisiert: ${update.rank || "Unbekannt"}`;
            }
            if (Number(orgLastTargetId) === Number(update.targetId)) {
                const issueRank = document.getElementById("orgPreviewRank"); if (issueRank) issueRank.textContent = `Rang: ${update.rank || "Unbekannt"}`;
            }
            const generalId = Number(document.getElementById("orgGeneralPersonId")?.value || 0);
            if (generalId && generalId === Number(update.targetId)) {
                const generalJob = document.getElementById("orgGeneralPersonJob"); if (generalJob) generalJob.textContent = `Job und Rang: ${update.jobLabel || "Organisation"} · ${update.rank || "Unbekannt"}`;
            }
            const deputyCandidateId = Number(document.getElementById("orgDeputyId")?.value || 0);
            if (deputyCandidateId && deputyCandidateId === Number(update.targetId)) {
                const deputyRank = document.getElementById("orgDeputyCandidateRank"); if (deputyRank) deputyRank.textContent = `Rang: ${update.rank || "Unbekannt"}`;
            }
            const currentUserRank = document.getElementById("orgCurrentUserRank");
            if (update.isCurrentUser && currentUserRank) currentUserRank.textContent = update.rank || "Unbekannt";
            break;
        }
        case "orgNoteResult": {
            const result = data.result || {};
            const status = document.getElementById("orgNoteStatus");
            if (status) { status.textContent = result.message || (result.success ? "Notiz übermittelt." : "Notiz konnte nicht gesendet werden."); status.style.color = result.success ? "#8ee6a1" : "#ff9b9b"; }
            const button = document.getElementById("orgNoteSubmit"); if (button) button.disabled = false;
            if (result.success) { const field = document.getElementById("orgNoteText"); if (field) field.value = ""; }
            break;
        }
        case "orgEmployeeJobResult": {
            const result = data.result || {};
            const status = document.getElementById("orgPeopleJobStatus");
            if (status) { status.textContent = result.message || (result.success ? "Mitarbeiterdaten aktualisiert." : "Aktion fehlgeschlagen."); status.style.color = result.success ? "#8ee6a1" : "#ff9b9b"; }
            const apply = document.getElementById("orgPeopleJobApply"); if (apply) apply.disabled = false;
            if (result.success && result.deputy) updateDeputyOverview(result.deputy);
            if (result.success) { const rank = document.getElementById("orgPeopleRank"); if (rank && result.rank) rank.textContent = `Rang: ${result.rank}`; const org = document.getElementById("orgPeopleOrg"); if (org && result.jobLabel) org.textContent = `Organisation: ${result.jobLabel}`; }
            break;
        }
        case "orgFireResult": {
            const result = data.result || {};
            const status = document.getElementById("orgPeopleStatus");
            const fireButton = document.getElementById("orgFireEmployeeButton");
            if (orgFireRequestTimer) { clearTimeout(orgFireRequestTimer); orgFireRequestTimer = null; }
            if (status) { status.textContent = result.message || (result.success ? "Mitarbeiter gekündigt." : "Kündigung fehlgeschlagen."); status.style.color = result.success ? "#8ee6a1" : "#ff9b9b"; }
            if (fireButton) { fireButton.disabled = false; fireButton.dataset.busy = "false"; }
            if (result.success) {
                const reasonField = document.getElementById("orgTerminationReason");
                if (reasonField) reasonField.value = "";
                postNui("requestOrgTerminationLogs");
                const preview = document.getElementById("orgPeoplePreview");
                if (preview) hideElement(preview);
            }
            break;
        }

        case "orgDeputyResult": {
            const result = data.result || {};
            orgDeputyStatus.textContent = result.message || "Aktion abgeschlossen.";
            orgDeputyStatus.style.color = result.success ? "#8ee6a1" : "#ff9b9b";
            if (result.deputy) updateDeputyOverview(result.deputy);
            break;
        }
        case "orgPersonProtocolResult": {
            renderOrgPersonProtocolResult(data.result || {});
            break;
        }

        case "orgIssueResult": {
            const result = data.result || {};
            if (orgIssueRequestTimer) { clearTimeout(orgIssueRequestTimer); orgIssueRequestTimer = null; }
            orgLookupStatus.textContent = result.message || (result.success ? "Ausweis erstellt." : "Ausstellung fehlgeschlagen.");
            orgLookupStatus.style.color = result.success ? "#8ee6a1" : "#ff9b9b";
            if (result.success) {
                orgIssueButton.disabled = true;
                orgTargetCanIssue = false;
            } else {
                updateOrgIssueButtonState();
            }
            break;
        }

        case "close":
            hideElement(testPanel);
            closePhotoPreview();
            hideElement(savedPhotoPanel);
            hideElement(orgTablet);
            hideElement(adminTablet);
            hideElement(myDocumentsPanel);
            break;

        case "preparePhotoCrop": {
            if (cropInProgress) return;

            cropInProgress = true;
            photoSaveInProgress = false;

            setPreviewButtonsDisabled(true);
            setPreviewStatus("Foto wird vorbereitet ...");
            showElement(photoPreview, "flex");

            try {
                if (typeof data.image !== "string" || !data.image) {
                    throw new Error("Es wurden keine Bilddaten übergeben.");
                }

                const croppedImage = await cropPhoto(data.image);

                showPhotoPreview(croppedImage);

                await postNui("photoCropped", {
                    image: croppedImage
                });
            } catch (error) {
                console.error("[Universal Identity] Foto-Zuschnitt fehlgeschlagen:", error);

                setPreviewStatus(
                    "Das Foto konnte nicht vorbereitet werden. Bitte erneut aufnehmen.",
                    true
                );

                await postNui("photoCropped", {
                    image: null
                });
            } finally {
                cropInProgress = false;
                setPreviewButtonsDisabled(photoSaveInProgress);
            }

            break;
        }

        case "closePhotoPreview":
            closePhotoPreview();
            break;

        case "savedPhotoResult":
            showElement(savedPhotoPanel, "flex");

            if (data.success === false) {
                showElement(savedPhotoMessage, "block");
                hideElement(savedPhotoContainer);
                setSavedPhotoMessage(
                    data.message || "Das Foto konnte nicht geladen werden.",
                    true
                );

                if (savedPhotoStatus) {
                    savedPhotoStatus.textContent = "Foto nicht verfügbar";
                }
            } else {
                showElement(savedPhotoMessage, "block");
                setSavedPhotoMessage(
                    data.message || "Gespeichertes Foto wird geladen ..."
                );

                if (savedPhotoStatus) {
                    savedPhotoStatus.textContent = "Warte auf Server ...";
                }
            }

            break;

        case "showSavedPhoto":
            if (typeof data.image === "string" && data.image) {
                showSavedPhoto(data.image);
            } else {
                setSavedPhotoMessage("Der Server hat keine Bilddaten geliefert.", true);
            }
            break;

        case "closeSavedPhoto":
            hideElement(savedPhotoPanel);
            hideElement(savedPhotoContainer);

            if (savedPhotoImage) {
                savedPhotoImage.removeAttribute("src");
            }

            break;

        case "photoSaving":
            photoSaveInProgress = true;
            setPreviewButtonsDisabled(true);
            setPreviewStatus(data.message || "Foto wird gespeichert ...");
            break;

        case "photoStatus":
            setPreviewStatus(
                data.message || "",
                data.success === false
            );

            if (data.success === false) {
                photoSaveInProgress = false;
                setPreviewButtonsDisabled(false);
            }

            break;

        default:
            break;
    }
});

// =========================================================
// INITIALZUSTAND
// =========================================================

hideElement(photoPreview);
hideElement(savedPhotoPanel);
hideElement(savedPhotoContainer);
hideElement(orgTablet);

// Organisations-Tablet navigation (visual pages share the existing server callbacks).
function showOrgPage(page) {
    document.querySelectorAll(".org-nav-btn[data-org-page]").forEach((button) => button.classList.toggle("active", button.dataset.orgPage === page));
    document.querySelectorAll(".org-page").forEach((section) => section.classList.toggle("hidden", section.id !== `orgPage-${page}`));
    if (page === "announcements") postNui("markOrgAnnouncementsRead");
}
document.querySelectorAll("[data-org-page]").forEach((button) => button.addEventListener("click", () => { showOrgPage(button.dataset.orgPage); if (button.dataset.orgPage === "archive") postNui("requestOrgArchiveMonths"); if (button.dataset.orgPage === "police-members") postNui("requestOrgPoliceMembers"); }));
document.querySelectorAll("[data-org-goto]").forEach((button) => button.addEventListener("click", () => showOrgPage(button.dataset.orgGoto)));
const orgSidebarOrg = document.getElementById("orgSidebarOrg");
const orgTargetIdPeople = document.getElementById("orgTargetIdPeople");
const orgLookupPeopleButton = document.getElementById("orgLookupPeopleButton");
if (orgLookupPeopleButton) orgLookupPeopleButton.addEventListener("click", async () => {
    const value = Number(orgTargetIdPeople.value);
    const peopleStatus = document.getElementById("orgPeopleStatus");
    const fireButton = document.getElementById("orgFireEmployeeButton");
    if (!Number.isInteger(value) || value < 1) {
        if (peopleStatus) { peopleStatus.textContent = "Bitte eine gültige Server-ID eingeben."; peopleStatus.style.color = "#ff9b9b"; }
        if (fireButton) fireButton.disabled = true;
        return;
    }
    if (peopleStatus) { peopleStatus.textContent = "Mitarbeiter wird serverseitig geprüft ..."; peopleStatus.style.color = ""; }
    const peoplePreview = document.getElementById("orgPeoplePreview"); if (peoplePreview) hideElement(peoplePreview);
    const peoplePhoto = document.getElementById("orgPeoplePhoto"); if (peoplePhoto) peoplePhoto.removeAttribute("src");
    if (fireButton) { fireButton.disabled = true; fireButton.dataset.serverId = ""; }
    const peopleActions = document.getElementById("orgPeopleActions"); if (peopleActions) hideElement(peopleActions);
    const firePanel = document.getElementById("orgPeopleFirePanel"); if (firePanel) hideElement(firePanel);
    const jobPanel = document.getElementById("orgPeopleJobPanel"); if (jobPanel) hideElement(jobPanel);
    await postNui("lookupOrgEmployeeManagement", { serverId: value });
});
const orgGeneralPersonId = document.getElementById("orgGeneralPersonId");
const orgGeneralPersonSearchButton = document.getElementById("orgGeneralPersonSearchButton");
if (orgGeneralPersonSearchButton) orgGeneralPersonSearchButton.addEventListener("click", async () => {
    const serverId = Number(orgGeneralPersonId?.value);
    const status = document.getElementById("orgGeneralPersonStatus");
    const resultBox = document.getElementById("orgGeneralPersonResult");
    if (!Number.isInteger(serverId) || serverId < 1) { if (status) { status.textContent = "Bitte eine gültige Server-ID eingeben."; status.style.color = "#ff9b9b"; } if (resultBox) hideElement(resultBox); return; }
    if (status) { status.textContent = "Spielerdaten werden geprüft …"; status.style.color = ""; }
    if (resultBox) hideElement(resultBox);
    orgGeneralPersonSearchButton.disabled = true;
    await postNui("lookupGeneralPerson", { serverId });
    setTimeout(() => { if (orgGeneralPersonSearchButton) orgGeneralPersonSearchButton.disabled = false; }, 1200);
});
// Organisations-Tablet controls
if (orgHireEmployee) orgHireEmployee.addEventListener("change", updateOrgIssueButtonState);
if (orgPermitFeeReceived) orgPermitFeeReceived.addEventListener("change", updateOrgIssueButtonState);
if (orgPersonalIdConfirmed) orgPersonalIdConfirmed.addEventListener("change", updateOrgIssueButtonState);
if (orgDocumentRank) orgDocumentRank.addEventListener("change", updateOrgIssueButtonState);
if (orgDocumentType) orgDocumentType.addEventListener("change", () => {
    const isOrgId = orgDocumentType.value === "organisation_id";
    const hireOption = document.getElementById("orgRecruitmentOption");
    if (hireOption) hireOption.classList.toggle("hidden", !isOrgId || orgTargetIsOrgMember || !orgLastTargetId);
    if (!isOrgId && orgHireEmployee) orgHireEmployee.checked = false;
    if (orgPermitFeeReceived) { orgPermitFeeReceived.checked = false; orgPermitFeeReceived.disabled = isOrgId || orgTargetIsOrgMember || orgWeaponPermitFee <= 0; }
    if (orgPermitFeeInfo) orgPermitFeeInfo.textContent = isOrgId
        ? "Für Dienstausweise fällt keine Waffenschein-Gebühr an."
        : ((orgTargetIsOrgMember || orgWeaponPermitFee <= 0) ? "Der Waffenschein ist für diesen Spieler kostenlos." : `Für Spieler außerhalb der Polizei sind ${orgWeaponPermitFee.toLocaleString("de-DE")} $ fällig. Geld persönlich entgegennehmen und erst danach bestätigen.`);
    if (orgDocumentRank) { orgDocumentRank.disabled = !isOrgId || !orgLastTargetId; if (!isOrgId) orgDocumentRank.value = ""; }
    if (orgIssueButton) orgIssueButton.textContent = isOrgId ? "✓ Dienstausweis erstellen" : "✓ Waffenschein ausstellen";
    updateOrgIssueButtonState();
});
if (orgLookupButton) orgLookupButton.addEventListener("click", async () => {
    const serverId = Number(orgTargetId.value);
    if (!Number.isInteger(serverId) || serverId < 1) {
        orgLookupStatus.textContent = "Bitte eine gültige Server-ID eingeben.";
        orgLookupStatus.style.color = "#ff9b9b";
        return;
    }
    orgLookupStatus.textContent = "Spieler wird gesucht ...";
    orgLookupStatus.style.color = "";
    orgIssueButton.disabled = true;
    hideElement(orgPreview);
    orgLastTargetId = null;
    orgTargetCanIssue = false;
    orgTargetCanRecruit = false;
    orgTargetIsOrgMember = false;
    orgPersonalIdValid = false;
    if (orgHireEmployee) { orgHireEmployee.checked = false; orgHireEmployee.disabled = true; }
    if (orgPersonalIdConfirmed) { orgPersonalIdConfirmed.checked = false; orgPersonalIdConfirmed.disabled = true; }
    if (orgDocumentRank) { orgDocumentRank.replaceChildren(new Option("Zuerst Spieler suchen", "")); orgDocumentRank.disabled = true; }
    await postNui("lookupOrgEmployee", { serverId });
});
let orgIssueRequestTimer = null;
if (orgIssueButton) orgIssueButton.addEventListener("click", async () => {
    updateOrgIssueButtonState();
    if (orgIssueButton.disabled || !orgLastTargetId) {
        orgLookupStatus.textContent = "Ausstellung gesperrt: Bitte Foto, gültigen Personalausweis, Bestätigung und die erforderlichen Auswahlfelder prüfen.";
        orgLookupStatus.style.color = "#ff9b9b";
        return;
    }
    if (String(orgDocumentType?.value || "organisation_id") === "organisation_id" && !orgTargetIsOrgMember && !orgTargetCanRecruit) {
        orgLookupStatus.textContent = "Neueinstellung gesperrt: Deine Ausstellerrolle besitzt keine Einstellungsberechtigung. Bitte wende dich an deine Polizeileitung.";
        orgLookupStatus.style.color = "#ff9b9b";
        return;
    }
    if (String(orgDocumentType?.value || "organisation_id") === "weapon_permit" && !orgTargetIsOrgMember && orgWeaponPermitFee > 0 && !orgPermitFeeReceived?.checked) {
        orgLookupStatus.textContent = `Waffenschein gesperrt: erst ${orgWeaponPermitFee.toLocaleString("de-DE")} $ persönlich entgegennehmen und die Zahlung bestätigen.`;
        orgLookupStatus.style.color = "#ff9b9b";
        return;
    }
    orgIssueButton.disabled = true;
    orgLookupStatus.textContent = "Ausstellung wird serverseitig geprüft ...";
    orgLookupStatus.style.color = "";
    if (orgIssueRequestTimer) clearTimeout(orgIssueRequestTimer);
    orgIssueRequestTimer = setTimeout(() => {
        orgIssueButton.disabled = false;
        updateOrgIssueButtonState();
        orgLookupStatus.textContent = "Keine Serverantwort erhalten. Bitte Serverkonsole und oxmysql prüfen, bevor du erneut ausstellst.";
        orgLookupStatus.style.color = "#ff9b9b";
    }, 15000);
    const documentType = String(orgDocumentType?.value || "organisation_id");
    const rankLabel = String(orgDocumentRank?.value || "").trim();
    if (documentType === "organisation_id" && !rankLabel) {
        orgIssueButton.disabled = false;
        updateOrgIssueButtonState();
        orgLookupStatus.textContent = "Bitte zuerst den Rang / die Bezeichnung auswählen.";
        orgLookupStatus.style.color = "#ff9b9b";
        return;
    }
    await postNui("issueOrgEmployee", { serverId: orgLastTargetId, rankLabel, documentType, personalIdConfirmed: orgPersonalIdConfirmed.checked, permitFeeHandedOver: orgPermitFeeReceived?.checked === true, recruitment: !orgTargetIsOrgMember && !orgAdminSelfTest && orgTargetCanRecruit });
});
if (closeOrgTabletButton) closeOrgTabletButton.addEventListener("click", () => {
    // Oberfläche sofort schließen; nicht darauf warten, dass der NUI-Callback antwortet.
    hideElement(orgTablet);
    postNui("closeOrgTablet");
});

let orgDeputyVerifiedId = null;
if (orgVerifyDeputyButton) orgVerifyDeputyButton.addEventListener("click", async () => {
    const serverId = Number(orgDeputyId.value);
    orgDeputyVerifiedId = null;
    if (orgAppointDeputyButton) orgAppointDeputyButton.disabled = true;
    if (!Number.isInteger(serverId) || serverId < 1) {
        if (orgDeputyCandidateStatus) { orgDeputyCandidateStatus.textContent = "Bitte eine gültige Server-ID eingeben."; orgDeputyCandidateStatus.style.color = "#ff9b9b"; }
        return;
    }
    if (orgDeputyCandidateStatus) { orgDeputyCandidateStatus.textContent = "Spieler und Organisation werden geprüft ..."; orgDeputyCandidateStatus.style.color = ""; }
    await postNui("lookupOrgDeputyCandidate", { serverId });
});
if (orgAppointDeputyButton) orgAppointDeputyButton.addEventListener("click", async () => {
    if (!orgDeputyVerifiedId || Number(orgDeputyId.value) !== orgDeputyVerifiedId) {
        if (orgDeputyCandidateStatus) { orgDeputyCandidateStatus.textContent = "Bitte die aktuell eingetragene Server-ID zuerst prüfen."; orgDeputyCandidateStatus.style.color = "#ff9b9b"; }
        orgAppointDeputyButton.disabled = true;
        return;
    }
    orgDeputyStatus.textContent = "Geprüfte Stellvertretung wird ernannt ...";
    await postNui("manageOrgDeputy", { action: "appoint", serverId: orgDeputyVerifiedId });
});
if (orgRemoveDeputyButton) orgRemoveDeputyButton.addEventListener("click", async () => {
    orgDeputyStatus.textContent = "Stellvertretung wird entfernt ...";
    await postNui("manageOrgDeputy", { action: "remove" });
});
const orgPeopleRecruitToggle = document.getElementById("orgPeopleRecruitToggle");
const orgPeoplePromoteToggle = document.getElementById("orgPeoplePromoteToggle");
const orgPeopleFireToggle = document.getElementById("orgPeopleFireToggle");
const orgPeopleJobPanel = document.getElementById("orgPeopleJobPanel");
const orgPeopleFirePanel = document.getElementById("orgPeopleFirePanel");
const orgPeopleJobGrade = document.getElementById("orgPeopleJobGrade");
const orgPeopleJobApply = document.getElementById("orgPeopleJobApply");
let orgPeopleJobAction = "";
function openPeopleJobPanel(action) {
    orgPeopleJobAction = action;
    if (orgPeopleJobPanel) showElement(orgPeopleJobPanel, "block");
    if (orgPeopleFirePanel) hideElement(orgPeopleFirePanel);
    const status = document.getElementById("orgPeopleJobStatus");
    if (status) {
        status.textContent = action === "recruit" ? "Wähle den neuen Rang des bestehenden Polizeimitglieds. Die Änderung wird serverseitig geprüft." : "Wähle einen höheren Rang. Die Beförderung wird serverseitig geprüft.";
        status.style.color = "";
    }
    if (orgPeopleJobApply) {
        orgPeopleJobApply.textContent = action === "recruit" ? "Rekrutieren" : "Beförderung bestätigen";
        orgPeopleJobApply.disabled = !orgPeopleJobGrade || !orgPeopleJobGrade.value;
    }
}
if (orgPeopleRecruitToggle) orgPeopleRecruitToggle.addEventListener("click", () => openPeopleJobPanel("recruit"));
if (orgPeoplePromoteToggle) orgPeoplePromoteToggle.addEventListener("click", () => openPeopleJobPanel("promote"));
if (orgPeopleFireToggle) orgPeopleFireToggle.addEventListener("click", () => { if (orgPeopleFirePanel) showElement(orgPeopleFirePanel, "block"); if (orgPeopleJobPanel) hideElement(orgPeopleJobPanel); const reason = document.getElementById("orgTerminationReason"); const fire = document.getElementById("orgFireEmployeeButton"); if (fire) fire.disabled = !(reason && reason.value.trim() && fire.dataset.serverId); });
if (orgPeopleJobGrade) orgPeopleJobGrade.addEventListener("change", () => { if (orgPeopleJobApply) orgPeopleJobApply.disabled = !orgPeopleJobGrade.value; });
if (orgPeopleJobApply) orgPeopleJobApply.addEventListener("click", async () => {
    const serverId = Number(orgPeopleJobApply.dataset.serverId);
    const gradeLevel = Number(orgPeopleJobGrade?.value);
    if (!Number.isInteger(serverId) || serverId < 1 || !Number.isInteger(gradeLevel) || !orgPeopleJobAction) return;
    orgPeopleJobApply.disabled = true;
    const status = document.getElementById("orgPeopleJobStatus"); if (status) { status.textContent = "Rang und Personalstatus werden serverseitig aktualisiert …"; status.style.color = ""; }
    await postNui("manageOrgEmployeeJob", { serverId, action: orgPeopleJobAction, gradeLevel });
});
const orgTerminationReasonField = document.getElementById("orgTerminationReason");
if (orgTerminationReasonField) orgTerminationReasonField.addEventListener("input", () => {
    const fire = document.getElementById("orgFireEmployeeButton");
    if (fire) fire.disabled = !(fire.dataset.serverId && orgTerminationReasonField.value.trim().length > 0);
});

const orgFireEmployeeButton = document.getElementById("orgFireEmployeeButton");
let orgFireRequestTimer = null;
if (orgFireEmployeeButton) orgFireEmployeeButton.addEventListener("click", () => {
    const serverId = Number(orgFireEmployeeButton.dataset.serverId);
    const reasonField = document.getElementById("orgTerminationReason");
    const reason = (reasonField?.value || "").trim();
    if (!reason) {
        const status = document.getElementById("orgPeopleStatus");
        if (status) { status.textContent = "Bitte vor der Kündigung einen Kündigungsgrund eintragen."; status.style.color = "#ff9b9b"; }
        reasonField?.focus();
        return;
    }
    if (!Number.isInteger(serverId) || serverId < 1 || orgFireEmployeeButton.dataset.busy === "true") return;

    // Kein window.confirm(): native Bestätigungsdialoge können die FiveM-NUI blockieren,
    // sodass Tablet-Schließen und weitere Eingaben nicht mehr reagieren.
    orgFireEmployeeButton.dataset.busy = "true";
    orgFireEmployeeButton.disabled = true;
    const peopleStatus = document.getElementById("orgPeopleStatus");
    if (peopleStatus) {
        peopleStatus.textContent = `Kündigung für Server-ID ${serverId} wird verarbeitet ...`;
        peopleStatus.style.color = "";
    }
    if (orgFireRequestTimer) clearTimeout(orgFireRequestTimer);

    // Timeout VOR dem Request starten, damit auch eine hängende NUI-Anfrage die UI freigibt.
    orgFireRequestTimer = window.setTimeout(() => {
        if (peopleStatus) {
            peopleStatus.textContent = "Keine Serverantwort nach 15 Sekunden. Prüfe die Serverkonsole auf 'Fehler bei Mitarbeiterkündigung'. Du kannst das Tablet weiterhin schließen.";
            peopleStatus.style.color = "#ff9b9b";
        }
        orgFireEmployeeButton.disabled = false;
        orgFireEmployeeButton.dataset.busy = "false";
        orgFireRequestTimer = null;
    }, 15000);

    postNui("fireOrgEmployee", { serverId, reason }).then((callbackResult) => {
        if (callbackResult && callbackResult.success === false) {
            if (orgFireRequestTimer) clearTimeout(orgFireRequestTimer);
            orgFireRequestTimer = null;
            if (peopleStatus) {
                peopleStatus.textContent = callbackResult.message || "Die Kündigungsanfrage konnte nicht gesendet werden.";
                peopleStatus.style.color = "#ff9b9b";
            }
            orgFireEmployeeButton.disabled = false;
            orgFireEmployeeButton.dataset.busy = "false";
        }
    }).catch(() => {
        if (orgFireRequestTimer) clearTimeout(orgFireRequestTimer);
        orgFireRequestTimer = null;
        if (peopleStatus) {
            peopleStatus.textContent = "Die Anfrage konnte nicht gesendet werden. Bitte Serverkonsole prüfen.";
            peopleStatus.style.color = "#ff9b9b";
        }
        orgFireEmployeeButton.disabled = false;
        orgFireEmployeeButton.dataset.busy = "false";
    });
});

// Persönliche Dokumentenmappe mit farblich getrennten RP-Kartenvorlagen
const myDocumentsPanel = document.getElementById("myDocumentsPanel");
const myDocumentsGrid = document.getElementById("myDocumentsGrid");
const myDocumentsStatus = document.getElementById("myDocumentsStatus");
const documentTypePresentation = {
  personal_id: { label: "Personalausweis", theme: "blue" },
  organisation_id: { label: "Dienstausweis", theme: "navy" },
  weapon_permit: { label: "Waffenschein", theme: "red" },
  fishing_license: { label: "Angelschein", theme: "cyan" },
  boat_license: { label: "Bootsführerschein", theme: "ocean" },
  pilot_license: { label: "Pilotenschein", theme: "violet" }
};
function formatDocumentDate(value) {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "number" || /^\d{10,13}$/.test(String(value).trim())) {
    let stamp = Number(value);
    if (String(Math.trunc(stamp)).length <= 10) stamp *= 1000;
    const date = new Date(stamp);
    if (!Number.isNaN(date.getTime())) return `${date.toLocaleDateString("de-DE")} ${date.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}`;
  }
  const raw = String(value);
  const match = raw.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
  if (match) return `${match[3]}.${match[2]}.${match[1]}${match[4] ? ` ${match[4]}:${match[5]}${match[6] ? `:${match[6]}` : ""}` : ""}`;
  const parsed = new Date(raw);
  return Number.isNaN(parsed.getTime()) ? raw : `${parsed.toLocaleDateString("de-DE")} ${parsed.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}`;
}
function renderMyDocuments(payload) {
  const data = payload || {};
  const rows = Array.isArray(data.documents) ? data.documents : [];
  myDocumentsPanel.classList.toggle('document-presentation-mode', data.presentation === true);
  const headerTitle = myDocumentsPanel.querySelector('.documents-header h2');
  const headerDesc = myDocumentsPanel.querySelector('.documents-header p');
  if (headerTitle) headerTitle.textContent = data.presentation === true ? 'Vorgezeigtes Dokument' : 'Meine Dokumente';
  if (headerDesc) headerDesc.textContent = data.presentation === true ? 'Ein Spieler zeigt dir dieses Dokument.' : 'Deine ausgestellten RP-Dokumente an einem Ort.';
  myDocumentsGrid.replaceChildren();
  if (data.error) myDocumentsStatus.textContent = data.error;
  else myDocumentsStatus.textContent = rows.length ? `${rows.length} Dokument(e) in deiner Dokumentenmappe` : "Noch keine ausgestellten Dokumente vorhanden.";
  rows.forEach(doc => {
    const presentation = documentTypePresentation[doc.document_type] || { label: String(doc.document_type || "Dokument"), theme: "slate", subtitle: "UNIVERSAL DOCUMENT" };
    const card = document.createElement("article");
    card.className = `identity-card identity-card-landscape theme-${presentation.theme} doc-${String(doc.document_type || "document").replace(/[^a-z0-9_-]/gi, "")}`;
    const top = document.createElement("div"); top.className = "identity-card-top";
    const mark = document.createElement("span"); mark.className = "identity-card-mark"; mark.textContent = ({ personal_id: "ID", organisation_id: "ORG", weapon_permit: "WP", fishing_license: "FISH", boat_license: "SEA", pilot_license: "AIR" })[doc.document_type] || "UI";
    const topText = document.createElement("div"); topText.className = "identity-card-heading";
    const brand = document.createElement("strong"); brand.textContent = "UNIVERSAL IDENTITY";
    if (doc.document_type === "weapon_permit") {
      card.classList.add("weapon-permit-premium");
      topText.append(brand);
      top.append(mark, topText);
    } else {
      topText.append(brand);
      card.classList.add(doc.document_type === "personal_id" ? "personal-id-premium" : "organisation-id-premium");
      top.append(mark, topText);
    }
    const body = document.createElement("div"); body.className = "identity-card-body";
    const portrait = document.createElement("img"); portrait.className = "identity-card-photo"; portrait.alt = "Charakterfoto";
    if (typeof data.photo === "string" && data.photo.startsWith("data:image/")) portrait.src = data.photo;
    else { portrait.src = ""; portrait.classList.add("photo-missing"); portrait.alt = "Kein gespeichertes Foto"; }
    const details = document.createElement("div"); details.className = "identity-card-details";
    const title = document.createElement("h3"); title.textContent = presentation.label; title.classList.add("identity-card-document-title");
    const fullName = String(doc.owner_name || "Unbekannt").trim().split(/\s+/);
    const firstName = fullName.shift() || "Unbekannt";
    const lastName = fullName.join(" ") || "—";
    const nameLabel = document.createElement("small"); nameLabel.textContent = "NAME";
    const name = document.createElement("strong"); name.textContent = firstName;
    const surnameLabel = document.createElement("small"); surnameLabel.textContent = "NACHNAME";
    const surname = document.createElement("strong"); surname.textContent = lastName;
    details.append(title, nameLabel, name, surnameLabel, surname);
    const birthdate = String(doc.birthdate || "").trim();
    if (birthdate && birthdate !== "—") { const birthLabel = document.createElement("small"); birthLabel.textContent = "GEBOREN AM"; const birthValue = document.createElement("strong"); birthValue.textContent = birthdate; details.append(birthLabel, birthValue); }
    const signature = document.createElement("div"); signature.className = "weapon-digital-signature";
    const signatureLabel = document.createElement("small"); signatureLabel.textContent = "DIGITALE UNTERSCHRIFT";
    const signatureValue = document.createElement("span"); signatureValue.textContent = `${firstName} ${lastName}`;
    signature.append(signatureLabel, signatureValue); details.append(signature);
    body.append(portrait, details);
    const bottom = document.createElement("div"); bottom.className = "identity-card-bottom";
    const extra = document.createElement("span");
    const orgKey = String(doc.organisation_key || "").toLowerCase();
    const organisationName = doc.organisation_label || ({ police: "Polizei" }[orgKey] || doc.organisation_key || "Organisation");
    const rankName = String(doc.rank_label || "").trim();
    extra.textContent = doc.document_type === "weapon_permit" ? `AUSGESTELLT · ${formatDocumentDate(doc.handed_over_at || doc.created_at)}` : `${doc.document_type === "organisation_id" ? `${organisationName}${rankName ? " · " + rankName : ""} · ` : ""}Ausgestellt: ${formatDocumentDate(doc.handed_over_at || doc.created_at)}`;
    const status = document.createElement("span"); status.className = `identity-card-status status-${String(doc.status || "ready").replace(/[^a-z_]/g, "")}`;
    status.textContent = doc.document_type === "weapon_permit" ? (doc.status === "revoked" ? "UNGÜLTIG" : "GÜLTIG") : (({ issued: "AUSGESTELLT", ready: "ABHOLBEREIT", pending_handover: "ABHOLBEREIT", collected_by_issuer: "BEIM AUSSTELLER", revoked: "UNGÜLTIG", processing: "IN BEARBEITUNG" })[doc.status] || String(doc.status || "AKTIV").toUpperCase());
    bottom.append(extra, status);
    card.append(top, body, bottom);
    if (data.presentation !== true && data.preview !== true && ["issued", "collected_by_issuer"].includes(String(doc.status || ""))) {
      const showButton = document.createElement("button");
      showButton.type = "button"; showButton.className = "identity-card-show-button"; showButton.textContent = "Ausweis vorzeigen";
      showButton.addEventListener("click", async () => {
        showButton.disabled = true; showButton.textContent = "Spieler wird gesucht …";
        const result = await postNui("showDocumentToNearbyPlayer", { documentType: doc.document_type });
        if (!result || result.success !== true) {
          showButton.disabled = false; showButton.textContent = "Ausweis vorzeigen";
        } else {
          showButton.textContent = "Anfrage gesendet";
          window.setTimeout(() => { showButton.disabled = false; showButton.textContent = "Ausweis vorzeigen"; }, 2200);
        }
      });
      card.append(showButton);
    }
    myDocumentsGrid.append(card);
  });
}
function closeMyDocuments() {
  hideElement(myDocumentsPanel);
  postNui("closeMyDocuments");
}
document.getElementById("closeMyDocuments")?.addEventListener("click", closeMyDocuments);

// Admin tablet UI
// Datum/Uhrzeit im Admin-Tablet (lokale Zeit des FiveM-Clients)
const adminDateTime = document.getElementById('adminDateTime');
function updateAdminDateTime() {
  if (!adminDateTime) return;
  const now = new Date();
  const date = new Intl.DateTimeFormat('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(now);
  const time = new Intl.DateTimeFormat('de-DE', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(now);
  adminDateTime.textContent = `${date} · ${time}`;
}
updateAdminDateTime();
window.setInterval(updateAdminDateTime, 1000);

const adminTablet = document.getElementById('adminTablet');
const adminFeedback = document.getElementById('adminFeedback');
let adminTabletData = { photo: [], pickup: [], policePickup: [], pc: [], policeMembers: [] };
function adminAction(action, extra = {}) { postNui('adminTabletAction', { action, ...extra }); }
function adminFeedbackSet(message, success = true) { if (!adminFeedback) return; adminFeedback.textContent = message || ''; adminFeedback.style.color = success ? '#79e5a4' : '#ff9999'; }
function renderAdminList(id, rows, type, extraLabel = '') {
  const el = document.getElementById(id);
  if (!el) return;

  if (!Array.isArray(rows) || rows.length === 0) {
    el.replaceChildren();
    const empty = document.createElement('div');
    empty.className = 'admin-summary';
    empty.textContent = 'Keine Einträge vorhanden.';
    el.append(empty);
    return;
  }

  el.replaceChildren();
  rows.forEach(row => {
    const line = document.createElement('div');
    line.className = 'admin-list-row';

    const info = document.createElement('div');
    const title = document.createElement('strong');
    title.textContent = row.name || type;

    const small = document.createElement('small');
    small.textContent = `${extraLabel || row.org_key || ''} · Löschen nur direkt am Standort möglich`;
    info.append(title, small);

    const del = document.createElement('button');
    del.className = 'admin-delete';
    del.type = 'button';
    del.textContent = 'Löschen';
    del.setAttribute('aria-label', `Eintrag ${row.id} löschen`);
    let confirmDelete = false;

    // Avoid native confirm(): FiveM's embedded NUI browser can leave focus
    // stuck when a JavaScript confirmation dialog is opened.
    del.addEventListener('click', () => {
      if (!confirmDelete) {
        confirmDelete = true;
        del.textContent = 'Sicher löschen?';
        del.classList.add('confirm-delete');
        adminFeedbackSet(`Zum Löschen von ${row.name || type} bitte erneut klicken.`, false);
        return;
      }

      del.disabled = true;
      del.textContent = 'Wird gelöscht …';
      adminFeedbackSet(`${row.name || type} wird gelöscht …`, true);
      adminAction(`delete-${type}`, { id: row.id });
    });

    line.append(info, del);
    el.append(line);
  });
}
function renderAdminHistoryInto(targetId, rows) {
  const el = document.getElementById(targetId);
  if (!el) return;
  el.replaceChildren();
  if (!Array.isArray(rows) || rows.length === 0) {
    const empty = document.createElement("div"); empty.className = "admin-summary"; empty.textContent = "Noch keine protokollierten Vorgänge."; el.append(empty); return;
  }
  rows.forEach(row => {
    const line = document.createElement("div"); line.className = "admin-list-row";
    const info = document.createElement("div");
    const title = document.createElement("strong");
    title.textContent = `#${row.document_id || row.id} · ${row.document_number || "ohne Nummer"} · ${row.owner_name || "Unbekannt"}`;
    const small = document.createElement("small");
    small.textContent = `${row.document_type || "Dokument"} · ${row.action || "Aktion"} · Aussteller: ${row.actor_name || "Unbekannt"} · ${formatDocumentDate(row.created_at)}${row.details ? " · " + row.details : ""}`;
    info.append(title, small); line.append(info); el.append(line);
  });
}
function renderAdminHistory(rows) { renderAdminHistoryInto("adminDocumentHistory", rows); }
function renderOrgTerminationLogs(rows) {
  const el = document.getElementById("orgTerminationLogs");
  if (!el) return;
  el.replaceChildren();
  if (!Array.isArray(rows) || rows.length === 0) {
    const empty = document.createElement("div"); empty.className = "org-protocol-row"; empty.textContent = "Für diese Organisation wurden noch keine Kündigungen protokolliert."; el.append(empty); return;
  }
  rows.forEach(row => {
    const item = document.createElement("article"); item.className = "org-protocol-row";
    const title = document.createElement("strong"); title.textContent = `${row.employee_name || "Unbekannter Mitarbeiter"} · Kündigung`;
    const details = document.createElement("small");
    details.textContent = `Von: ${row.terminated_by_name || "Unbekannt"}\nDatum/Uhrzeit: ${formatDocumentDate(row.created_at)}\nGrund: ${row.reason || "Kein Grund hinterlegt"}`;
    item.append(title, details);
    if (row.id) { const archive = document.createElement("button"); archive.type = "button"; archive.className = "secondary-button"; archive.textContent = "Ins Archiv verschieben"; archive.addEventListener("click", () => postNui("archiveOrgProtocol", { sourceType: "termination", sourceId: Number(row.id) })); item.append(archive); }
    el.append(item);
  });
}

function renderOrgIssueLogs(rows) {
  const el = document.getElementById("orgTerminationLogs");
  if (!el) return;
  el.replaceChildren();
  if (!Array.isArray(rows) || rows.length === 0) {
    const empty = document.createElement("div"); empty.className = "org-protocol-row"; empty.textContent = "Noch keine Ausweis-Ausstellungen protokolliert."; el.append(empty); return;
  }
  rows.forEach(row => {
    const item = document.createElement("article"); item.className = "org-protocol-row";
    const title = document.createElement("strong"); title.textContent = `${row.owner_name || "Unbekannter Mitarbeiter"} · ${row.document_type === "weapon_permit" ? "Waffenschein" : "Dienstausweis"}`;
    const actionMap = { issued_waiting_pickup: { label: "Abholbereit", dot: "ready" }, collected_by_issuer: { label: "Abgeschlossen", dot: "done" }, handed_to_owner: { label: "Abgeschlossen", dot: "done" } };
    const mapped = actionMap[String(row.action || "")] || { label: String(row.action || "Ausstellung"), dot: "" };
    const details = document.createElement("small");
    details.append(document.createTextNode(`Vorgang: ${mapped.label} `));
    if (mapped.dot) { const dot = document.createElement("span"); dot.className = `org-audit-dot ${mapped.dot}`; dot.title = mapped.dot === "ready" ? "Abholbereit" : "Abgeschlossen"; details.append(dot); }
    details.append(document.createTextNode(`\nVon: ${row.actor_name || row.owner_name || "Unbekannt"}\nDatum/Uhrzeit: ${formatDocumentDate(row.created_at)}\n${row.details || ""}`));
    item.append(title, details);
    if (row.id) { const archive = document.createElement("button"); archive.type = "button"; archive.className = "secondary-button"; archive.textContent = "Ins Archiv verschieben"; archive.addEventListener("click", () => postNui("archiveOrgProtocol", { sourceType: "audit", sourceId: Number(row.id) })); item.append(archive); }
    el.append(item);
  });
}
function renderOrgPersonProtocolResult(result) {
  const box = document.getElementById("orgProtocolPersonResult");
  const list = document.getElementById("orgTerminationLogs");
  if (!box || !list) return;
  box.textContent = result.message || (result.success ? "Suche abgeschlossen." : "Person konnte nicht gefunden werden.");
  box.style.color = result.success ? "#8ee6a1" : "#ff9b9b";
  list.replaceChildren();
  list.classList.remove("hidden");
  if (result.success && result.person) {
    const person = result.person; const profile = document.createElement("article"); profile.className = "org-protocol-row";
    if (result.photo) { const photo = document.createElement("img"); photo.src = result.photo; photo.alt = "Charakterfoto"; photo.style.width = "92px"; photo.style.height = "112px"; photo.style.objectFit = "cover"; photo.style.borderRadius = "8px"; photo.style.float = "left"; photo.style.marginRight = "14px"; profile.append(photo); }
    const title = document.createElement("strong"); title.textContent = result.name || "Spieler";
    const genderValue = person.gender; const genderLabel = (genderValue === 0 || genderValue === "0") ? "Männlich" : ((genderValue === 1 || genderValue === "1") ? "Weiblich" : (genderValue || "—")); const details = document.createElement("small"); details.textContent = `Server-ID: ${result.serverId || "—"}\nCitizenID: ${person.citizenid || "—"}\nGeburtsdatum: ${person.birthdate || "—"}\nGeschlecht: ${genderLabel}\nNationalität: ${person.nationality || "—"}\nJob: ${person.job || "—"} · Rang: ${person.grade || "—"}\nBargeld: ${person.cash ?? 0} · Bank: ${person.bank ?? 0}`;
    profile.append(title, details); list.append(profile);
  }
  const entries = Array.isArray(result.entries) ? result.entries : [];
  if (!result.success || entries.length === 0) {
    const empty = document.createElement("div");
    empty.className = "org-protocol-row";
    empty.textContent = result.success ? "Keine Einträge vorhanden." : (result.message || "Keine Einträge vorhanden.");
    list.append(empty);
    return;
  }
  entries.forEach(row => {
    const item = document.createElement("article"); item.className = "org-protocol-row";
    const title = document.createElement("strong"); title.textContent = `${row.entry_type || "Protokoll"} · ${row.subject_name || result.name || "Spieler"}`;
    const details = document.createElement("small");
    details.textContent = `Datum/Uhrzeit: ${formatDocumentDate(row.created_at)}\nVon: ${row.actor_name || "Unbekannt"}\n${row.details || "Keine Details"}`;
    item.append(title, details); list.append(item);
  });
}

function initOrgProtocolTiles() {
  const tiles = document.querySelectorAll("[data-protocol-filter]");
  const logs = document.getElementById("orgTerminationLogs");
  const personSearch = document.getElementById("orgProtocolPersonSearch");
  const result = document.getElementById("orgProtocolPersonResult");
  tiles.forEach(tile => tile.addEventListener("click", () => {
    tiles.forEach(other => other.classList.toggle("active", other === tile));
    const filter = tile.dataset.protocolFilter;
    if (personSearch) personSearch.classList.toggle("hidden", filter !== "person");
    if (logs) logs.classList.toggle("hidden", filter === "person");
    if (filter === "terminations" || filter === "all") postNui("requestOrgTerminationLogs");
    else if (filter === "issued") postNui("requestOrgIssueLogs");
    else if (filter === "person") { if (result) result.textContent = "Server-ID eingeben und Person suchen."; }
  }));
  document.getElementById("orgProtocolPersonSearchButton")?.addEventListener("click", () => {
    const field = document.getElementById("orgProtocolPersonId");
    const serverId = Number(field?.value);
    if (!Number.isInteger(serverId) || serverId < 1) { if (result) { result.textContent = "Bitte eine gültige Server-ID eingeben."; result.style.color = "#ff9b9b"; } return; }
    result.textContent = "Spieler und zugehörige Protokolle werden gesucht …";
    result.style.color = "";
    postNui("searchOrgPersonProtocol", { serverId });
  });
}
initOrgProtocolTiles();

const orgNoteSubmitButton = document.getElementById("orgNoteSubmit");
if (orgNoteSubmitButton) orgNoteSubmitButton.addEventListener("click", async () => {
  const serverId = Number(document.getElementById("orgNoteServerId")?.value || 0);
  const note = String(document.getElementById("orgNoteText")?.value || "").trim();
  const status = document.getElementById("orgNoteStatus");
  if (!Number.isInteger(serverId) || serverId < 1 || !note) { if (status) { status.textContent = "Bitte Server-ID, Namen und Notiz ausfüllen."; status.style.color = "#ff9b9b"; } return; }
  orgNoteSubmitButton.disabled = true;
  if (status) { status.textContent = "Notiz wird serverseitig geprüft und übermittelt …"; status.style.color = ""; }
  await postNui("submitOrgNote", { serverId, note });
});

function renderAdminOrgNotes(notes) {
  const container = document.getElementById("adminOrgNotes");
  if (!container) return;
  container.replaceChildren();
  if (!Array.isArray(notes) || notes.length === 0) {
    const empty = document.createElement("div"); empty.className = "admin-summary"; empty.textContent = "Noch keine Polizeinotizen vorhanden."; container.appendChild(empty); return;
  }
  notes.forEach(note => {
    const card = document.createElement("article"); card.className = "admin-note-card";
    const heading = document.createElement("strong"); heading.textContent = `${note.author_name || "Unbekannt"} · Server-ID ${note.author_server_id || "—"}`;
    const time = document.createElement("small"); time.textContent = formatDocumentDate(note.created_at);
    const status = document.createElement("small"); status.textContent = note.status === "accepted" ? "Status: Akzeptiert" : "Status: Offen";
    const body = document.createElement("p"); body.textContent = note.note_text || ""; body.style.whiteSpace = "pre-wrap"; body.style.overflowWrap = "anywhere";
    const actions = document.createElement("div"); actions.className = "admin-note-actions";
    if (note.status !== "accepted") { const accept = document.createElement("button"); accept.className = "admin-primary"; accept.textContent = "Akzeptieren"; accept.addEventListener("click", () => adminAction("note-accept", { id: Number(note.id) })); actions.appendChild(accept); }
    const remove = document.createElement("button"); remove.className = "admin-delete"; remove.textContent = "Löschen"; remove.addEventListener("click", () => adminAction("note-delete", { id: Number(note.id) })); actions.appendChild(remove);
    card.append(heading, time, status, body, actions); container.appendChild(card);
  });
}

let orgPoliceMembersCache = [];
let orgPoliceRankFilter = 'all';

function sortPoliceMembersByRank(members) {
  return [...members].sort((a, b) => {
    const gradeA = Number.isFinite(Number(a.gradeLevel)) ? Number(a.gradeLevel) : -1;
    const gradeB = Number.isFinite(Number(b.gradeLevel)) ? Number(b.gradeLevel) : -1;
    if (gradeA !== gradeB) return gradeB - gradeA;
    const rankCompare = String(a.rank || '').localeCompare(String(b.rank || ''), 'de', { sensitivity: 'base' });
    if (rankCompare !== 0) return rankCompare;
    return String(a.name || '').localeCompare(String(b.name || ''), 'de', { sensitivity: 'base' });
  });
}

function renderPoliceMembers(members, targetId = 'adminPoliceMembers', authorized = true, deniedMessage = '') {
  const container = document.getElementById(targetId);
  if (!container) return;

  if (targetId === 'orgPoliceMembers' && authorized !== true) {
    orgPoliceMembersCache = [];
    const filter = document.getElementById('orgPoliceRankFilter');
    if (filter) { filter.replaceChildren(new Option('Keine Berechtigung', '')); filter.disabled = true; }
    container.replaceChildren();
    const denied = document.createElement('div');
    denied.className = 'admin-summary';
    denied.textContent = deniedMessage || 'Du hast keine Berechtigung, Polizeimitglieder anzusehen. Bitte wende dich an deinen Vorgesetzten.';
    container.appendChild(denied);
    return;
  }

  if (targetId === 'orgPoliceMembers') {
    const filter = document.getElementById('orgPoliceRankFilter');
    if (filter) filter.disabled = false;
    orgPoliceMembersCache = Array.isArray(members) ? members : [];
    if (filter) {
      const ranks = new Map();
      orgPoliceMembersCache.forEach(member => {
        const label = String(member.rank || 'Unbekannt');
        const level = Number.isFinite(Number(member.gradeLevel)) ? Number(member.gradeLevel) : -1;
        if (!ranks.has(label) || ranks.get(label) < level) ranks.set(label, level);
      });
      const sortedRanks = [...ranks.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], 'de', { sensitivity: 'base' }));
      filter.replaceChildren();
      const allOption = document.createElement('option');
      allOption.value = 'all';
      allOption.textContent = 'Alle Ränge';
      filter.appendChild(allOption);
      sortedRanks.forEach(([label]) => {
        const option = document.createElement('option');
        option.value = label;
        option.textContent = label;
        filter.appendChild(option);
      });
      if ([...filter.options].some(option => option.value === orgPoliceRankFilter)) {
        filter.value = orgPoliceRankFilter;
      } else {
        orgPoliceRankFilter = 'all';
        filter.value = 'all';
      }
    }
    members = orgPoliceMembersCache.filter(member =>
      orgPoliceRankFilter === 'all' || String(member.rank || 'Unbekannt') === orgPoliceRankFilter
    );
  }

  container.replaceChildren();
  const sortedMembers = sortPoliceMembersByRank(Array.isArray(members) ? members : []);
  if (!sortedMembers.length) {
    const empty = document.createElement('div');
    empty.className = 'admin-summary';
    empty.textContent = orgPoliceRankFilter !== 'all' && targetId === 'orgPoliceMembers'
      ? 'Keine Polizeimitglieder mit diesem Rang gefunden.'
      : 'Keine Polizeimitglieder gefunden.';
    container.appendChild(empty);
    return;
  }

  sortedMembers.forEach(member => {
    const row = document.createElement('article'); row.className = 'police-roster-card';
    const img = document.createElement('img'); img.className = 'police-roster-photo'; img.alt = 'Charakterfoto'; img.src = member.photo || ''; img.onerror = () => { img.removeAttribute('src'); img.classList.add('photo-missing'); img.alt = 'Kein Foto'; };
    const info = document.createElement('div'); info.className = 'police-roster-info';
    const title = document.createElement('strong'); title.textContent = member.name || 'Unbekannt';
    const rank = document.createElement('span'); rank.textContent = `Rang: ${member.rank || 'Unbekannt'}`;
    const id = document.createElement('span'); id.textContent = `ID: ${member.online && member.serverId ? member.serverId : 'Offline'}`;
    const status = document.createElement('span'); status.className = member.online ? 'roster-status online' : 'roster-status offline'; status.textContent = member.online ? 'Online' : 'Offline'; status.style.color = member.online ? '#16a34a' : '#dc2626'; status.style.fontWeight = '700';
    const hired = document.createElement('small'); hired.textContent = `Eintrittsdatum: ${member.hiredAt ? formatDocumentDate(member.hiredAt) : 'Nicht hinterlegt'}`;
    info.append(title, rank, id, status, hired);
    row.append(img, info);
    container.appendChild(row);
  });
}

document.getElementById('orgPoliceRankFilter')?.addEventListener('change', event => {
  orgPoliceRankFilter = event.target.value || 'all';
  renderPoliceMembers(orgPoliceMembersCache, 'orgPoliceMembers');
});
const orgAdminEntry = document.getElementById('orgAdminEntry');
if (orgAdminEntry) orgAdminEntry.addEventListener('click', () => postNui('requestOpenAdminTablet'));

function renderOrgAnnouncements(rows, canPublish, unreadCount = 0) {
  const composer=document.getElementById('orgAnnouncementComposer'); if(composer) composer.classList.toggle('hidden', !canPublish);
  const permissionNotice=document.getElementById('orgAnnouncementPermissionNotice'); if(permissionNotice) { permissionNotice.textContent='Du kannst Bekanntmachungen lesen. Das Veröffentlichen ist für deinen aktuellen Zugriff nicht freigeschaltet. Die zuständige Leitung kann die Schreibberechtigung im Admin-Tablet vergeben.'; permissionNotice.classList.toggle('hidden', canPublish); }
  const badge=document.getElementById('orgAnnouncementsNewBadge'); if(badge){const count=Math.max(0,Number(unreadCount)||0);badge.classList.toggle('hidden',count===0);badge.textContent=count>1?'NEU':'NEU';badge.title=count>0?`${count} ungelesene Bekanntmachung${count===1?'':'en'}`:'';}
  const container=document.getElementById('orgAnnouncementsList'); if(!container) return; container.replaceChildren();
  if(!Array.isArray(rows)||!rows.length){const empty=document.createElement('div');empty.className='admin-summary';empty.textContent='Noch keine internen Bekanntmachungen.';container.appendChild(empty);return;}
  rows.forEach(item=>{const card=document.createElement('article');card.className='admin-note-card';const h=document.createElement('strong');h.textContent=item.title||'Bekanntmachung';const meta=document.createElement('small');meta.textContent=`Von ${item.author_name||'Leitung'} · ${formatDocumentDate(item.created_at)}`;const body=document.createElement('p');body.textContent=item.body||'';body.style.whiteSpace='pre-wrap';body.style.overflowWrap='anywhere';card.append(h,meta,body);if(canPublish){const del=document.createElement('button');del.type='button';del.className='announcement-delete-button';del.textContent='Bekanntmachung löschen';del.addEventListener('click',async()=>{if(del.disabled)return;del.disabled=true;del.textContent='Wird gelöscht …';const result=await postNui('deleteOrgAnnouncement',{id:item.id});if(!result||result.success!==true){del.disabled=false;del.textContent='Erneut versuchen';const status=document.getElementById('orgAnnouncementStatus');if(status)status.textContent='Löschanfrage konnte nicht gesendet werden. Bitte erneut versuchen.';}});card.appendChild(del);}container.appendChild(card);});
}

document.getElementById('orgAnnouncementPublish')?.addEventListener('click', async () => {
  const title=String(document.getElementById('orgAnnouncementTitle')?.value||'').trim();
  const body=String(document.getElementById('orgAnnouncementText')?.value||'').trim();
  const status=document.getElementById('orgAnnouncementStatus');
  if(!title||!body){if(status)status.textContent='Bitte Überschrift und Text ausfüllen.';return;}
  const btn=document.getElementById('orgAnnouncementPublish'); if(btn)btn.disabled=true;
  await postNui('publishOrgAnnouncement',{title,body});
  if(status)status.textContent='Bekanntmachung wird veröffentlicht …';
  // Die Eingaben erst leeren, wenn der Server die gespeicherte Liste zurücksendet.
  if(btn)btn.disabled=false;
});

const adminPermissionDefinitions = [
  { key: 'view_employee', label: 'Mitarbeiter ansehen', help: 'Mitarbeiter suchen und Stammdaten ansehen.' },
  { key: 'issue_org_document', label: 'Ausweise ausstellen', help: 'Dienstausweise und Waffenscheine ausstellen.' },
  { key: 'hire_employee', label: 'Mitarbeiter einstellen', help: 'Spieler ohne Polizeijob einstellen; Job und Rang werden direkt bei der Ausstellung gesetzt.' },
  { key: 'manage_employee_job', label: 'Ränge verwalten', help: 'Bestehende Polizeimitglieder befördern oder ihren Rang ändern.' },
  { key: 'fire_employee', label: 'Mitarbeiter kündigen', help: 'Mitarbeiter entlassen und Vorgang protokollieren.' },
  { key: 'manage_deputy', label: 'Stellvertretung verwalten', help: 'Stellvertreter ernennen oder entfernen.' },
  { key: 'view_issue_logs', label: 'Ausstellungsvorgänge ansehen', help: 'Dokumenten-Ausstellungsverlauf öffnen.' },
  { key: 'publish_announcements', label: 'Bekanntmachungen veröffentlichen', help: 'Interne Mitteilungen veröffentlichen.' },
  { key: 'delete_announcements', label: 'Bekanntmachungen löschen', help: 'Veröffentlichte Mitteilungen entfernen.' }
];
let activePermissionOverrides = {};
function renderPermissionControls() {
  const list = document.getElementById('adminPermissionList');
  if (!list) return;
  list.replaceChildren();
  for (const permission of adminPermissionDefinitions) {
    const row = document.createElement('label'); row.className = 'admin-permission-row';
    const copy = document.createElement('div');
    const title = document.createElement('span'); title.textContent = permission.label;
    const help = document.createElement('small'); help.textContent = permission.help;
    copy.append(title, help);
    const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.dataset.permission = permission.key;
    checkbox.checked = activePermissionOverrides[permission.key] === true;
    row.append(copy, checkbox); list.appendChild(row);
  }
}
function loadSelectedPermissions() {
  const orgKey = document.getElementById('adminPermissionOrg')?.value || 'police';
  const grade = document.getElementById('adminPermissionGrade')?.value;
  if (grade === '' || grade == null) return;
  const entry = (adminTabletData.permissionSettings || []).find(item => String(item.org_key) === orgKey && Number(item.grade_level) === Number(grade));
  activePermissionOverrides = entry && entry.permissions && typeof entry.permissions === 'object' ? entry.permissions : {};
  renderPermissionControls();
  const status = document.getElementById('adminPermissionStatus');
  if (status) status.textContent = entry ? `Eigene Rechte für Rang ${grade} geladen. Nicht aktivierte Rechte sind gesperrt.` : `Für Rang ${grade} sind noch keine eigenen Rechte gespeichert. Speichern legt eine ausdrückliche Rechteauswahl an.`;
}
function renderPermissionOptions(data) {
  const orgSelect = document.getElementById('adminPermissionOrg');
  const gradeSelect = document.getElementById('adminPermissionGrade');
  if (!orgSelect || !gradeSelect) return;
  const orgs = Array.isArray(data.permissionOrganizations) ? data.permissionOrganizations : [];
  if (orgs.length) {
    orgSelect.replaceChildren();
    for (const org of orgs) { const option = document.createElement('option'); option.value = org.key; option.textContent = org.label; orgSelect.appendChild(option); }
  }
  const selectedOrg = orgSelect.value || 'police';
  const jobInfo = (data.permissionJobs || {})[selectedOrg];
  gradeSelect.replaceChildren();
  for (const grade of (jobInfo?.grades || [])) { const option = document.createElement('option'); option.value = String(grade.level); option.textContent = `${grade.label} (Stufe ${grade.level})`; gradeSelect.appendChild(option); }
  const deputyOption = document.createElement('option'); deputyOption.value = '-1'; deputyOption.textContent = 'Stellvertretung (eigene Rechte)'; gradeSelect.appendChild(deputyOption);
  if (!jobInfo?.grades?.length) { const option = document.createElement('option'); option.value = ''; option.textContent = 'Keine QBCore-Ränge gefunden'; gradeSelect.insertBefore(option, deputyOption); }
  loadSelectedPermissions();
}
document.getElementById('adminPermissionOrg')?.addEventListener('change', () => renderPermissionOptions(adminTabletData));
document.getElementById('adminPermissionGrade')?.addEventListener('change', loadSelectedPermissions);
document.getElementById('adminPoliceTestModeSave')?.addEventListener('click', () => {
  const enabled = document.getElementById('adminPoliceTestMode')?.checked === true;
  const status = document.getElementById('adminPoliceTestModeStatus');
  if (status) status.textContent = 'Testmodus-Einstellung wird gespeichert …';
  adminAction('save-police-test-mode', { enabled });
});
document.getElementById('adminWeaponPermitFeeSave')?.addEventListener('click', () => {
  const input = document.getElementById('adminWeaponPermitFee');
  const amount = Number(input?.value);
  const status = document.getElementById('adminWeaponPermitFeeStatus');
  if (!Number.isInteger(amount) || amount < 0 || amount > 1000000) { if (status) status.textContent = 'Bitte einen ganzen Betrag zwischen 0 und 1.000.000 $ eingeben.'; return; }
  if (status) status.textContent = 'Gebühr wird gespeichert …';
  adminAction('save-weapon-permit-fee', { amount });
});

document.getElementById('adminPermissionSave')?.addEventListener('click', () => {
  const orgKey = document.getElementById('adminPermissionOrg')?.value || 'police';
  const gradeLevel = Number(document.getElementById('adminPermissionGrade')?.value);
  if (!Number.isInteger(gradeLevel) || (gradeLevel < 0 && gradeLevel !== -1)) { const status = document.getElementById('adminPermissionStatus'); if(status) status.textContent='Bitte zuerst einen gültigen Rang auswählen.'; return; }
  const permissions = {};
  document.querySelectorAll('#adminPermissionList input[data-permission]').forEach(input => { permissions[input.dataset.permission] = input.checked === true; });
  adminAction('save-rank-permissions', { orgKey, gradeLevel, permissions });
});

function renderAdminData(data) {
  adminTabletData = data || { photo: [], pickup: [], policePickup: [], pc: [], policeMembers: [] };
  renderAdminList('adminPhotoList', adminTabletData.photo, 'photo');
  renderAdminList('adminPickupList', adminTabletData.pickup, 'pickup');
  renderAdminList('adminPolicePickupList', adminTabletData.policePickup, 'police-pickup');
  renderAdminList('adminPcList', adminTabletData.pc, 'pc');
  renderAdminHistory(adminTabletData.history || []);
  renderAdminHistoryInto('adminSystemHistory', adminTabletData.history || []);
  renderAdminOrgNotes(adminTabletData.notes || []);
  renderPoliceMembers(adminTabletData.policeMembers || []);
  renderPermissionOptions(adminTabletData);
  const feeInput = document.getElementById('adminWeaponPermitFee');
  const feeStatus = document.getElementById('adminWeaponPermitFeeStatus');
  const savedFee = Number(adminTabletData.systemSettings?.weaponPermitTabletFee ?? 6500);
  if (feeInput && document.activeElement !== feeInput) feeInput.value = String(Number.isFinite(savedFee) ? savedFee : 6500);
  if (feeStatus) feeStatus.textContent = `Aktuell gespeicherte Gebühr: ${Number.isFinite(savedFee) ? savedFee.toLocaleString('de-DE') : '6.500'} $. Änderungen werden sofort im Polizeisystem verwendet. Polizeimitglieder bleiben kostenlos.`;
  const testModeToggle = document.getElementById('adminPoliceTestMode');
  if (testModeToggle && document.activeElement !== testModeToggle) testModeToggle.checked = adminTabletData.systemSettings?.policeTestMode === true;
  const testModeStatus = document.getElementById('adminPoliceTestModeStatus');
  if (testModeStatus) testModeStatus.textContent = adminTabletData.systemSettings?.policeTestMode === true ? 'Testmodus ist AKTIV. Ausschließlich serverseitig bestätigte Serveradmins dürfen eigene Dokumente testen; andere Spieler erhalten dadurch keine Testberechtigung.' : 'Testmodus ist AUS. Es gelten die regulären Job- und Rangberechtigungen; Admin-Selbstausstellung ist gesperrt.';
  const summary = document.getElementById('adminSummary'); if (summary) summary.textContent = `Fotostationen: ${(adminTabletData.photo||[]).length}   ·   Abholpunkte: ${(adminTabletData.pickup||[]).length}   ·   Organisations-PCs: ${(adminTabletData.pc||[]).length}`;
}
function closeAdminTablet() { hideElement(adminTablet); postNui('closeAdminTablet'); }
document.getElementById('closeAdminTablet')?.addEventListener('click', closeAdminTablet);
document.querySelectorAll('[data-admin-page]').forEach(btn => btn.addEventListener('click', () => {
  const page = btn.dataset.adminPage;
  if (!page) return;
  const navPage = (page.startsWith('commands-') || page.startsWith('settings-')) ? 'settings' : page;
  document.querySelectorAll('.admin-nav-btn').forEach(nav => nav.classList.toggle('active', nav.dataset.page === navPage));
  document.querySelectorAll('.admin-page').forEach(section => section.classList.toggle('hidden', section.id !== `adminPage-${page}`));
}));
document.querySelectorAll('.admin-nav-btn').forEach(btn => btn.addEventListener('click', () => {
  document.querySelectorAll('.admin-nav-btn').forEach(b => b.classList.toggle('active', b === btn));
  document.querySelectorAll('.admin-page').forEach(page => page.classList.toggle('hidden', page.id !== `adminPage-${btn.dataset.page}`));
  if (['notes','police','permissions','settings'].includes(btn.dataset.page)) postNui('adminTabletAction', { action: 'refresh' });
}));
document.querySelectorAll('[data-action]').forEach(btn => btn.addEventListener('click', () => {
  const action = btn.dataset.action;
  if (action === 'create-pickup' || action === 'create-police-pickup') adminAction(action, { name: action === 'create-pickup' ? 'Personalausweis Abholstation' : 'Polizei-Ausgabestelle' });
  else if (action === 'create-pc') adminAction(action, { orgKey: document.getElementById('adminOrgKey')?.value || 'police', name: document.getElementById('adminPcName')?.value || '' });
  else adminAction(action);
}));
window.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (adminTablet && !adminTablet.classList.contains('hidden')) closeAdminTablet();
  else if (myDocumentsPanel && !myDocumentsPanel.classList.contains('hidden')) closeMyDocuments();
  else if (orgTablet && !orgTablet.classList.contains('hidden')) { hideElement(orgTablet); postNui('closeOrgTablet'); }
});


document.getElementById("orgArchiveAllButton")?.addEventListener("click", (event) => { const button = event.currentTarget; if (button.dataset.busy === 'true') return; button.dataset.busy = 'true'; button.disabled = true; button.textContent = 'Archivierung läuft …'; postNui("archiveAllOrgProtocols"); setTimeout(() => { button.dataset.busy = 'false'; button.disabled = false; button.textContent = 'Bisherige Protokolle ins Monatsarchiv verschieben'; }, 8000); });

