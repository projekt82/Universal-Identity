local QBCore = exports['qb-core']:GetCoreObject()
local RESOURCE = GetCurrentResourceName()
local DocumentsReady = false
local PersonalPickupLocations, OrgPcLocations = {}, {}
local VerifiedDeputyCandidates = {}
local WeaponPermitTabletFee = math.max(0, math.floor(tonumber(Config.Documents and Config.Documents.WeaponPermitTabletFee) or 6500))
local PoliceTestModeEnabled = Config.Documents and Config.Documents.PoliceTestMode == true
local PoliceFreelancerTestAccessEnabled = false -- im öffentlichen Release fest deaktiviert

CreateThread(function()
    Wait(1500)
    local ok, err = pcall(function()
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS ui_org_termination_logs (
            id INT NOT NULL AUTO_INCREMENT,
            org_key VARCHAR(60) NOT NULL,
            employee_identifier VARCHAR(100) NOT NULL,
            employee_name VARCHAR(120) NOT NULL,
            terminated_by_identifier VARCHAR(100) NULL,
            terminated_by_name VARCHAR(120) NULL,
            reason VARCHAR(1000) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), KEY idx_ui_term_org (org_key), KEY idx_ui_term_employee (employee_identifier)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]], {})
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS ui_org_protocol_archive (
            id INT NOT NULL AUTO_INCREMENT,
            org_key VARCHAR(60) NOT NULL,
            source_type VARCHAR(30) NOT NULL,
            source_id INT NOT NULL,
            archive_month CHAR(7) NOT NULL,
            title VARCHAR(180) NOT NULL,
            payload LONGTEXT NOT NULL,
            archived_by_name VARCHAR(120) NULL,
            archived_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY uq_ui_protocol_source (org_key, source_type, source_id), KEY idx_ui_protocol_month (org_key, archive_month)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]], {})
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS ui_org_employment_dates (
            org_key VARCHAR(60) NOT NULL,
            identifier VARCHAR(100) NOT NULL,
            employee_name VARCHAR(120) NOT NULL,
            hired_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (org_key, identifier)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]], {})
        -- Existing installs may already have this table without employee_name.
        -- Migrate it in place without deleting existing employment dates.
        MySQL.query.await([[ALTER TABLE ui_org_employment_dates
            ADD COLUMN IF NOT EXISTS employee_name VARCHAR(120) NOT NULL DEFAULT '' ]], {})
        MySQL.query.await([[ALTER TABLE ui_org_employment_dates
            ADD COLUMN IF NOT EXISTS hired_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ]], {})
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS ui_org_notes (
            id INT NOT NULL AUTO_INCREMENT,
            org_key VARCHAR(60) NOT NULL,
            author_identifier VARCHAR(100) NOT NULL,
            author_name VARCHAR(120) NOT NULL,
            author_server_id INT NOT NULL,
            note_text TEXT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), KEY idx_ui_org_notes_org (org_key), KEY idx_ui_org_notes_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]], {})
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS ui_org_rank_permissions (
            org_key VARCHAR(60) NOT NULL,
            grade_level INT NOT NULL,
            permissions LONGTEXT NOT NULL,
            updated_by VARCHAR(100) NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (org_key, grade_level)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]], {})
        MySQL.query.await([[ALTER TABLE ui_org_notes ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'pending']], {})
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS ui_org_announcements (id INT NOT NULL AUTO_INCREMENT, org_key VARCHAR(60) NOT NULL, title VARCHAR(140) NOT NULL, body TEXT NOT NULL, author_identifier VARCHAR(100) NOT NULL, author_name VARCHAR(120) NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(id), KEY idx_ui_org_announcements_org (org_key, created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]], {})
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS ui_org_announcement_reads (
            org_key VARCHAR(60) NOT NULL,
            announcement_id INT NOT NULL,
            identifier VARCHAR(100) NOT NULL,
            read_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (org_key, announcement_id, identifier),
            KEY idx_ui_announcement_reads_identifier (identifier)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]], {})
    end)
    if not ok then print(('^1[Universal Identity] Konnte ui_org_termination_logs nicht anlegen: %s^7'):format(tostring(err))) end
end)


AddEventHandler('playerJoining', function()
    local playerId = source
    TriggerClientEvent('universal_identity:policeTestModeState', playerId, PoliceTestModeEnabled == true, PoliceFreelancerTestAccessEnabled == true)
end)

RegisterNetEvent('universal_identity:requestPoliceTestModeState', function()
    TriggerClientEvent('universal_identity:policeTestModeState', source, PoliceTestModeEnabled == true, PoliceFreelancerTestAccessEnabled == true)
end)

local function log(message) print(('[Universal Identity] %s'):format(message)) end
local function notify(src, message, kind)
    TriggerClientEvent('QBCore:Notify', src, message, kind or 'primary', 6000)
end
local function adminAllowed(src)
    if src == 0 then return true end
    if IsPlayerAceAllowed(src, Config.AdminAcePermission or 'universal_identity.admin') or IsPlayerAceAllowed(src, 'group.admin') then return true end
    for _, permission in ipairs({ 'god', 'admin' }) do
        local ok, allowed = pcall(function() return QBCore.Functions.HasPermission(src, permission) end)
        if ok and allowed then return true end
    end
    return false
end
local function charId(src)
    local p = QBCore.Functions.GetPlayer(tonumber(src))
    return p and p.PlayerData and p.PlayerData.citizenid or nil
end
local function playerName(src)
    local p = QBCore.Functions.GetPlayer(tonumber(src))
    local c = p and p.PlayerData and p.PlayerData.charinfo or {}
    return (('%s %s'):format(c.firstname or GetPlayerName(src) or 'Unbekannt', c.lastname or '')):gsub('%s+$', '')
end
-- Begrenzter RAM-Cache für häufig angezeigte Mitarbeiterfotos.
-- Neue/ersetzte Fotos invalidieren ihren Eintrag in server/photos.lua.
UIDPhotoDataUriCache = UIDPhotoDataUriCache or {}
UIDPhotoDataUriCacheOrder = UIDPhotoDataUriCacheOrder or {}
local PHOTO_DATA_URI_CACHE_LIMIT = 64
local function photoDataUri(identifier)
    if not identifier or tostring(identifier) == '' then return nil end
    identifier = tostring(identifier)
    local cached = UIDPhotoDataUriCache[identifier]
    if cached then return cached end
    local bytes = LoadResourceFile(RESOURCE, ('photos/%s.jpg'):format(identifier))
    if not bytes or #bytes == 0 then return nil end
    local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    local out = {}
    for i = 1, #bytes, 3 do
        local a, b, c = bytes:byte(i, i + 2); b = b or 0; c = c or 0
        local n = a * 65536 + b * 256 + c
        local x1 = math.floor(n / 262144) % 64 + 1
        local x2 = math.floor(n / 4096) % 64 + 1
        local x3 = math.floor(n / 64) % 64 + 1
        local x4 = n % 64 + 1
        out[#out + 1] = chars:sub(x1, x1) .. chars:sub(x2, x2) .. (i + 1 <= #bytes and chars:sub(x3, x3) or '=') .. (i + 2 <= #bytes and chars:sub(x4, x4) or '=')
    end
    local dataUri = 'data:image/jpeg;base64,' .. table.concat(out)
    UIDPhotoDataUriCache[identifier] = dataUri
    UIDPhotoDataUriCacheOrder[#UIDPhotoDataUriCacheOrder + 1] = identifier
    if #UIDPhotoDataUriCacheOrder > PHOTO_DATA_URI_CACHE_LIMIT then
        local evicted = table.remove(UIDPhotoDataUriCacheOrder, 1)
        if evicted then UIDPhotoDataUriCache[evicted] = nil end
    end
    return dataUri
end

local function hasPhoto(identifier)
    if not identifier then return false end
    local ok, row = pcall(function()
        return MySQL.single.await('SELECT photo_path FROM ui_character_photos WHERE identifier = ? LIMIT 1', { identifier })
    end)
    if not ok or not row or type(row.photo_path) ~= 'string' then return false end
    local expected = ('photos/%s.jpg'):format(identifier)
    if row.photo_path ~= expected then return false end
    local bytes = LoadResourceFile(RESOURCE, expected)
    return bytes ~= nil and #bytes > 0
end
local function getHighestJobGrade(jobName, fallback)
    local jobs = QBCore.Shared and QBCore.Shared.Jobs or {}
    local job = jobs[jobName]
    local grades = job and job.grades
    local highest = nil
    if type(grades) == 'table' then
        for key, gradeData in pairs(grades) do
            local level = tonumber(key) or (type(gradeData) == 'table' and tonumber(gradeData.level))
            if level and (highest == nil or level > highest) then highest = level end
        end
    end
    return highest or tonumber(fallback) or 999
end

local function isHighestOrganisationRank(job, org)
    if not job or not org or job.name ~= org.job then return false end
    local grade = tonumber((job.grade or {}).level or job.grade) or 0
    return grade >= getHighestJobGrade(org.job, org.minimumGrade)
end

local function hasValidConfiguredJobRank(src, orgKey)
    local player = QBCore.Functions.GetPlayer(src)
    local org = Config.Documents.Organisations[orgKey]
    if not player or not org then return false end
    local job = player.PlayerData.job or {}
    if job.name ~= org.job then return false end
    local grade = tonumber((job.grade or {}).level or job.grade)
    if not grade then return false end
    local sharedJob = QBCore.Shared and QBCore.Shared.Jobs and QBCore.Shared.Jobs[org.job]
    local grades = sharedJob and sharedJob.grades
    if type(grades) ~= 'table' then return false end
    return grades[tostring(grade)] ~= nil or grades[grade] ~= nil
end

local function isPoliceTestMode(orgKey)
    return orgKey == 'police' and PoliceTestModeEnabled == true
end

-- Legacy-Hilfsfunktion bleibt für Kompatibilität im Code, gewährt im Release aber nie Zugriff.
-- Die Rolle ist zusätzlich zum globalen Testmodus explizit im Admin-Menü freizuschalten.
local function hasFreelancerTestAccess(src, orgKey)
    -- Die Freelancer-Testrolle ist im öffentlichen Release vollständig deaktiviert.
    return false
end

local function hasPoliceTestIssuerAccess(src, orgKey)
    -- Der Testmodus ist ausschließlich ein Admin-Selbsttest, kein allgemeiner Polizeizugang.
    return isPoliceTestMode(orgKey) and Config.Documents.AllowSelfIssueForTesting == true and adminAllowed(src)
end

local function requirePoliceAccess(src)
    local player = QBCore.Functions.GetPlayer(src)
    local job = player and player.PlayerData and player.PlayerData.job or {}
    local org = Config.Documents.Organisations and Config.Documents.Organisations.police or {}
    local orgJob = tostring(org.job or 'police')
    local allowed = hasPoliceTestIssuerAccess(src, 'police') or hasValidConfiguredJobRank(src, 'police')
    if not allowed then
        notify(src, 'Zugriff verweigert: Nur Polizeibeamte dürfen diese Ausgabestelle benutzen.', 'error')
        return false
    end
    return true
end

local function getOrgAccess(src, orgKey)
    local org = Config.Documents.Organisations[orgKey]
    if not org then return nil, 'Diese Organisation ist nicht konfiguriert.' end
    local p = QBCore.Functions.GetPlayer(src)
    if not p then return nil, 'Spieler nicht gefunden.' end
    local job = p.PlayerData.job or {}
    local grade = tonumber((job.grade or {}).level or job.grade)
    -- Im vollständigen Polizeitestmodus sind Job, Rang und Organisationszugehörigkeit
    -- für den Aussteller nicht erforderlich. Außerhalb des Testmodus bleibt alles geschützt.
    local fullTestAccess = hasFreelancerTestAccess(src, orgKey)
    local adminTestAccess = isPoliceTestMode(orgKey) and Config.Documents.AllowSelfIssueForTesting == true and adminAllowed(src)
    if not adminTestAccess and job.name ~= org.job then return nil, 'Du gehörst nicht zu dieser Organisation.' end
    if adminTestAccess then
        grade = grade or 0
    elseif not grade or not hasValidConfiguredJobRank(src, orgKey) then
        return nil, 'Dein Organisationsrang ist ungültig oder nicht in QBCore konfiguriert.'
    end
    local leader = isHighestOrganisationRank(job, org)
    local appointed = nil
    local deputy = false
    if not leader then
        appointed = MySQL.scalar.await('SELECT identifier FROM ui_org_deputies WHERE org_key = ? LIMIT 1', { orgKey })
        deputy = appointed ~= nil and appointed == p.PlayerData.citizenid
    end
    return { org = org, grade = grade, deputy = deputy, leader = leader, member = job.name == org.job, testAccess = fullTestAccess or adminTestAccess, adminTestAccess = adminTestAccess, name = playerName(src) }
end
local VALID_ORG_PERMISSIONS = {
    view_employee = true, issue_org_document = true, hire_employee = true, manage_employee_job = true,
    fire_employee = true, manage_deputy = true, view_issue_logs = true,
    publish_announcements = true, delete_announcements = true
}
local function hasOrgPermission(src, orgKey, permissionKey, fallbackAllowed)
    if not VALID_ORG_PERMISSIONS[permissionKey] then return false end
    local player = QBCore.Functions.GetPlayer(src)
    if not player then return false end
    local job = player.PlayerData.job or {}
    local org = Config.Documents.Organisations[orgKey]
    -- Der Polizei-Testmodus verleiht normalen Spielern keine zusätzlichen Rechte.
    if not org then return false end
    if hasFreelancerTestAccess(src, orgKey) then return true end
    if job.name ~= org.job then return false end
    local sharedJob = QBCore.Shared and QBCore.Shared.Jobs and QBCore.Shared.Jobs[org.job]
    local sharedGrades = sharedJob and sharedJob.grades or {}
    local playerGrade = job.grade or {}
    local resolvedGrade = type(playerGrade) == 'table' and tonumber(playerGrade.level or playerGrade.grade) or tonumber(playerGrade)
    local validRank = false
    if resolvedGrade and type(sharedGrades) == 'table' then
        for key, gradeData in pairs(sharedGrades) do
            local candidateLevel = type(gradeData) == 'table' and tonumber(gradeData.level or gradeData.grade) or tonumber(key)
            if candidateLevel == resolvedGrade then validRank = true; break end
        end
    end
    -- Fehlende/ungültige QBCore-Rangdaten führen immer zur Ablehnung.
    if not validRank then return false end
    local appointedDeputy = MySQL.scalar.await('SELECT identifier FROM ui_org_deputies WHERE org_key = ? LIMIT 1', { orgKey })
    local isDeputy = appointedDeputy ~= nil and tostring(appointedDeputy) == tostring(player.PlayerData.citizenid)
    local grade = isDeputy and -1 or resolvedGrade
    if not grade then return false end
    local row = MySQL.single.await('SELECT permissions FROM ui_org_rank_permissions WHERE org_key = ? AND grade_level = ? LIMIT 1', { orgKey, grade })
    -- Ohne ausdrücklich gespeicherte Rangrechte wird die Aktion verweigert.
    if not row then return false end
    local ok, permissions = pcall(json.decode, row.permissions or '{}')
    if not ok or type(permissions) ~= 'table' then return false end
    return permissions[permissionKey] == true
end

local function notifyOrgPermissionDenied(src, message)
    message = tostring(message or 'Du bist für diese Aktion nicht berechtigt.')
    notify(src, message, 'error')
    TriggerClientEvent('universal_identity:orgPermissionDenied', src, message)
end

local function loadLocations()
    if not DocumentsReady then return end
    PersonalPickupLocations = MySQL.query.await('SELECT id, name, x, y, z, heading, station_type FROM ui_document_pickups', {}) or {}
    OrgPcLocations = MySQL.query.await("SELECT id, org_key, name, x, y, z, heading FROM ui_org_pcs WHERE org_key = 'police'", {}) or {}
    TriggerClientEvent('universal_identity:documentLocations', -1, PersonalPickupLocations, OrgPcLocations)
end
local function waitReady()
    for _ = 1, 100 do if DocumentsReady then return true end Wait(100) end
    return DocumentsReady
end
local function isNearPickupType(src, stationType, maxDistance)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false end
    local coords = GetEntityCoords(ped)
    for _, loc in ipairs(PersonalPickupLocations or {}) do
        if tostring(loc.station_type or 'police') == stationType then
            local pos = vector3(tonumber(loc.x) or 0, tonumber(loc.y) or 0, tonumber(loc.z) or 0)
            if #(coords - pos) <= (maxDistance or 3.0) then return true end
        end
    end
    return false
end

local function isNearLocation(src, locations, orgKey, maxDistance)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false end
    local coords = GetEntityCoords(ped)
    for _, loc in ipairs(locations or {}) do
        if not orgKey or loc.org_key == orgKey then
            local pos = vector3(tonumber(loc.x) or 0, tonumber(loc.y) or 0, tonumber(loc.z) or 0)
            if #(coords - pos) <= (maxDistance or 3.0) then return true end
        end
    end
    return false
end

CreateThread(function()
    local ok, err = pcall(function()
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS ui_universal_documents (
                id INT NOT NULL AUTO_INCREMENT,
                document_number VARCHAR(40) NOT NULL,
                document_type VARCHAR(40) NOT NULL,
                owner_identifier VARCHAR(100) NOT NULL,
                owner_name VARCHAR(120) NOT NULL,
                organisation_key VARCHAR(60) NULL,
                rank_label VARCHAR(100) NULL,
                rank_level INT NULL,
                status VARCHAR(32) NOT NULL DEFAULT 'ready',
                issued_by VARCHAR(100) NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                handed_over_at TIMESTAMP NULL DEFAULT NULL,
                PRIMARY KEY (id), UNIQUE KEY uq_ui_doc_number (document_number),
                KEY idx_ui_doc_owner (owner_identifier), KEY idx_ui_doc_type (document_type)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ]])
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS ui_document_audit (
                id INT NOT NULL AUTO_INCREMENT, document_id INT NULL, document_number VARCHAR(40) NULL,
                document_type VARCHAR(40) NOT NULL, owner_identifier VARCHAR(100) NOT NULL, owner_name VARCHAR(120) NOT NULL,
                action VARCHAR(40) NOT NULL, actor_identifier VARCHAR(100) NULL, actor_name VARCHAR(120) NULL,
                target_identifier VARCHAR(100) NULL, target_name VARCHAR(120) NULL, details VARCHAR(255) NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id),
                KEY idx_ui_audit_owner (owner_identifier), KEY idx_ui_audit_document (document_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ]])
        pcall(function() MySQL.query.await('ALTER TABLE ui_universal_documents ADD COLUMN issued_by_name VARCHAR(120) NULL') end)
        -- Additive migration: stores the exact QBCore grade selected for a Dienstausweis.
        pcall(function() MySQL.query.await('ALTER TABLE ui_universal_documents ADD COLUMN rank_level INT NULL') end)
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS ui_document_pickups (
                id INT NOT NULL AUTO_INCREMENT, name VARCHAR(100) NOT NULL DEFAULT 'Ausweis-Ausgabe',
                x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, heading DOUBLE NOT NULL DEFAULT 0,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ]])
        -- Migration: existing locations remain police pickup points; new ID stations are typed explicitly.
        pcall(function() MySQL.query.await("ALTER TABLE ui_document_pickups ADD COLUMN station_type VARCHAR(20) NOT NULL DEFAULT 'police'") end)
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS ui_org_deputies (
                org_key VARCHAR(60) NOT NULL, identifier VARCHAR(100) NOT NULL, appointed_by VARCHAR(100) NOT NULL,
                appointed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (org_key), UNIQUE KEY uq_ui_org_deputy (identifier)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ]])
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS ui_org_pcs (
                id INT NOT NULL AUTO_INCREMENT, org_key VARCHAR(60) NOT NULL,
                name VARCHAR(100) NOT NULL DEFAULT 'Organisations-PC', x DOUBLE NOT NULL, y DOUBLE NOT NULL,
                z DOUBLE NOT NULL, heading DOUBLE NOT NULL DEFAULT 0,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY idx_ui_org_pc (org_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ]])
        MySQL.query.await([[CREATE TABLE IF NOT EXISTS ui_system_settings (
            setting_key VARCHAR(80) NOT NULL,
            setting_value VARCHAR(255) NOT NULL,
            updated_by VARCHAR(100) NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (setting_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]], {})
        local feeRow = MySQL.single.await('SELECT setting_value FROM ui_system_settings WHERE setting_key = ? LIMIT 1', { 'weapon_permit_tablet_fee' })
        if feeRow and tonumber(feeRow.setting_value) then
            WeaponPermitTabletFee = math.max(0, math.floor(tonumber(feeRow.setting_value)))
        else
            MySQL.insert.await('INSERT IGNORE INTO ui_system_settings (setting_key, setting_value, updated_by) VALUES (?, ?, ?)', { 'weapon_permit_tablet_fee', tostring(WeaponPermitTabletFee), 'system' })
        end
        local testModeRow = MySQL.single.await('SELECT setting_value FROM ui_system_settings WHERE setting_key = ? LIMIT 1', { 'police_test_mode' })
        if testModeRow then
            PoliceTestModeEnabled = tostring(testModeRow.setting_value) == '1' or tostring(testModeRow.setting_value):lower() == 'true'
        else
            MySQL.insert.await('INSERT IGNORE INTO ui_system_settings (setting_key, setting_value, updated_by) VALUES (?, ?, ?)', { 'police_test_mode', PoliceTestModeEnabled and '1' or '0', 'system' })
        end
        -- Legacy-Freelancer-Einstellung bleibt in der DB unangetastet, wird im Release aber ignoriert.
        PoliceFreelancerTestAccessEnabled = false
        -- Additive migration: records remain intact; existing documents default to normal (non-recruitment).
        MySQL.query.await([[ALTER TABLE ui_universal_documents ADD COLUMN IF NOT EXISTS is_recruitment TINYINT(1) NOT NULL DEFAULT 0]], {})
    end)
    if not ok then log(('Dokumentendatenbank konnte nicht initialisiert werden: %s'):format(tostring(err))); return end
    -- Vorhandene Organisations-PC-Datensätze anderer Schlüssel bleiben unangetastet.

    DocumentsReady = true
    TriggerClientEvent('universal_identity:policeTestModeState', -1, PoliceTestModeEnabled == true, PoliceFreelancerTestAccessEnabled == true)
    MySQL.update.await("UPDATE ui_universal_documents SET status = 'ready' WHERE document_type = 'personal_id' AND status = 'processing'", {})
    loadLocations()
    for _ = 1, 100 do if PhotoSystemDatabaseReady then break end Wait(100) end
    local savedPhotos = {}
    if PhotoSystemDatabaseReady then
        local photosOk, photosRows = pcall(function() return MySQL.query.await('SELECT identifier FROM ui_character_photos', {}) end)
        if photosOk and photosRows then savedPhotos = photosRows end
        for _, photo in ipairs(savedPhotos) do
            if photo.identifier then pcall(CreatePersonalIdentityDocument, photo.identifier) end
        end
    end
    log(('Dokumentensystem-Datenbank bereit; vorhandene Fotos geprüft: %d.'):format(#savedPhotos))
end)

local function makeNumber(prefix)
    return ('%s-%s-%04d'):format(prefix, os.date('%y%m%d%H%M%S'), math.random(0, 9999))
end

local function auditDocument(doc, action, src, details, target)
    if not doc then return end
    local actor = src and src > 0 and QBCore.Functions.GetPlayer(src) or nil
    local actorIdentifier = actor and actor.PlayerData and actor.PlayerData.citizenid or (src == 0 and 'console' or nil)
    local actorName = actor and playerName(src) or (src == 0 and 'Universal Identity / System' or 'Universal Identity')
    local targetPlayer = target and QBCore.Functions.GetPlayer(target) or nil
    local targetIdentifier = targetPlayer and targetPlayer.PlayerData and targetPlayer.PlayerData.citizenid or nil
    local targetName = targetPlayer and playerName(target) or nil
    pcall(function()
        MySQL.insert.await([[
            INSERT INTO ui_document_audit
            (document_id, document_number, document_type, owner_identifier, owner_name, action, actor_identifier, actor_name, target_identifier, target_name, details)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ]], { doc.id, doc.document_number, doc.document_type, doc.owner_identifier, doc.owner_name, action, actorIdentifier, actorName, targetIdentifier, targetName, details })
    end)
end

function CreatePersonalIdentityDocument(identifier)
    if not identifier or not waitReady() then return false end
    if not hasPhoto(identifier) then return false end
    local player = QBCore.Functions.GetPlayerByCitizenId(identifier)
    local ownerName = 'Charakter'
    if player and player.PlayerData and player.PlayerData.charinfo then
        local c = player.PlayerData.charinfo
        ownerName = (('%s %s'):format(c.firstname or '', c.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
    else
        local ok, row = pcall(function() return MySQL.single.await('SELECT charinfo FROM players WHERE citizenid = ? LIMIT 1', { identifier }) end)
        if ok and row and type(row.charinfo) == 'string' then
            local decodedOk, info = pcall(json.decode, row.charinfo)
            if decodedOk and type(info) == 'table' then
                ownerName = (('%s %s'):format(info.firstname or '', info.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
            end
        end
    end
    local existing = MySQL.single.await("SELECT id FROM ui_universal_documents WHERE owner_identifier = ? AND document_type = 'personal_id' LIMIT 1", { identifier })
    if existing then
        MySQL.update.await("UPDATE ui_universal_documents SET owner_name = ?, issued_by_name = COALESCE(issued_by_name, 'Universal Identity / Fotostation') WHERE id = ?", { ownerName, existing.id })
        return true
    end
    MySQL.insert.await([[
        INSERT INTO ui_universal_documents (document_number, document_type, owner_identifier, owner_name, status, issued_by, issued_by_name)
        VALUES (?, 'personal_id', ?, ?, 'ready', 'system', 'Universal Identity / Fotostation')
    ]], { makeNumber('ID'), identifier, ownerName })
    local created = MySQL.single.await("SELECT id, document_number, document_type, owner_identifier, owner_name FROM ui_universal_documents WHERE owner_identifier = ? AND document_type = 'personal_id' ORDER BY id DESC LIMIT 1", { identifier })
    auditDocument(created, 'created_ready', 0, 'Personalausweis nach bestätigtem Foto erstellt.')
    log(('Personalausweis für Charakter %s ist abholbereit.'):format(identifier))
    return true
end


RegisterNetEvent('universal_identity:requestDocumentLocations', function()
    if not waitReady() then return end
    TriggerClientEvent('universal_identity:documentLocations', source, PersonalPickupLocations, OrgPcLocations)
end)

local function getDeputyOverview(orgKey)
    local row = MySQL.single.await('SELECT d.identifier, p.charinfo, p.job FROM ui_org_deputies d LEFT JOIN players p ON p.citizenid = d.identifier WHERE d.org_key = ? LIMIT 1', { orgKey })
    if not row then return { name = nil, online = false, rank = 'Kein Rang hinterlegt' } end
    local name = 'Unbekannter Mitarbeiter'
    local rankName = 'Rang unbekannt'
    if row.charinfo and type(row.charinfo) == 'string' then
        local ok, info = pcall(json.decode, row.charinfo)
        if ok and info then name = ((info.firstname or '') .. ' ' .. (info.lastname or '')):gsub('^%s*(.-)%s*$', '%1') end
    end
    if row.job and type(row.job) == 'string' then
        local ok, jobData = pcall(json.decode, row.job)
        if ok and type(jobData) == 'table' then
            local grade = jobData.grade
            if type(grade) == 'table' then rankName = tostring(grade.name or grade.label or grade.level or rankName) end
        end
    end
    local serverId = nil
    for _, id in ipairs(QBCore.Functions.GetPlayers()) do
        local player = QBCore.Functions.GetPlayer(tonumber(id))
        if player and player.PlayerData and player.PlayerData.citizenid == row.identifier then
            serverId = tonumber(id)
            local c = player.PlayerData.charinfo or {}
            name = ((c.firstname or '') .. ' ' .. (c.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
            local job = player.PlayerData.job or {}
            local grade = job.grade or {}
            rankName = tostring(type(grade) == 'table' and (grade.name or grade.label or grade.level) or grade or rankName)
            break
        end
    end
    return { name = name, online = serverId ~= nil, serverId = serverId, rank = rankName }
end

RegisterNetEvent('universal_identity:openOrgTablet', function(orgKey)
    local src = source
    if not waitReady() then notify(src, 'Dokumentensystem ist noch nicht bereit.', 'error'); return end
    orgKey = tostring(orgKey or '')
    local access, err = getOrgAccess(src, orgKey)
    if not access then notify(src, err, 'error'); return end
    local adminSelfTest = isPoliceTestMode(orgKey) and Config.Documents.AllowSelfIssueForTesting == true and adminAllowed(src)
    -- Serveradmins dürfen das Polizeitablet im aktiven Testmodus zum eigenen Dokumententest öffnen.
    if not adminSelfTest and not isNearLocation(src, OrgPcLocations, orgKey, (Config.Documents.OrgPcInteractionDistance or 2.0) + 1.0) then notify(src, 'Du musst am konfigurierten Organisations-PC stehen.', 'error'); return end
    local deputy = getDeputyOverview(orgKey)
    local currentPlayer = QBCore.Functions.GetPlayer(src)
    local money = currentPlayer and currentPlayer.PlayerData.money or {}
    local currentJob = currentPlayer and currentPlayer.PlayerData.job or {}
    local currentGrade = currentJob.grade or {}
    local currentRank = type(currentGrade) == 'table' and tostring(currentGrade.name or currentGrade.label or currentGrade.level or 'Unbekannt') or tostring(currentGrade or 'Unbekannt')
    local hireDate = currentPlayer and MySQL.scalar.await('SELECT hired_at FROM ui_org_employment_dates WHERE org_key = ? AND identifier = ? LIMIT 1', { orgKey, currentPlayer.PlayerData.citizenid }) or nil
    TriggerClientEvent('universal_identity:showOrgTablet', src, orgKey, access.org.label, playerName(src), deputy, { cash = tonumber(money.cash) or 0, bank = tonumber(money.bank) or 0, rank = currentRank, hiredAt = hireDate, testMode = isPoliceTestMode(orgKey), adminSelfIssue = adminSelfTest, isServerAdmin = adminAllowed(src), serverDateTime = os.date('%d.%m.%Y · %H:%M:%S') })
end)

RegisterNetEvent('universal_identity:requestOrgTerminationLogs', function(orgKey)
    local src = source
    orgKey = tostring(orgKey or '')
    local access, err = getOrgAccess(src, orgKey)
    if not access or not hasOrgPermission(src, orgKey, 'view_issue_logs', access.leader or access.deputy) then TriggerClientEvent('universal_identity:orgTerminationLogs', src, {}); notifyOrgPermissionDenied(src, 'Du hast keine Berechtigung, Vorgangsprotokolle anzusehen.'); return end
    local rows = MySQL.query.await([[SELECT t.id, t.employee_name, t.terminated_by_name, t.reason, t.created_at FROM ui_org_termination_logs t WHERE t.org_key = ? AND NOT EXISTS (SELECT 1 FROM ui_org_protocol_archive ar WHERE ar.org_key = t.org_key AND ar.source_type = 'termination' AND ar.source_id = t.id) ORDER BY t.id DESC LIMIT 100]], { orgKey }) or {}
    TriggerClientEvent('universal_identity:orgTerminationLogs', src, rows)
end)
RegisterNetEvent('universal_identity:requestOrgIssueLogs', function(orgKey)
    local src = source
    orgKey = tostring(orgKey or '')
    local access = getOrgAccess(src, orgKey)
    if not access or not hasOrgPermission(src, orgKey, 'view_issue_logs', access.leader or access.deputy) then TriggerClientEvent('universal_identity:orgIssueLogs', src, {}); notifyOrgPermissionDenied(src, 'Du hast keine Berechtigung, Ausstellungsvorgänge anzusehen.'); return end
    local rows = MySQL.query.await([[SELECT a.id, a.document_id, a.document_number, a.document_type, a.owner_name, a.action, a.actor_name, a.details, a.created_at
        FROM ui_document_audit a
        LEFT JOIN ui_universal_documents d ON d.id = a.document_id
        WHERE a.document_type IN ('organisation_id', 'weapon_permit')
          AND a.action IN ('issued_waiting_pickup', 'collected_by_issuer', 'handed_to_owner')
          AND a.id = (
              SELECT MAX(a2.id) FROM ui_document_audit a2
              WHERE a2.document_id = a.document_id
                AND a2.action IN ('issued_waiting_pickup', 'collected_by_issuer', 'handed_to_owner')
          )
          AND (d.organisation_key = ? OR a.details LIKE ?)
          AND NOT EXISTS (SELECT 1 FROM ui_org_protocol_archive ar WHERE ar.org_key = ? AND ar.source_type = 'audit' AND ar.source_id = a.id)
        ORDER BY a.id DESC LIMIT 100]], { orgKey, '%Organisation: ' .. tostring(access.org.label or orgKey) .. '%', orgKey }) or {}
    TriggerClientEvent('universal_identity:orgIssueLogs', src, rows)
end)

RegisterNetEvent('universal_identity:searchOrgPersonProtocol', function(orgKey, targetId)
    local src = source
    orgKey = tostring(orgKey or '')
    local access = getOrgAccess(src, orgKey)
    if not access or not hasOrgPermission(src, orgKey, 'view_employee', access.leader or access.deputy) then
        TriggerClientEvent('universal_identity:orgPersonProtocolResult', src, { success = false, message = 'Keine Berechtigung für diese Personalprotokolle.' })
        return
    end
    if not isNearLocation(src, OrgPcLocations, orgKey, (Config.Documents.OrgPcInteractionDistance or 2.0) + 1.0) then
        TriggerClientEvent('universal_identity:orgPersonProtocolResult', src, { success = false, message = 'Du musst am Organisations-PC bleiben.' })
        return
    end
    local target = targetId and QBCore.Functions.GetPlayer(targetId)
    if not target or not target.PlayerData then
        TriggerClientEvent('universal_identity:orgPersonProtocolResult', src, { success = false, message = 'Kein online befindlicher Spieler mit dieser Server-ID gefunden.' })
        return
    end
    local identifier = tostring(target.PlayerData.citizenid or '')
    local name = playerName(targetId)
    local charinfo = target.PlayerData.charinfo or {}
    local job = target.PlayerData.job or {}
    local grade = job.grade or {}
    local photoData = nil
    if hasPhoto(identifier) then
        local bytes = LoadResourceFile(RESOURCE, ('photos/%s.jpg'):format(identifier))
        if bytes and #bytes > 0 then
            local b64 = ''
            local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
            for i = 1, #bytes, 3 do
                local a, b, c = bytes:byte(i, i + 2); b = b or 0; c = c or 0
                local n = a * 65536 + b * 256 + c
                local x1 = math.floor(n / 262144) % 64 + 1
                local x2 = math.floor(n / 4096) % 64 + 1
                local x3 = math.floor(n / 64) % 64 + 1
                local x4 = n % 64 + 1
                b64 = b64 .. chars:sub(x1,x1) .. chars:sub(x2,x2) .. (i + 1 <= #bytes and chars:sub(x3,x3) or '=') .. (i + 2 <= #bytes and chars:sub(x4,x4) or '=')
            end
            photoData = 'data:image/jpeg;base64,' .. b64
        end
    end
    local entries = {}
    local ok, err = pcall(function()
        local terms = MySQL.query.await([[SELECT 'Kündigung' AS entry_type, employee_name AS subject_name, terminated_by_name AS actor_name, reason AS details, created_at
            FROM ui_org_termination_logs WHERE org_key = ? AND (employee_identifier = ? OR terminated_by_identifier = ?)
            ORDER BY id DESC LIMIT 100]], { orgKey, identifier, identifier }) or {}
        for _, row in ipairs(terms) do entries[#entries + 1] = row end
        local audits = MySQL.query.await([[SELECT 'Dokument' AS entry_type, owner_name AS subject_name, actor_name, CONCAT(COALESCE(action, 'Aktion'), ' - ', COALESCE(details, '')) AS details, created_at
            FROM ui_document_audit WHERE (owner_identifier = ? OR target_identifier = ? OR actor_identifier = ?)
            ORDER BY id DESC LIMIT 100]], { identifier, identifier, identifier }) or {}
        for _, row in ipairs(audits) do entries[#entries + 1] = row end
    end)
    if not ok then
        print(('[Universal Identity] Fehler bei Personen-Protokollsuche (Server-ID %s): %s'):format(targetId, tostring(err)))
        TriggerClientEvent('universal_identity:orgPersonProtocolResult', src, { success = false, name = name, serverId = targetId, message = 'Protokolle konnten nicht geladen werden. Bitte Serverkonsole prüfen.' })
        return
    end
    table.sort(entries, function(a, b) return tostring(a.created_at or '') > tostring(b.created_at or '') end)
    TriggerClientEvent('universal_identity:orgPersonProtocolResult', src, { success = true, name = name, serverId = targetId, photo = photoData, person = { citizenid = identifier, firstname = charinfo.firstname, lastname = charinfo.lastname, birthdate = charinfo.birthdate, gender = charinfo.gender, nationality = charinfo.nationality, job = job.label or job.name, grade = grade.name or grade.level, cash = (target.PlayerData.money or {}).cash or 0, bank = (target.PlayerData.money or {}).bank or 0 }, entries = entries, message = #entries > 0 and ('%s (Server-ID %s): %d Protokolleintrag/-einträge gefunden.'):format(name, targetId, #entries) or ('%s (Server-ID %s): Keine Einträge vorhanden.'):format(name, targetId) })
end)

RegisterNetEvent('universal_identity:lookupGeneralPerson', function(orgKey, targetId)
    local src = source
    orgKey = tostring(orgKey or '')
    local access = getOrgAccess(src, orgKey)
    if not access or not hasOrgPermission(src, orgKey, 'view_employee', access.leader or access.deputy) then TriggerClientEvent('universal_identity:generalPersonResult', src, { success = false, message = 'Du hast keine Berechtigung für die Personensuche.' }); return end
    if not isNearLocation(src, OrgPcLocations, orgKey, (Config.Documents.OrgPcInteractionDistance or 2.0) + 1.0) then TriggerClientEvent('universal_identity:generalPersonResult', src, { success = false, message = 'Du musst am Organisations-PC bleiben.' }); return end
    targetId = tonumber(targetId)
    local target = targetId and QBCore.Functions.GetPlayer(targetId)
    if not target or not target.PlayerData then TriggerClientEvent('universal_identity:generalPersonResult', src, { success = false, message = 'Kein Online-Spieler mit dieser Server-ID gefunden.' }); return end
    local pd = target.PlayerData
    local char = pd.charinfo or {}
    local job = pd.job or {}
    local grade = job.grade or {}
    local identifier = tostring(pd.citizenid or '')
    local photo = nil
    if identifier ~= '' and hasPhoto(identifier) then
        local bytes = LoadResourceFile(RESOURCE, ('photos/%s.jpg'):format(identifier))
        if bytes and #bytes > 0 then
            local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
            local out = {}
            for i = 1, #bytes, 3 do
                local a, b, c = bytes:byte(i, i + 2); b = b or 0; c = c or 0
                local n = a * 65536 + b * 256 + c
                local x1 = math.floor(n / 262144) % 64 + 1; local x2 = math.floor(n / 4096) % 64 + 1
                local x3 = math.floor(n / 64) % 64 + 1; local x4 = n % 64 + 1
                out[#out + 1] = chars:sub(x1,x1) .. chars:sub(x2,x2) .. (i + 1 <= #bytes and chars:sub(x3,x3) or '=') .. (i + 2 <= #bytes and chars:sub(x4,x4) or '=')
            end
            photo = 'data:image/jpeg;base64,' .. table.concat(out)
        end
    end
    local name = (('%s %s'):format(char.firstname or '', char.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
    TriggerClientEvent('universal_identity:generalPersonResult', src, { success = true, serverId = targetId, name = name, citizenid = identifier, birthdate = tostring(char.birthdate or '—'), gender = (tonumber(char.gender) == 0 and 'Männlich' or (tonumber(char.gender) == 1 and 'Weiblich' or '—')), nationality = tostring(char.nationality or '—'), job = tostring(job.label or job.name or 'Unbekannt'), rank = tostring(grade.name or grade.level or grade.grade or 'Unbekannt'), photo = photo, message = ('Spieler %s (Server-ID %s) gefunden.'):format(name, targetId) })
end)

RegisterNetEvent('universal_identity:lookupOrgDeputyCandidate', function(orgKey, targetId)
    local src = source
    orgKey = tostring(orgKey or '')
    local org = Config.Documents.Organisations[orgKey]
    if not org then TriggerClientEvent('universal_identity:tabletDeputyCandidateResult', src, { success = false, message = 'Unbekannte Organisation.' }); return end
    local issuer = QBCore.Functions.GetPlayer(src)
    if not issuer then return end
    local issuerJob = issuer.PlayerData.job or {}
    if issuerJob.name ~= org.job and not hasFreelancerTestAccess(src, orgKey) then
        TriggerClientEvent('universal_identity:tabletDeputyCandidateResult', src, { success = false, message = 'Du gehörst nicht zu dieser Organisation.' }); return
    end
    if not hasOrgPermission(src, orgKey, 'manage_deputy', false) then
        TriggerClientEvent('universal_identity:tabletDeputyCandidateResult', src, { success = false, message = 'Du hast keine Berechtigung, die Stellvertretung zu verwalten.' }); return
    end
    if not isNearLocation(src, OrgPcLocations, orgKey, (Config.Documents.OrgPcInteractionDistance or 2.0) + 1.0) then
        TriggerClientEvent('universal_identity:tabletDeputyCandidateResult', src, { success = false, message = 'Du musst am Organisations-PC bleiben.' }); return
    end
    targetId = tonumber(targetId)
    local target = targetId and QBCore.Functions.GetPlayer(targetId)
    if not target then VerifiedDeputyCandidates[src] = nil; TriggerClientEvent('universal_identity:tabletDeputyCandidateResult', src, { success = false, message = 'Diese Server-ID ist nicht online.' }); return end
    if target.PlayerData.citizenid == issuer.PlayerData.citizenid and not (isPoliceTestMode(orgKey) and Config.Documents.AllowSelfDeputyForTesting == true) then VerifiedDeputyCandidates[src] = nil; TriggerClientEvent('universal_identity:tabletDeputyCandidateResult', src, { success = false, message = 'Selbsternennung ist deaktiviert.' }); return end
    local selfDeputyTest = targetId == src and Config.Documents.AllowSelfDeputyForTesting == true and hasFreelancerTestAccess(src, orgKey)
    if (not target.PlayerData.job or target.PlayerData.job.name ~= org.job) and not selfDeputyTest then VerifiedDeputyCandidates[src] = nil; TriggerClientEvent('universal_identity:tabletDeputyCandidateResult', src, { success = false, message = 'Der Spieler gehört nicht zu dieser Organisation.' }); return end
    local grade = (target.PlayerData.job or {}).grade or {}
    local name = playerName(targetId)
    local photoData
    local identifier = target.PlayerData.citizenid
    local photoBytes = LoadResourceFile(RESOURCE, ('photos/%s.jpg'):format(identifier))
    if photoBytes then
        local chars, out = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', {}
        for i = 1, #photoBytes, 3 do
            local a,b,c = photoBytes:byte(i,i+2); local n=((a or 0)<<16)|((b or 0)<<8)|(c or 0)
            local x1=((n>>18)&63)+1; local x2=((n>>12)&63)+1; local x3=((n>>6)&63)+1; local x4=(n&63)+1
            out[#out+1]=chars:sub(x1,x1)..chars:sub(x2,x2)..(b and chars:sub(x3,x3) or '=')..(c and chars:sub(x4,x4) or '=')
        end
        photoData = 'data:image/jpeg;base64,' .. table.concat(out)
    end
    VerifiedDeputyCandidates[src] = { orgKey = orgKey, targetId = targetId, identifier = identifier, verifiedAt = os.time() }
    TriggerClientEvent('universal_identity:tabletDeputyCandidateResult', src, { success = true, targetId = targetId, name = name, rank = grade.name or tostring(grade.level or grade), photo = photoData, message = ('Geprüft: %s (Server-ID %s), %s. Bestätige jetzt die Ernennung.'):format(name, targetId, grade.name or ('Rang ' .. tostring(grade.level or grade))) })
end)

RegisterNetEvent('universal_identity:manageOrgDeputy', function(orgKey, targetId, action)
    local src = source
    orgKey, action = tostring(orgKey or ''), tostring(action or '')
    local org = Config.Documents.Organisations[orgKey]
    if not org then notify(src, 'Unbekannte Organisation.', 'error'); return end
    local issuer = QBCore.Functions.GetPlayer(src)
    if not issuer then return end
    local issuerJob = issuer.PlayerData.job or {}
    if issuerJob.name ~= org.job and not hasFreelancerTestAccess(src, orgKey) then notify(src, 'Du gehörst nicht zu dieser Organisation.', 'error'); return end
    if not hasOrgPermission(src, orgKey, 'manage_deputy', false) then notifyOrgPermissionDenied(src, 'Du hast keine Berechtigung, die Stellvertretung zu verwalten.'); return end
    if not isNearLocation(src, OrgPcLocations, orgKey, (Config.Documents.OrgPcInteractionDistance or 2.0) + 1.0) then notify(src, 'Du musst am Organisations-PC bleiben.', 'error'); return end
    if action == 'remove' then
        local changed = MySQL.update.await('DELETE FROM ui_org_deputies WHERE org_key = ?', { orgKey })
        VerifiedDeputyCandidates[src] = nil
        local msg = changed and changed > 0 and 'Stellvertretung entfernt.' or 'Keine Stellvertretung eingetragen.'
        notify(src, msg, changed and changed > 0 and 'success' or 'error')
        TriggerClientEvent('universal_identity:tabletDeputyResult', src, { success = changed and changed > 0, message = msg, deputy = getDeputyOverview(orgKey) })
        return
    end
    targetId = tonumber(targetId)
    local verified = VerifiedDeputyCandidates[src]
    if action ~= 'appoint' or not verified or verified.orgKey ~= orgKey or verified.targetId ~= targetId or os.time() - verified.verifiedAt > 120 then
        notify(src, 'Bitte die Server-ID zuerst prüfen. Die Ernennung wurde nicht ausgeführt.', 'error')
        TriggerClientEvent('universal_identity:tabletDeputyResult', src, { success = false, message = 'Bitte erst die Server-ID prüfen und anschließend ernennen.' })
        return
    end
    local target = QBCore.Functions.GetPlayer(targetId)
    local selfDeputyTest = targetId == src and Config.Documents.AllowSelfDeputyForTesting == true and hasFreelancerTestAccess(src, orgKey)
    if not target or target.PlayerData.citizenid ~= verified.identifier or ((not target.PlayerData.job or target.PlayerData.job.name ~= org.job) and not selfDeputyTest) then
        VerifiedDeputyCandidates[src] = nil
        notify(src, 'Der geprüfte Spieler ist nicht mehr verfügbar oder gehört nicht mehr zur Organisation.', 'error')
        TriggerClientEvent('universal_identity:tabletDeputyResult', src, { success = false, message = 'Spielerdaten haben sich geändert. Bitte erneut prüfen.' })
        return
    end
    local ok, dbError = pcall(function()
        MySQL.insert.await('INSERT INTO ui_org_deputies (org_key, identifier, appointed_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE identifier = VALUES(identifier), appointed_by = VALUES(appointed_by), appointed_at = CURRENT_TIMESTAMP', { orgKey, target.PlayerData.citizenid, charId(src) or 'admin' })
    end)
    if not ok then notify(src, 'Stellvertretung konnte nicht gespeichert werden.', 'error'); return end
    VerifiedDeputyCandidates[src] = nil
    local msg = ('%s (Server-ID %s) wurde als Stellvertretung eingetragen.'):format(playerName(targetId), targetId)
    notify(src, msg, 'success')
    notify(targetId, ('Du wurdest als Stellvertretung für %s ernannt.'):format(org.label), 'success')
    TriggerClientEvent('universal_identity:tabletDeputyResult', src, { success = true, message = msg, deputy = getDeputyOverview(orgKey) })
end)

RegisterNetEvent('universal_identity:fireOrgEmployee', function(orgKey, targetId, reason)
    local src = source
    local ok, failure = xpcall(function()
        orgKey = tostring(orgKey or '')
        local org = Config.Documents.Organisations[orgKey]
        local issuer = QBCore.Functions.GetPlayer(src)
        if not org or not issuer then
            error('Organisation oder auslösender Spieler wurde nicht gefunden.')
        end
        local access, accessError = getOrgAccess(src, orgKey)
        local testAccess = access and access.testAccess == true
        if not access or not hasOrgPermission(src, orgKey, 'fire_employee', access.leader or access.deputy) then
            error(accessError or 'Du hast keine Berechtigung, Mitarbeiter zu kündigen.')
        end
        if not isNearLocation(src, OrgPcLocations, orgKey, (Config.Documents.OrgPcInteractionDistance or 2.0) + 1.0) then
            error('Du musst am Organisations-PC bleiben.')
        end
        targetId = tonumber(targetId)
        local target = targetId and QBCore.Functions.GetPlayer(targetId)
        if not target or (targetId == src and not (isPoliceTestMode(orgKey) and Config.Documents.AllowSelfTerminationForTesting == true)) then
            error('Bitte eine gültige Server-ID eines Online-Mitarbeiters eingeben.')
        end
        if (target.PlayerData.job or {}).name ~= org.job and not (testAccess and targetId == src) then
            error('Dieser Spieler gehört nicht mehr zu dieser Organisation.')
        end

        local targetIdentifier, targetName = target.PlayerData.citizenid, playerName(targetId)
        reason = tostring(reason or ''):gsub('^%s+', ''):gsub('%s+$', '')
        if reason == '' then error('Bitte einen Kündigungsgrund eintragen.') end
        if #reason > 1000 then reason = reason:sub(1, 1000) end
        local itemName = Config.Documents.OrganisationIdItem or 'universal_org_id'
        local weaponItemName = (Config.Documents.OtherTypes and Config.Documents.OtherTypes.weapon_permit and Config.Documents.OtherTypes.weapon_permit.item) or 'universal_weapon_permit'

        -- Lade die noch aktiven Dienstausweise und Waffenscheine zuerst. Bei einem Datenbankfehler wird kein Job geändert.
        local docs = MySQL.query.await([[
            SELECT id, document_number, document_type, owner_identifier, owner_name
            FROM ui_universal_documents
            WHERE owner_identifier = ? AND organisation_key = ?
              AND document_type IN ('organisation_id', 'weapon_permit') AND status <> 'revoked'
        ]], { targetIdentifier, orgKey }) or {}

        MySQL.update.await([[
            UPDATE ui_universal_documents SET status = 'revoked'
            WHERE owner_identifier = ? AND organisation_key = ?
              AND document_type IN ('organisation_id', 'weapon_permit') AND status <> 'revoked'
        ]], { targetIdentifier, orgKey })

        -- Entfernt Ausweise sowohl beim Mitarbeiter als auch beim Aussteller, falls noch nicht übergeben.
        for _, onlineId in ipairs(QBCore.Functions.GetPlayers()) do
            local holder = QBCore.Functions.GetPlayer(tonumber(onlineId))
            if holder and holder.PlayerData and holder.PlayerData.items then
                local slots = {}
                for slot, item in pairs(holder.PlayerData.items) do
                    local info = item and (item.info or item.metadata)
                    if item and (item.name == itemName or item.name == weaponItemName) and info
                        and info.ownerIdentifier == targetIdentifier
                        and (not info.organisationKey or info.organisationKey == orgKey) then
                        slots[#slots + 1] = { name = item.name, slot = item.slot or slot, amount = item.amount or 1 }
                    end
                end
                for _, entry in ipairs(slots) do
                    holder.Functions.RemoveItem(entry.name, entry.amount, entry.slot)
                end
            end
        end

        MySQL.update.await('DELETE FROM ui_org_deputies WHERE org_key = ? AND identifier = ?', { orgKey, targetIdentifier })
        local issuerIdentifier = issuer.PlayerData.citizenid or 'unknown'
        local issuerName = playerName(src)
        MySQL.insert.await('INSERT INTO ui_org_termination_logs (org_key, employee_identifier, employee_name, terminated_by_identifier, terminated_by_name, reason) VALUES (?, ?, ?, ?, ?, ?)', { orgKey, targetIdentifier, targetName, issuerIdentifier, issuerName, reason })
        target.Functions.SetJob('unemployed', 0)
        for _, doc in ipairs(docs) do
            auditDocument(doc, 'revoked_employee_terminated', src, ('Mitarbeiter gekündigt; Dienstausweis und Waffenschein entwertet. Grund: %s'):format(reason), targetId)
        end
        local msg = ('%s wurde gekündigt; aktive Dienstausweise wurden entwertet und aus den Online-Inventaren entfernt.'):format(targetName)
        notify(src, msg, 'success')
        notify(targetId, ('Du wurdest aus %s entlassen. Dein Dienstausweis wurde entwertet.'):format(org.label), 'error')
        TriggerClientEvent('universal_identity:tabletFireResult', src, { success = true, message = msg })
    end, function(err) return tostring(err) end)

    if not ok then
        local msg = 'Kündigung fehlgeschlagen: ' .. tostring(failure):gsub('^.-:%d+: ', '')
        log('Fehler bei Mitarbeiterkündigung: ' .. tostring(failure):gsub('[\r\n]+', ' '))
        notify(src, msg, 'error')
        TriggerClientEvent('universal_identity:tabletFireResult', src, { success = false, message = msg })
    end
end)

local function insertProtocolArchiveBatch(orgKey, sourceType, rows, src, getFields)
    local inserted = 0
    local batchSize = 50
    for first = 1, #rows, batchSize do
        local values, params = {}, {}
        local last = math.min(first + batchSize - 1, #rows)
        for i = first, last do
            local row = rows[i]
            local sourceId, month, title = getFields(row)
            if sourceId and month and month:match('^%d%d%d%d%-%d%d$') then
                values[#values + 1] = "(?, ?, ?, ?, ?, ?, ?)"
                params[#params + 1] = orgKey
                params[#params + 1] = sourceType
                params[#params + 1] = sourceId
                params[#params + 1] = month
                params[#params + 1] = title
                params[#params + 1] = json.encode(row)
                params[#params + 1] = playerName(src)
            end
        end
        if #values > 0 then
            local sql = 'INSERT IGNORE INTO ui_org_protocol_archive (org_key, source_type, source_id, archive_month, title, payload, archived_by_name) VALUES ' .. table.concat(values, ',')
            MySQL.query.await(sql, params)
            inserted = inserted + #values
        end
        -- Yield between batches so a large test history does not monopolize the server coroutine.
        Wait(0)
    end
    return inserted
end

RegisterNetEvent('universal_identity:archiveAllOrgProtocols', function(orgKey)
    local src = source
    orgKey = tostring(orgKey or '')
    local access = getOrgAccess(src, orgKey)
    if not access then notify(src, 'Keine Berechtigung für dieses Organisationsarchiv.', 'error'); return end
    if not access.leader then
        notify(src, 'Nur die ranghöchste Leitung darf Protokolle archivieren.', 'error')
        return
    end

    notify(src, 'Archivierung gestartet. Die Protokolle werden in kleinen Paketen gespeichert …', 'primary')
    local ok, result = pcall(function()
        local terms = MySQL.query.await('SELECT id, org_key, employee_identifier, employee_name, terminated_by_identifier, terminated_by_name, reason, created_at FROM ui_org_termination_logs WHERE org_key = ?', { orgKey }) or {}
        local termCount = insertProtocolArchiveBatch(orgKey, 'termination', terms, src, function(row)
            local date = tostring(row.created_at or os.date('%Y-%m-%d'))
            return tonumber(row.id), date:sub(1, 7), (row.employee_name or 'Mitarbeiter') .. ' · Kündigung'
        end)

        local audits = MySQL.query.await([[SELECT a.id, a.document_id, a.document_number, a.document_type, a.owner_identifier, a.owner_name, a.action, a.actor_identifier, a.actor_name, a.target_identifier, a.target_name, a.details, a.created_at, d.organisation_key AS document_org_key
            FROM ui_document_audit a
            LEFT JOIN ui_universal_documents d ON d.id = a.document_id
            WHERE a.document_type IN ('organisation_id', 'weapon_permit')
              AND a.action IN ('issued_waiting_pickup', 'collected_by_issuer', 'handed_to_owner')
              AND (d.organisation_key = ? OR a.details LIKE ?)
            ORDER BY a.id ASC]], { orgKey, '%Organisation: ' .. tostring(access.org.label or orgKey) .. '%' }) or {}
        local auditCount = insertProtocolArchiveBatch(orgKey, 'audit', audits, src, function(row)
            local date = tostring(row.created_at or os.date('%Y-%m-%d'))
            return tonumber(row.id), date:sub(1, 7), (row.owner_name or 'Mitarbeiter') .. ' · ' .. (row.document_type or 'Dokument')
        end)

        local months = MySQL.query.await('SELECT archive_month, COUNT(*) AS entry_count FROM ui_org_protocol_archive WHERE org_key = ? GROUP BY archive_month ORDER BY archive_month DESC', { orgKey }) or {}
        TriggerClientEvent('universal_identity:orgArchiveMonths', src, months)
        local activeTerms = MySQL.query.await([[SELECT t.id, t.employee_name, t.terminated_by_name, t.reason, t.created_at FROM ui_org_termination_logs t WHERE t.org_key = ? AND NOT EXISTS (SELECT 1 FROM ui_org_protocol_archive ar WHERE ar.org_key = t.org_key AND ar.source_type = 'termination' AND ar.source_id = t.id) ORDER BY t.id DESC LIMIT 100]], { orgKey }) or {}
        TriggerClientEvent('universal_identity:orgTerminationLogs', src, activeTerms)
        local activeAudits = MySQL.query.await([[SELECT a.id, a.document_id, a.document_number, a.document_type, a.owner_name, a.action, a.actor_name, a.details, a.created_at
            FROM ui_document_audit a LEFT JOIN ui_universal_documents d ON d.id = a.document_id
            WHERE a.document_type IN ('organisation_id', 'weapon_permit')
              AND a.action IN ('issued_waiting_pickup', 'collected_by_issuer', 'handed_to_owner')
              AND a.id = (SELECT MAX(a2.id) FROM ui_document_audit a2 WHERE a2.document_id = a.document_id AND a2.action IN ('issued_waiting_pickup', 'collected_by_issuer', 'handed_to_owner'))
              AND (d.organisation_key = ? OR a.details LIKE ?)
              AND NOT EXISTS (SELECT 1 FROM ui_org_protocol_archive ar WHERE ar.org_key = ? AND ar.source_type = 'audit' AND ar.source_id = a.id)
            ORDER BY a.id DESC LIMIT 100]], { orgKey, '%Organisation: ' .. tostring(access.org.label or orgKey) .. '%', orgKey }) or {}
        TriggerClientEvent('universal_identity:orgIssueLogs', src, activeAudits)
        return { count = termCount + auditCount }
    end)
    if not ok then
        log('Sammelarchivierung fehlgeschlagen: ' .. tostring(result))
        notify(src, 'Archivierung abgebrochen. Bitte Serverkonsole prüfen; bereits gespeicherte Einträge bleiben erhalten.', 'error')
        return
    end
    notify(src, ('Archivierung abgeschlossen. %d Einträge wurden verarbeitet.'):format(result.count or 0), 'success')
end)

RegisterNetEvent('universal_identity:requestOrgArchiveMonths', function(orgKey)
    local src = source; orgKey = tostring(orgKey or '')
    local access = getOrgAccess(src, orgKey)
    if not access or not hasOrgPermission(src, orgKey, 'view_issue_logs', access.leader or access.deputy) then TriggerClientEvent('universal_identity:orgArchiveMonths', src, {}); return end
    local rows = MySQL.query.await('SELECT archive_month, COUNT(*) AS entry_count FROM ui_org_protocol_archive WHERE org_key = ? GROUP BY archive_month ORDER BY archive_month DESC', { orgKey }) or {}
    TriggerClientEvent('universal_identity:orgArchiveMonths', src, rows)
end)
RegisterNetEvent('universal_identity:requestOrgArchiveEntries', function(orgKey, month)
    local src = source; orgKey = tostring(orgKey or ''); month = tostring(month or '')
    local access = getOrgAccess(src, orgKey)
    if not access or not hasOrgPermission(src, orgKey, 'view_issue_logs', access.leader or access.deputy) or not month:match('^%d%d%d%d%-%d%d$') then TriggerClientEvent('universal_identity:orgArchiveEntries', src, {}); return end
    local rows = MySQL.query.await('SELECT id, source_type, title, payload, archived_by_name, archived_at FROM ui_org_protocol_archive WHERE org_key = ? AND archive_month = ? ORDER BY archived_at DESC LIMIT 200', { orgKey, month }) or {}
    for _, row in ipairs(rows) do local ok, payload = pcall(json.decode, row.payload or '{}'); row.payload = ok and payload or {} end
    TriggerClientEvent('universal_identity:orgArchiveEntries', src, rows)
end)
RegisterNetEvent('universal_identity:archiveOrgProtocol', function(orgKey, sourceType, sourceId)
    local src = source; orgKey = tostring(orgKey or ''); sourceType = tostring(sourceType or ''); sourceId = tonumber(sourceId)
    local access = getOrgAccess(src, orgKey)
    if not access or not sourceId or (sourceType ~= 'termination' and sourceType ~= 'audit') then return end
    if not access.leader then notify(src, 'Nur die ranghöchste Leitung darf Protokolle archivieren.', 'error'); return end
    local row, title, month
    if sourceType == 'termination' then
        row = MySQL.single.await('SELECT * FROM ui_org_termination_logs WHERE id = ? AND org_key = ?', { sourceId, orgKey })
        if row then title = (row.employee_name or 'Mitarbeiter') .. ' · Kündigung'; month = tostring(row.created_at or os.date('%Y-%m-%d')):sub(1,7) end
    else
        row = MySQL.single.await('SELECT a.*, d.organisation_key AS document_org_key FROM ui_document_audit a LEFT JOIN ui_universal_documents d ON d.id = a.document_id WHERE a.id = ?', { sourceId })
        if row then
            local details = tostring(row.details or '')
            if row.document_org_key ~= orgKey and not details:find('Organisation: ' .. tostring(access.org.label or orgKey), 1, true) then return end
            title = (row.owner_name or 'Mitarbeiter') .. ' · ' .. (row.document_type or 'Dokument')
            month = tostring(row.created_at or os.date('%Y-%m-%d')):sub(1,7)
        end
    end
    if not row then notify(src, 'Protokolleintrag nicht gefunden.', 'error'); return end
    local ok, err = pcall(function()
        local archiveParams = { orgKey, sourceType, sourceId, month, title, json.encode(row), playerName(src) }
        assert(#archiveParams == 7, 'Archiv-Parameteranzahl muss 7 sein')
        MySQL.query.await('INSERT IGNORE INTO ui_org_protocol_archive (org_key, source_type, source_id, archive_month, title, payload, archived_by_name) VALUES (?, ?, ?, ?, ?, ?, ?)', archiveParams)
    end)
    if not ok then log('Archivierung fehlgeschlagen: ' .. tostring(err)); notify(src, 'Archivierung fehlgeschlagen.', 'error'); return end
    notify(src, 'Protokoll wurde im Monatsarchiv abgelegt.', 'success')
    if sourceType == 'termination' then
        local active = MySQL.query.await([[SELECT t.id, t.employee_name, t.terminated_by_name, t.reason, t.created_at FROM ui_org_termination_logs t WHERE t.org_key = ? AND NOT EXISTS (SELECT 1 FROM ui_org_protocol_archive ar WHERE ar.org_key = t.org_key AND ar.source_type = 'termination' AND ar.source_id = t.id) ORDER BY t.id DESC LIMIT 100]], { orgKey }) or {}
        TriggerClientEvent('universal_identity:orgTerminationLogs', src, active)
    else
        local active = MySQL.query.await([[SELECT a.id, a.document_id, a.document_number, a.document_type, a.owner_name, a.action, a.actor_name, a.details, a.created_at FROM ui_document_audit a LEFT JOIN ui_universal_documents d ON d.id = a.document_id WHERE a.document_type IN ('organisation_id', 'weapon_permit') AND a.action IN ('issued_waiting_pickup', 'collected_by_issuer', 'handed_to_owner') AND a.id = (SELECT MAX(a2.id) FROM ui_document_audit a2 WHERE a2.document_id = a.document_id AND a2.action IN ('issued_waiting_pickup', 'collected_by_issuer', 'handed_to_owner')) AND (d.organisation_key = ? OR a.details LIKE ?) AND NOT EXISTS (SELECT 1 FROM ui_org_protocol_archive ar WHERE ar.org_key = ? AND ar.source_type = 'audit' AND ar.source_id = a.id) ORDER BY a.id DESC LIMIT 100]], { orgKey, '%Organisation: ' .. tostring(access.org.label or orgKey) .. '%', orgKey }) or {}
        TriggerClientEvent('universal_identity:orgIssueLogs', src, active)
    end
    local rows = MySQL.query.await('SELECT archive_month, COUNT(*) AS entry_count FROM ui_org_protocol_archive WHERE org_key = ? GROUP BY archive_month ORDER BY archive_month DESC', { orgKey }) or {}
    TriggerClientEvent('universal_identity:orgArchiveMonths', src, rows)
end)

local function getDocumentRankOptions(orgKey)
    local org = Config.Documents.Organisations[tostring(orgKey or '')]
    if not org then return {} end
    local sharedJob = QBCore.Shared and QBCore.Shared.Jobs and QBCore.Shared.Jobs[org.job]
    local grades = sharedJob and sharedJob.grades or {}
    local options = {}
    local function addGrade(gradeKey, labelOverride)
        local grade = grades[tostring(gradeKey)] or grades[gradeKey]
        if not grade then return end
        local level = tonumber(type(grade) == 'table' and (grade.level or grade.grade)) or tonumber(gradeKey)
        if not level then return end
        local label = tostring(labelOverride or (type(grade) == 'table' and (grade.name or grade.label)) or gradeKey)
        options[#options + 1] = { value = tostring(gradeKey), label = label, level = level }
    end
    if type(org.documentRanks) == 'table' and #org.documentRanks > 0 then
        for _, entry in ipairs(org.documentRanks) do
            if type(entry) == 'table' then
                local key = entry.grade or entry.level or entry.value
                if key ~= nil then addGrade(key, entry.label or entry.name) end
            else
                local requested = tostring(entry or '')
                if requested ~= '' then
                    local matched = false
                    for key, grade in pairs(grades) do
                        local gradeLabel = tostring(type(grade) == 'table' and (grade.name or grade.label) or key)
                        if requested == gradeLabel or requested == tostring(key) then
                            addGrade(key, requested == tostring(key) and gradeLabel or requested)
                            matched = true
                            break
                        end
                    end
                    if not matched and tonumber(requested) then addGrade(requested, requested) end
                end
            end
        end
        return options
    end
    local keys = {}
    for key in pairs(grades) do keys[#keys + 1] = key end
    table.sort(keys, function(a, b) return (tonumber(a) or 0) < (tonumber(b) or 0) end)
    for _, key in ipairs(keys) do addGrade(key) end
    return options
end

local function getJobGradeOptions(orgKey)
    local options = {}
    for _, option in ipairs(getDocumentRankOptions(orgKey)) do
        options[#options + 1] = { value = tonumber(option.value) or option.value, label = option.label, level = option.level }
    end
    return options
end


-- Löst die gespeicherte numerische Rangstufe wieder auf den echten Schlüssel aus
-- QBCore.Shared.Jobs[job].grades auf. Das unterstützt auch Forks, deren Schlüssel
-- nicht rein numerisch sind, deren Grade aber ein numerisches level-Feld besitzen.
local function resolveSharedJobGrade(jobName, requestedLevel)
    local sharedJob = QBCore.Shared and QBCore.Shared.Jobs and QBCore.Shared.Jobs[jobName]
    local grades = sharedJob and sharedJob.grades
    if type(grades) ~= 'table' then return nil end
    local wanted = tonumber(requestedLevel)
    for key, gradeData in pairs(grades) do
        local level = type(gradeData) == 'table' and tonumber(gradeData.level or gradeData.grade) or nil
        level = level or tonumber(key)
        if wanted and level == wanted then return tostring(key), gradeData, level end
    end
    return nil
end

local function resolvePlayerJobGrade(jobName, jobData)
    local job = jobData or {}
    local grade = job.grade or {}
    local level = type(grade) == 'table' and tonumber(grade.level or grade.grade) or tonumber(grade)
    local sharedJob = QBCore.Shared and QBCore.Shared.Jobs and QBCore.Shared.Jobs[jobName]
    local grades = sharedJob and sharedJob.grades
    if level and type(grades) == 'table' then
        for key, gradeData in pairs(grades) do
            local candidateLevel = type(gradeData) == 'table' and tonumber(gradeData.level or gradeData.grade) or tonumber(key)
            if candidateLevel == level then return tostring(key), gradeData, level end
        end
    end
    if type(grades) == 'table' then
        local currentName = type(grade) == 'table' and tostring(grade.name or grade.label or '') or ''
        if currentName ~= '' then
            for key, gradeData in pairs(grades) do
                if type(gradeData) == 'table' and tostring(gradeData.name or gradeData.label or '') == currentName then
                    local candidateLevel = tonumber(gradeData.level or gradeData.grade) or tonumber(key)
                    return tostring(key), gradeData, candidateLevel
                end
            end
        end
    end
    return nil
end

local function getAllowedDocumentRank(orgKey, rankValue)
    rankValue = tostring(rankValue or '')
    if rankValue == '' then return nil end
    for _, option in ipairs(getDocumentRankOptions(orgKey)) do
        if tostring(option.value) == rankValue then return option end
    end
    return nil
end

-- Synchronisiert aktive Dienstausweise mit dem tatsächlichen QBCore-Jobrang.
-- Die Rangstufe aus PlayerData.job ist maßgeblich; Label und Level werden aus Shared.Jobs ergänzt.
local function syncEmployeeServiceCards(player)
    if not player or not player.PlayerData or not player.PlayerData.citizenid then return false end
    local job = player.PlayerData.job or {}
    if not job.name then return false end
    local synced = false
    for orgKey, org in pairs(Config.Documents.Organisations or {}) do
        if tostring(job.name) == tostring(org.job) then
            local grade = job.grade or {}
            local level = type(grade) == 'table' and tonumber(grade.level or grade.grade) or tonumber(grade)
            local sharedJob = (QBCore.Shared and QBCore.Shared.Jobs or {})[org.job]
            local gradeData = level and sharedJob and sharedJob.grades and (sharedJob.grades[tostring(level)] or sharedJob.grades[level]) or nil
            if not level and sharedJob and sharedJob.grades then
                local currentName = type(grade) == 'table' and tostring(grade.name or grade.label or '') or ''
                for key, candidate in pairs(sharedJob.grades) do
                    if type(candidate) == 'table' and currentName ~= '' and tostring(candidate.name or candidate.label or '') == currentName then
                        level = tonumber(candidate.level or candidate.grade) or tonumber(key)
                        gradeData = candidate
                        break
                    end
                end
            end
            if level then
                local label = tostring((type(gradeData) == 'table' and (gradeData.name or gradeData.label)) or (type(grade) == 'table' and (grade.name or grade.label)) or ('Rang ' .. level))
                MySQL.update.await([[UPDATE ui_universal_documents
                    SET rank_label = ?, rank_level = ?
                    WHERE owner_identifier = ? AND organisation_key = ? AND document_type = 'organisation_id'
                      AND status IN ('pending_handover', 'processing', 'collected_by_issuer', 'issued')]],
                    { label, level, player.PlayerData.citizenid, orgKey })
                synced = true
            end
        end
    end
    return synced
end

-- QBCore löst auch /setjob über SetJob aus. Dieser Server-Hook hält den Dienstausweis
-- bei externen Job-/Rangänderungen aktuell, nicht nur bei Aktionen im Tablet.
AddEventHandler('QBCore:Server:OnJobUpdate', function(playerId)
    local targetId = tonumber(playerId)
    if not targetId then return end
    local player = QBCore.Functions.GetPlayer(targetId)
    if not player then return end
    CreateThread(function()
        Wait(0)
        pcall(function() syncEmployeeServiceCards(QBCore.Functions.GetPlayer(targetId) or player) end)
    end)
end)

local function sendOrgEmployeeLookup(src, orgKey, targetId, mode)
    local responseEvent = mode == 'management'
        and 'universal_identity:orgEmployeeManagementLookupResult'
        or 'universal_identity:tabletLookupResult'
    local function fail(message)
        TriggerClientEvent(responseEvent, src, { success = false, message = message })
    end

    orgKey = tostring(orgKey or '')
    targetId = tonumber(targetId)
    local adminSelfLookup = targetId == tonumber(src) and isPoliceTestMode(orgKey) and Config.Documents.AllowSelfIssueForTesting == true and adminAllowed(src)
    local access, err = getOrgAccess(src, orgKey)
    if not access then fail(err or 'Kein Zugriff auf diese Organisation.'); return end
    if not targetId or targetId < 1 then fail('Bitte eine gültige Server-ID eingeben.'); return end
    local target = QBCore.Functions.GetPlayer(targetId)
    if not target then fail('Spieler ist nicht online.'); return end

    local targetJob = target.PlayerData.job or {}
    local isMember = tostring(targetJob.name or '') == tostring(access.org.job or '')
    local canHireAnyJob = adminSelfLookup or hasOrgPermission(src, orgKey, 'hire_employee', access.leader or access.deputy)
    local canView = adminSelfLookup or (mode == 'management'
        and hasOrgPermission(src, orgKey, 'view_employee', access.leader or access.deputy)
        or mode ~= 'management' and (isMember
            and hasOrgPermission(src, orgKey, 'issue_org_document', access.leader or access.deputy)
            or not isMember and canHireAnyJob))
    if not canView then
        fail(mode == 'management'
            and 'Du hast keine Berechtigung, Mitarbeiterdaten anzusehen.'
            or 'Du hast keine Berechtigung, Dienstausweise auszustellen oder Neueinstellungen vorzunehmen.')
        return
    end
    if not adminSelfLookup and not isNearLocation(src, OrgPcLocations, orgKey, (Config.Documents.OrgPcInteractionDistance or 2.0) + 1.0) then
        fail('Du musst am Organisations-PC bleiben.')
        return
    end

    -- Personalverwaltung ist strikt auf bereits eingestellte Organisationsmitglieder begrenzt.
    -- Nur der getrennte Dokumenten-/Neueinstellungsweg darf im Testmodus bzw. mit hire_employee
    -- auch Spieler ohne Organisationsjob laden.
    if mode == 'management' and not isMember then
        fail('Dieser Spieler gehört nicht zur Polizei. In der Mitarbeiterverwaltung erscheinen ausschließlich bestehende Polizeimitglieder. Nutze für neue Mitarbeiter die Dienstausweis-Ausstellung oder für allgemeine Prüfungen die Personensuche.')
        return
    end
    if mode ~= 'management' and not isMember and not canHireAnyJob then
        fail('Spieler ohne Polizeijob können nur im aktivierten Testmodus oder mit der Berechtigung „Mitarbeiter einstellen“ ausgewählt werden.')
        return
    end

    local identifier = target.PlayerData.citizenid
    local photoOk = hasPhoto(identifier)
    local personal = MySQL.single.await("SELECT id, document_number, status FROM ui_universal_documents WHERE owner_identifier = ? AND document_type = 'personal_id' ORDER BY id DESC LIMIT 1", { identifier })
    local personalIdValid = personal ~= nil and personal.status == 'issued'
    local canIssue = photoOk and (not Config.Documents.RequirePersonalIdForOrganisationId or personalIdValid)
    local photoData
    if photoOk then
        local bytes = LoadResourceFile(RESOURCE, ('photos/%s.jpg'):format(identifier))
        if bytes then
            local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
            local out = {}
            for i = 1, #bytes, 3 do
                local a,b,c = bytes:byte(i,i+2); local n=((a or 0)<<16)|((b or 0)<<8)|(c or 0)
                local x1=((n>>18)&63)+1; local x2=((n>>12)&63)+1; local x3=((n>>6)&63)+1; local x4=(n&63)+1
                out[#out+1]=chars:sub(x1,x1)..chars:sub(x2,x2)..(b and chars:sub(x3,x3) or '=')..(c and chars:sub(x4,x4) or '=')
            end
            photoData = 'data:image/jpeg;base64,' .. table.concat(out)
        end
    end
    local c = target.PlayerData.charinfo or {}
    local name = (('%s %s'):format(c.firstname or '', c.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
    local grade = targetJob.grade or {}
    local employment = nil
    if isMember then
        MySQL.insert.await('INSERT IGNORE INTO ui_org_employment_dates (org_key, identifier, employee_name) VALUES (?, ?, ?)', { orgKey, identifier, name })
        employment = MySQL.single.await('SELECT hired_at FROM ui_org_employment_dates WHERE org_key = ? AND identifier = ? LIMIT 1', { orgKey, identifier })
    end
    TriggerClientEvent(responseEvent, src, {
        success = true, targetId = targetId, identifier = identifier, name = name,
        organisation = access.org.label, rank = grade.name or tostring(grade.level or grade),
        jobName = tostring(targetJob.name or 'unemployed'), orgJobName = tostring(access.org.job or ''),
        isOrganisationMember = isMember, rankOptions = getDocumentRankOptions(orgKey),
        hiredAt = employment and employment.hired_at or nil,
        photo = photoData, hasPhoto = photoOk, hasPersonalId = personal ~= nil,
        personalIdValid = personalIdValid, jobGradeOptions = getJobGradeOptions(orgKey), adminSelfIssue = adminSelfLookup,
        weaponPermitFee = WeaponPermitTabletFee, canIssue = canIssue, canRecruit = canHireAnyJob,
        message = not photoOk and 'Ausstellung gesperrt: bestätigtes Foto fehlt.'
            or (not personalIdValid and 'Ausstellung gesperrt: gültiger Personalausweis muss abgeholt und vorgezeigt werden.'
            or 'Personalausweis gültig. Bitte bestätigen, dass er vorgezeigt wurde.')
    })
end

RegisterNetEvent('universal_identity:lookupOrgEmployee', function(orgKey, targetId)
    sendOrgEmployeeLookup(source, orgKey, targetId, 'document')
end)

RegisterNetEvent('universal_identity:lookupOrgEmployeeManagement', function(orgKey, targetId)
    sendOrgEmployeeLookup(source, orgKey, targetId, 'management')
end)

RegisterNetEvent('universal_identity:manageOrgEmployeeJob', function(orgKey, targetId, action, gradeLevel)
    local src = source
    local ok, failure = xpcall(function()
        orgKey = tostring(orgKey or '')
        action = tostring(action or '')
        local org = Config.Documents.Organisations[orgKey]
        local issuer = QBCore.Functions.GetPlayer(src)
        if not org or not issuer then error('Organisation oder auslösender Spieler wurde nicht gefunden.') end
        local issuerJob = issuer.PlayerData.job or {}
        local issuerGrade = tonumber((issuerJob.grade or {}).level or issuerJob.grade) or 0
        local access, accessError = getOrgAccess(src, orgKey)
        if not access or not hasOrgPermission(src, orgKey, 'manage_employee_job', access.leader or access.deputy) then
            error(accessError or 'Du hast keine Berechtigung, Mitarbeiter-Ränge zu verwalten.')
        end
        local isOrgManager = access.leader or access.deputy
        if action ~= 'recruit' and action ~= 'promote' then error('Ungültige Mitarbeiteraktion.') end
        if not isNearLocation(src, OrgPcLocations, orgKey, (Config.Documents.OrgPcInteractionDistance or 2.0) + 1.0) then error('Du musst am Organisations-PC bleiben.') end
        targetId = tonumber(targetId)
        local target = targetId and QBCore.Functions.GetPlayer(targetId)
        if not target then error('Der ausgewählte Spieler ist nicht online.') end
        local isSelfTest = targetId == src
        local allowSelfRecruit = isSelfTest and isPoliceTestMode(orgKey) and Config.Documents.AllowSelfRecruitForTesting == true
        local allowSelfPromote = isSelfTest and isPoliceTestMode(orgKey) and Config.Documents.AllowSelfPromoteForTesting == true
        if isSelfTest and not ((action == 'recruit' and allowSelfRecruit) or (action == 'promote' and allowSelfPromote)) then
            error('Selbst-Rekrutieren und Selbst-Befördern sind deaktiviert.')
        end
        local currentJob = target.PlayerData.job or {}
        local effectiveAction = action
        -- Die Mitarbeiterverwaltung darf ausschließlich bestehende Polizeimitglieder verwalten.
        -- „Rekrutieren“ ordnet im Test-/Personalworkflow einen bereits eingestellten Beamten
        -- einem Rang zu; es stellt niemals Zivilisten oder Spieler anderer Jobs ein.
        if currentJob.name ~= org.job then
            error('Nur Spieler mit dem Polizeijob können in der Polizeimitarbeiterverwaltung ausgewählt werden.')
        end
        if action == 'promote' and currentJob.name ~= org.job and not (isSelfTest and allowSelfPromote) then
            error('Befördern ist nur bei Mitarbeitern dieser Organisation möglich. Nutze „Rekrutieren“.')
        end
        if isSelfTest and action == 'recruit' and currentJob.name == org.job and not allowSelfRecruit then
            error('Selbst-Rekrutieren ist deaktiviert. Wähle „Befördern“ oder aktiviere AllowSelfRecruitForTesting.')
        end
        local requestedGrade = tonumber(gradeLevel)
        local sharedJob = QBCore.Shared and QBCore.Shared.Jobs and QBCore.Shared.Jobs[org.job]
        local grades = sharedJob and sharedJob.grades
        local gradeKey, gradeData = nil, nil
        if type(grades) == 'table' and requestedGrade then
            -- Dropdown value is the actual shared/jobs.lua key, because QBCore SetJob resolves grades[tostring(key)].
            if grades[tostring(requestedGrade)] ~= nil then
                gradeKey, gradeData = tostring(requestedGrade), grades[tostring(requestedGrade)]
            else
                for key, candidate in pairs(grades) do
                    local candidateLevel = type(candidate) == 'table' and tonumber(candidate.level or candidate.grade) or nil
                    if candidateLevel == requestedGrade then gradeKey, gradeData = tostring(key), candidate; break end
                end
            end
        end
        if not requestedGrade or not gradeData then error(('Der ausgewählte Rang %s existiert nicht unter QBCore.Shared.Jobs[%s].grades.'):format(tostring(gradeLevel), tostring(org.job))) end
        local resolvedLevel = (type(gradeData) == 'table' and tonumber(gradeData.level or gradeData.grade)) or tonumber(gradeKey) or requestedGrade
        local currentTargetGrade = currentJob.grade
        local currentTargetLevel = type(currentTargetGrade) == 'table' and tonumber(currentTargetGrade.level or currentTargetGrade.grade) or tonumber(currentTargetGrade)
        -- Manche QBCore-Forks liefern kein grade.level im PlayerData-Objekt. Dann den Rang anhand
        -- des gespeicherten Gradenamens bzw. der passenden Shared-Job-Definition auflösen.
        if currentTargetLevel == nil and type(grades) == 'table' then
            local currentGradeName = type(currentTargetGrade) == 'table' and tostring(currentTargetGrade.name or currentTargetGrade.label or '') or ''
            for key, candidate in pairs(grades) do
                if type(candidate) == 'table' and currentGradeName ~= '' and tostring(candidate.name or candidate.label or '') == currentGradeName then
                    currentTargetLevel = tonumber(candidate.level or candidate.grade) or tonumber(key)
                    break
                end
            end
        end
        currentTargetLevel = currentTargetLevel or -1
        if effectiveAction == 'recruit' then
            -- Bereits aktives Polizeimitglied: Rang wird zugewiesen, vorhandenes Einstellungsdatum bleibt erhalten.
        elseif effectiveAction == 'promote' then
            if currentJob.name ~= org.job and not (isSelfTest and allowSelfPromote) then error('Befördern ist nur bei Mitarbeitern dieser Organisation möglich. Nutze Rekrutieren.') end
            if resolvedLevel <= currentTargetLevel and not (isSelfTest and allowSelfPromote) then error('Befördern ist nur nach oben möglich. Der ausgewählte Rang ist nicht höher als der aktuelle Rang.') end
        end
        -- SetJob wird mit dem echten shared/jobs.lua-Schlüssel aufgerufen; manche Forks erwarten zusätzlich die numerische Stufe.
        local changed = target.Functions.SetJob(org.job, tonumber(gradeKey) or gradeKey)
        local updatedJob = target.PlayerData.job or {}
        -- QBCore-Forks können PlayerData.job.grade erst nach SetJob aktualisieren.
        -- Die Rangänderung wird hier deshalb nicht anhand des unmittelbar gelesenen
        -- PlayerData-Caches verworfen: SetJob kann bereits erfolgreich sein, obwohl
        -- die lokale Tabelle noch den vorherigen Rang enthält.
        if changed == false or (updatedJob.name ~= nil and updatedJob.name ~= org.job) then
            error(('QBCore hat den Job nicht übernommen. Erwartet: %s; tatsächlich: %s. Prüfe shared/jobs.lua.'):format(tostring(org.job), tostring(updatedJob.name)))
        end
        -- Bestehende Dienstausweise direkt nach Rekrutierung/Beförderung aktualisieren.
        syncEmployeeServiceCards(target)
        local targetName = playerName(targetId)
        if effectiveAction == 'recruit' then
            MySQL.update.await('INSERT IGNORE INTO ui_org_employment_dates (org_key, identifier, employee_name) VALUES (?, ?, ?)', { orgKey, target.PlayerData.citizenid, targetName })
            MySQL.update.await('UPDATE ui_org_employment_dates SET employee_name = ? WHERE org_key = ? AND identifier = ?', { targetName, orgKey, target.PlayerData.citizenid })
        else
            MySQL.update.await('INSERT IGNORE INTO ui_org_employment_dates (org_key, identifier, employee_name) VALUES (?, ?, ?)', { orgKey, target.PlayerData.citizenid, targetName })
            MySQL.update.await('UPDATE ui_org_employment_dates SET employee_name = ? WHERE org_key = ? AND identifier = ?', { targetName, orgKey, target.PlayerData.citizenid })
        end
        local gradeLabel = tostring((type(gradeData) == 'table' and (gradeData.name or gradeData.label)) or requestedGrade)
        local msg = effectiveAction == 'recruit'
            and (targetName .. ' wurde der Rang ' .. gradeLabel .. ' zugewiesen.')
            or (targetName .. ' wurde auf ' .. gradeLabel .. ' befördert.')
        notify(src, msg, 'success')
        notify(targetId, effectiveAction == 'recruit' and ('Dir wurde bei ' .. tostring(org.label) .. ' der Rang ' .. gradeLabel .. ' zugewiesen.') or ('Dein Rang bei ' .. tostring(org.label) .. ' wurde auf ' .. gradeLabel .. ' geändert.'), 'success')
        TriggerClientEvent('universal_identity:tabletEmployeeJobResult', src, { success = true, targetId = targetId, rank = gradeLabel, level = resolvedLevel, jobLabel = org.label, message = msg, deputy = getDeputyOverview(orgKey) })
        TriggerClientEvent('universal_identity:orgEmployeeRankUpdated', -1, { targetId = targetId, rank = gradeLabel, level = resolvedLevel, jobLabel = org.label, name = targetName, orgKey = orgKey, deputy = getDeputyOverview(orgKey), isCurrentUser = (targetId == src) })
    end, debug.traceback)
    if not ok then
        local failureText = tostring(failure)
        local firstLine = failureText:match('([^\n]+)') or failureText
        firstLine = firstLine:gsub('^.-:%d+: ', '')
        local msg = 'Mitarbeiteraktion fehlgeschlagen: ' .. firstLine
        log('Fehler bei Mitarbeiteraktion: ' .. failureText)
        notify(src, msg, 'error')
        TriggerClientEvent('universal_identity:tabletEmployeeJobResult', src, { success = false, message = msg })
    end
end)

local function processOrgDocumentIssue(src, orgKey, targetId, requestedRank, documentType, personalIdConfirmed, permitFeeHandedOver, recruitmentRequested)
    print(('[Universal Identity] Dienstausweis-Ausstellung gestartet: Aussteller=%s Ziel=%s Organisation=%s'):format(tostring(src), tostring(targetId), tostring(orgKey)))
    if not waitReady() then local msg = 'Dokumentensystem noch nicht bereit.'; notify(src, msg, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg }); return end
    orgKey = tostring(orgKey or '')
    targetId = tonumber(targetId)
    local adminSelfTest = targetId == tonumber(src) and isPoliceTestMode(orgKey) and Config.Documents.AllowSelfIssueForTesting == true and adminAllowed(src)
    local access, err = getOrgAccess(src, orgKey)
    if not access then notify(src, err, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = err }); return end
    if not adminSelfTest and not isNearLocation(src, OrgPcLocations, orgKey, (Config.Documents.OrgPcInteractionDistance or 2.0) + 1.0) then
        local msg = 'Du musst am Organisations-PC bleiben.'
        notify(src, msg, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg }); return
    end
    targetId = tonumber(targetId)
    local target = targetId and QBCore.Functions.GetPlayer(targetId)
    if not target then local msg = 'Spieler ist nicht online.'; notify(src, msg, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg }); return end
    if targetId == src and not adminSelfTest then
        local msg = 'Selbstausstellung ist deaktiviert. Suche die Server-ID eines anderen Mitarbeiters.'
        notify(src, msg, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg }); return
    end
    documentType = tostring(documentType or 'organisation_id')
    if documentType ~= 'organisation_id' and documentType ~= 'weapon_permit' then documentType = 'organisation_id' end
    local targetIsOrgMember = (target.PlayerData.job or {}).name == access.org.job
    local canRecruit = hasOrgPermission(src, orgKey, 'hire_employee', access.leader or access.deputy)
    local canIssueExistingDocument = hasOrgPermission(src, orgKey, 'issue_org_document', access.leader or access.deputy)
    if documentType == 'organisation_id' and not targetIsOrgMember and not adminSelfTest then
        if not canRecruit then
            local msg = 'Für eine Neueinstellung benötigst du die Berechtigung „Mitarbeiter einstellen“.'
            notify(src, msg, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg }); return
        end
    elseif not adminSelfTest and not canIssueExistingDocument then
        local msg = 'Du hast keine Berechtigung, bestehende Dienstausweise auszustellen.'
        notify(src, msg, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg }); return
    end
    local identifier = target.PlayerData.citizenid
    if Config.Documents.RequirePhotoForOrganisationId and not hasPhoto(identifier) then
        local msg = 'Ausstellung gesperrt: Spieler benötigt zuerst ein bestätigtes Foto.'
        notify(src, msg, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg }); return
    end
    local personal = MySQL.single.await("SELECT id, status FROM ui_universal_documents WHERE owner_identifier = ? AND document_type = 'personal_id' ORDER BY id DESC LIMIT 1", { identifier })
    if Config.Documents.RequirePersonalIdForOrganisationId and (not personal or personal.status ~= 'issued') then
        local msg = 'Ausstellung gesperrt: der Personalausweis muss gültig und bereits abgeholt sein.'
        notify(src, msg, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg }); return
    end
    if Config.Documents.RequirePersonalIdForOrganisationId and personalIdConfirmed ~= true then
        local msg = 'Ausstellung gesperrt: bitte bestätigen, dass der gültige Personalausweis vorgezeigt wurde (gilt auch für den Waffenschein).'
        notify(src, msg, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg }); return
    end
    local c = target.PlayerData.charinfo or {}
    local ownerName = (('%s %s'):format(c.firstname or '', c.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
    local selectedRank = documentType == 'organisation_id' and getAllowedDocumentRank(orgKey, requestedRank) or nil
    local rank = selectedRank and tostring(selectedRank.label) or ''
    local rankLevel = selectedRank and (tonumber(selectedRank.level) or tonumber(selectedRank.value)) or nil
    if documentType == 'organisation_id' and targetIsOrgMember then
        local currentGradeKey, currentGradeData, currentGradeLevel = resolvePlayerJobGrade(access.org.job, target.PlayerData.job or {})
        if not currentGradeKey or not currentGradeLevel then
            local message = 'Der aktuelle QBCore-Rang des Mitarbeiters konnte nicht aus shared/jobs.lua gelesen werden.'
            notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
        end
        selectedRank = getAllowedDocumentRank(orgKey, currentGradeKey) or getAllowedDocumentRank(orgKey, tostring(currentGradeLevel))
        if not selectedRank then
            for _, option in ipairs(getDocumentRankOptions(orgKey)) do
                if tonumber(option.level) == tonumber(currentGradeLevel) then selectedRank = option; break end
            end
        end
        if not selectedRank then
            local message = 'Der aktuelle QBCore-Rang ist nicht in den Dienstausweis-Rangoptionen enthalten. Bitte Konfiguration prüfen.'
            notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
        end
        rank = tostring(selectedRank.label)
        rankLevel = tonumber(selectedRank.level) or currentGradeLevel
    end
    if documentType == 'organisation_id' and not targetIsOrgMember and not adminSelfTest then
        local issuer = QBCore.Functions.GetPlayer(src)
        local issuerGradeLevel = nil
        if issuer then
            local _, _, resolvedIssuerLevel = resolvePlayerJobGrade(access.org.job, issuer.PlayerData.job or {})
            issuerGradeLevel = resolvedIssuerLevel
        end
        if not issuerGradeLevel then
            local message = 'Dein eigener QBCore-Rang konnte nicht sicher aufgelöst werden. Eine Neueinstellung ist deshalb nicht möglich.'
            notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
        end
        if not rankLevel or rankLevel >= issuerGradeLevel then
            local message = 'Du darfst nur einen niedrigeren Rang als deinen eigenen vergeben. Wähle einen Rang unter deiner aktuellen Stufe.'
            notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
        end
    end
    local number, docId, docType, details, msg
    local issuerIdentifier, issuerName = charId(src), playerName(src)
    local permitFee = 0
    if documentType == 'weapon_permit' then
        local existingPermit = MySQL.single.await("SELECT id FROM ui_universal_documents WHERE owner_identifier = ? AND document_type = 'weapon_permit' AND status IN ('pending_handover', 'processing', 'collected_by_issuer', 'issued') LIMIT 1", { identifier })
        if existingPermit then
            local message = 'Für diesen Spieler existiert bereits ein aktiver Waffenschein.'
            notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
        end
        local targetJobName = tostring((target.PlayerData.job or {}).name or 'unemployed')
        local freeJobs = Config.Documents.WeaponPermitFreeJobs or { police = true }
        permitFee = (targetJobName == tostring(access.org.job or '') or freeJobs[targetJobName] == true) and 0 or WeaponPermitTabletFee
        if permitFee > 0 and permitFeeHandedOver ~= true then
            local message = ('Der Spieler gehört nicht zur Polizei. Vor der Ausstellung müssen $%s persönlich an den Aussteller übergeben werden. Es wird kein Geld automatisch abgezogen.'):format(permitFee)
            notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
        end
        number = makeNumber('WP')
        docType = 'weapon_permit'
        local insertOk, insertResult = pcall(function()
            return MySQL.insert.await([[INSERT INTO ui_universal_documents (document_number, document_type, owner_identifier, owner_name, organisation_key, rank_label, status, issued_by, issued_by_name) VALUES (?, 'weapon_permit', ?, ?, ?, '', 'pending_handover', ?, ?)]], { number, identifier, ownerName, orgKey, issuerIdentifier, issuerName })
        end)
        if insertOk then docId = insertResult end
        details = ('Organisation: %s; Waffenschein; Gebühr: $%s; Zahlung persönlich bestätigt: %s'):format(access.org.label, permitFee, permitFee > 0 and 'ja' or 'nicht erforderlich')
        msg = permitFee > 0 and ('Gebühr von $%s wurde vom Aussteller als persönlich erhalten bestätigt. Waffenschein %s ist zur Abholung bereit.'):format(permitFee, number) or ('Waffenschein %s wurde für ein Polizeimitglied kostenlos ausgestellt und ist zur Abholung bereit.'):format(number)
    else
        if not selectedRank or not rankLevel then
            local message = 'Bitte wähle eine gültige Rang-Bezeichnung aus der Liste.'
            notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
        end
        local existingOrgDoc = MySQL.single.await("SELECT id FROM ui_universal_documents WHERE owner_identifier = ? AND organisation_key = ? AND document_type = 'organisation_id' AND status IN ('pending_handover', 'processing', 'collected_by_issuer', 'issued') LIMIT 1", { identifier, orgKey })
        if existingOrgDoc then
            local message = 'Für diesen Mitarbeiter existiert bereits ein aktiver Dienstausweis.'
            notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
        end
        number = makeNumber('ORG')
        docType = 'organisation_id'
        docId = MySQL.insert.await([[INSERT INTO ui_universal_documents (document_number, document_type, owner_identifier, owner_name, organisation_key, rank_label, rank_level, is_recruitment, status, issued_by, issued_by_name) VALUES (?, 'organisation_id', ?, ?, ?, ?, ?, ?, 'pending_handover', ?, ?)]], { number, identifier, ownerName, orgKey, rank, rankLevel, (not targetIsOrgMember and not adminSelfTest) and 1 or 0, issuerIdentifier, issuerName })
        details = ('Organisation: %s; Rang: %s; Neueinstellung: %s%s'):format(access.org.label, rank, (not targetIsOrgMember and not adminSelfTest) and 'ja' or 'nein', adminSelfTest and '; Serveradmin-Selbstausstellung im Testmodus; QBCore-Job unverändert' or '')

        -- Bei einer Neueinstellung wird der Job bereits beim Klick auf „Ausweis ausstellen“ gesetzt.
        -- Die spätere Abholung/Übergabe betrifft nur noch das physische Dokument.
        if not targetIsOrgMember and not adminSelfTest then
            local gradeKey, gradeData, resolvedLevel = resolveSharedJobGrade(access.org.job, rankLevel)
            if not gradeKey or not resolvedLevel then
                MySQL.update.await("UPDATE ui_universal_documents SET status = 'revoked' WHERE id = ? AND status = 'pending_handover'", { docId })
                local message = ('Der ausgewählte Rang %s konnte nicht in QBCore.Shared.Jobs[%s].grades aufgelöst werden.'):format(rank, tostring(access.org.job))
                notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
            end
            local previousJob = target.PlayerData.job or {}
            local previousJobName = tostring(previousJob.name or 'unemployed')
            local previousGrade = previousJob.grade or 0
            local previousGradeLevel = type(previousGrade) == 'table' and tonumber(previousGrade.level or previousGrade.grade) or tonumber(previousGrade) or 0
            local setOk, setResult = pcall(function() return target.Functions.SetJob(access.org.job, tonumber(gradeKey) or gradeKey) end)
            if not setOk or setResult == false then
                -- Falls ein QBCore-Fork trotz Fehler teilweise umgeschaltet hat, den alten Job wiederherstellen.
                pcall(function() target.Functions.SetJob(previousJobName, previousGradeLevel) end)
                MySQL.update.await("UPDATE ui_universal_documents SET status = 'revoked' WHERE id = ? AND status = 'pending_handover'", { docId })
                log(('Neueinstellung SetJob fehlgeschlagen: Spieler %s, Job %s, Grade %s, Fehler %s'):format(tostring(targetId), tostring(access.org.job), tostring(gradeKey), tostring(setResult)))
                local message = 'QBCore konnte den Polizeijob nicht zuweisen. Der Ausweis wurde nicht freigegeben; bitte Serverkonsole prüfen.'
                notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
            end
            Wait(100)
            target = QBCore.Functions.GetPlayer(targetId) or target
            local actualJob = target.PlayerData and target.PlayerData.job or {}
            local actualGrade = actualJob.grade or {}
            local actualLevel = type(actualGrade) == 'table' and tonumber(actualGrade.level or actualGrade.grade) or tonumber(actualGrade)
            local actualGradeName = type(actualGrade) == 'table' and tostring(actualGrade.name or actualGrade.label or '') or ''
            local expectedGradeName = type(gradeData) == 'table' and tostring(gradeData.name or gradeData.label or '') or ''
            local gradeApplied = actualLevel ~= nil and actualLevel == resolvedLevel or actualLevel == nil and expectedGradeName ~= '' and actualGradeName == expectedGradeName
            if tostring(actualJob.name or '') ~= tostring(access.org.job) or not gradeApplied then
                pcall(function() target.Functions.SetJob(previousJobName, previousGradeLevel) end)
                MySQL.update.await("UPDATE ui_universal_documents SET status = 'revoked' WHERE id = ? AND status = 'pending_handover'", { docId })
                log(('Neueinstellung SetJob-Verifikation fehlgeschlagen: Spieler %s, erwartet %s/%s, erhalten %s/%s'):format(tostring(targetId), tostring(access.org.job), tostring(resolvedLevel), tostring(actualJob.name), tostring(actualLevel or actualGradeName)))
                local message = 'QBCore hat den ausgewählten Polizei-Job oder Rang nicht bestätigt. Die Ausstellung wurde abgebrochen.'
                notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
            end
            syncEmployeeServiceCards(target)
            MySQL.insert.await('INSERT INTO ui_org_employment_dates (org_key, identifier, employee_name, hired_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP) ON DUPLICATE KEY UPDATE employee_name = VALUES(employee_name), hired_at = CURRENT_TIMESTAMP', { orgKey, identifier, ownerName })
            details = details .. ('; SetJob sofort angewendet: %s / Grade %s'):format(tostring(access.org.job), tostring(resolvedLevel))
            notify(targetId, ('Du wurdest bei %s eingestellt. Dein Rang: %s. Dein Dienstausweis ist zur Abholung bereit.'):format(tostring(access.org.label), rank), 'success')
            msg = ('Neueinstellung erfolgreich: %s hat jetzt den Job %s mit Rang %s. Dienstausweis %s ist zur Abholung bereit; die persönliche Übergabe erfolgt danach.'):format(ownerName, tostring(access.org.job), rank, number)
        else
            msg = ('Dienstausweis %s wurde für %s gespeichert und ist zur Abholung bereit. Der bestehende Polizeijob bleibt bestehen.'):format(number, ownerName)
        end
    end
    if not docId then
        local message = (documentType == 'weapon_permit' and 'Waffenschein' or 'Dienstausweis') .. ' konnte nicht in der Datenbank angelegt werden.'
        notify(src, message, 'error'); TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = message }); return
    end
    auditDocument({ id = docId, document_number = number, document_type = docType, owner_identifier = identifier, owner_name = ownerName }, 'issued_waiting_pickup', src, details, targetId)
    notify(src, msg, 'success')
    TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = true, message = msg, documentNumber = number, waitingPickup = true })
end

RegisterNetEvent('universal_identity:issueOrgDocument', function(orgKey, targetId, rankLabel, documentType, personalIdConfirmed, permitFeeHandedOver, recruitmentRequested)
    local src = source
    local ok, err = xpcall(function() processOrgDocumentIssue(src, orgKey, targetId, rankLabel, documentType, personalIdConfirmed == true, permitFeeHandedOver == true, recruitmentRequested == true) end, debug.traceback)
    if not ok then
        print(('[Universal Identity] FEHLER bei Dienstausweis-Ausstellung für Spieler %s: %s'):format(tostring(src), tostring(err)))
        local msg = 'Die Ausstellung ist serverseitig fehlgeschlagen. Bitte Serverkonsole prüfen; es wurde keine Erfolgsmeldung ausgegeben.'
        notify(src, msg, 'error')
        TriggerClientEvent('universal_identity:tabletIssueResult', src, { success = false, message = msg })
    end
end)

-- Der Aussteller holt seinen ausgestellten Dienstausweis an einer Ausgabestelle ab.
RegisterNetEvent('universal_identity:collectOrgDocument', function()
    local src = source
    local adminTestCollector = adminAllowed(src) and isPoliceTestMode('police') and Config.Documents.AllowSelfIssueForTesting == true
    if not adminTestCollector and not requirePoliceAccess(src) then return end
    if not waitReady() then notify(src, 'Dokumentensystem noch nicht bereit.', 'error'); return end
    if not isNearPickupType(src, 'police', (Config.Documents.PickupInteractionDistance or 2.0) + 1.0) then notify(src, 'Du musst an einer Polizei-Ausgabestelle stehen.', 'error'); return end
    local issuerIdentifier = charId(src)
    if not issuerIdentifier then return end
    local row
    if adminTestCollector then
        row = MySQL.single.await([[
            SELECT * FROM ui_universal_documents
            WHERE issued_by = ? AND owner_identifier = ? AND document_type = 'organisation_id' AND status = 'pending_handover'
            ORDER BY id ASC LIMIT 1
        ]], { issuerIdentifier, issuerIdentifier })
    else
        row = MySQL.single.await([[
            SELECT * FROM ui_universal_documents
            WHERE issued_by = ? AND document_type = 'organisation_id' AND status = 'pending_handover'
            ORDER BY id ASC LIMIT 1
        ]], { issuerIdentifier })
    end
    if not row then notify(src, 'Du hast keinen Dienstausweis zur Abholung.', 'error'); return end
    if adminTestCollector and row.owner_identifier ~= issuerIdentifier then notify(src, 'Im Admin-Testmodus darfst du nur deinen eigenen Dienstausweis abholen.', 'error'); return end
    local claimed = MySQL.update.await("UPDATE ui_universal_documents SET status = 'processing' WHERE id = ? AND status = 'pending_handover'", { row.id })
    if not claimed or claimed < 1 then notify(src, 'Dieser Dienstausweis wird bereits abgeholt.', 'error'); return end
    local itemName = Config.Documents.OrganisationIdItem or 'universal_org_id'
    local issuerPlayer = QBCore.Functions.GetPlayer(src)
    local org = Config.Documents.Organisations[row.organisation_key] or {}
    local metadata = {
        documentId = row.id, documentNumber = row.document_number, ownerIdentifier = row.owner_identifier,
        ownerName = row.owner_name, organisation = org.label or row.organisation_key,
        organisationKey = row.organisation_key, rank = row.rank_label,
        issuerIdentifier = issuerIdentifier, issuerName = playerName(src), status = 'collected_by_issuer'
    }
    local added = issuerPlayer and issuerPlayer.Functions.AddItem(itemName, 1, false, metadata)
    if not added then
        MySQL.update.await("UPDATE ui_universal_documents SET status = 'pending_handover' WHERE id = ? AND status = 'processing'", { row.id })
        notify(src, ('Inventar voll oder Item \"%s\" fehlt. Der Dienstausweis bleibt abholbereit.'):format(itemName), 'error'); return
    end
    MySQL.update.await("UPDATE ui_universal_documents SET status = 'collected_by_issuer' WHERE id = ? AND status = 'processing'", { row.id })
    auditDocument(row, 'collected_by_issuer', src, 'Dienstausweis an der Ausgabestelle abgeholt.', nil)
    notify(src, ('Dienstausweis %s abgeholt. Übergib ihn mit /uidgiveorg [Server-ID] an den vorgesehenen Mitarbeiter.'):format(row.document_number), 'success')
end)

-- Waffenschein an derselben Ausgabestelle abholen, sofern ein ausstellender Ablauf einen pending_handover-Datensatz angelegt hat.
RegisterNetEvent('universal_identity:applyWeaponPermit', function()
    local src = source
    if not waitReady() then notify(src, 'Dokumentensystem noch nicht bereit.', 'error'); return end
    if not isNearPickupType(src, 'police', (Config.Documents.PickupInteractionDistance or 2.0) + 1.0) then
        notify(src, 'Du musst an einer Polizei-Ausgabestelle sein, um einen Waffenschein zu beantragen.', 'error'); return
    end
    local player = QBCore.Functions.GetPlayer(src); if not player then return end
    local identifier = player.PlayerData.citizenid
    if not identifier or not hasPhoto(identifier) then notify(src, 'Für den Antrag benötigst du zuerst ein bestätigtes Charakterfoto.', 'error'); return end
    local personal = MySQL.single.await("SELECT id,status FROM ui_universal_documents WHERE owner_identifier = ? AND document_type = 'personal_id' AND status = 'issued' ORDER BY id DESC LIMIT 1", { identifier })
    if not personal then notify(src, 'Für den Antrag benötigst du einen bereits abgeholten Personalausweis.', 'error'); return end
    local existing = MySQL.single.await("SELECT id FROM ui_universal_documents WHERE owner_identifier = ? AND document_type = 'weapon_permit' AND status IN ('pending_handover','processing','collected_by_issuer','issued','ready') LIMIT 1", { identifier })
    if existing then notify(src, 'Du besitzt bereits einen aktiven Waffenschein oder hast einen Antrag gestellt.', 'error'); return end
    local jobName = tostring((player.PlayerData.job or {}).name or 'unemployed')
    local policeOrg = Config.Documents.Organisations and Config.Documents.Organisations.police or {}
    local freeJobs = Config.Documents.WeaponPermitFreeJobs or {}
    local price = (jobName == tostring(policeOrg.job or 'police') or freeJobs[jobName] == true) and 0 or math.max(0, tonumber(Config.Documents.WeaponPermitApplicationPrice) or 6500)
    if price > 0 then
        local money = player.PlayerData.money or {}
        local account = tonumber(money.cash) >= price and 'cash' or (tonumber(money.bank) >= price and 'bank' or nil)
        if not account then notify(src, ('Der Waffenschein kostet $%s. Du hast nicht genug Bargeld oder Bankguthaben.'):format(price), 'error'); return end
        if not player.Functions.RemoveMoney(account, price, 'universal-identity-weapon-permit-application') then notify(src, 'Die Gebühr konnte nicht abgebucht werden.', 'error'); return end
    end
    local number = makeNumber('WP')
    local name = playerName(src)
    local docId = MySQL.insert.await([[INSERT INTO ui_universal_documents (document_number, document_type, owner_identifier, owner_name, organisation_key, rank_label, status, issued_by, issued_by_name) VALUES (?, 'weapon_permit', ?, ?, 'civilian', '', 'pending_handover', ?, ?)]], { number, identifier, name, identifier, name })
    if not docId then
        if price > 0 then player.Functions.AddMoney('cash', price, 'universal-identity-weapon-permit-refund') end
        notify(src, 'Der Antrag konnte nicht gespeichert werden. Eine Gebühr wurde ggf. zurückerstattet.', 'error'); return
    end
    auditDocument({ id = docId, document_number = number, document_type = 'weapon_permit', owner_identifier = identifier, owner_name = name }, 'issued_waiting_pickup', src, ('Privater Waffenschein-Antrag; Gebühr: $%s'):format(price), src)
    notify(src, price == 0 and ('Waffenschein-Antrag angenommen. Für deinen Polizeijob ist er kostenlos. Nummer: %s. Hole ihn an dieser Ausgabestelle ab.'):format(number) or ('Waffenschein-Antrag angenommen. $%s bezahlt. Nummer: %s. Hole ihn an dieser Ausgabestelle ab.'):format(price, number), 'success')
end)

RegisterNetEvent('universal_identity:collectWeaponPermit', function()
    local src = source
    local adminTestCollector = adminAllowed(src) and isPoliceTestMode('police') and Config.Documents.AllowSelfIssueForTesting == true
    if not adminTestCollector and not requirePoliceAccess(src) then return end
    if not waitReady() then notify(src, 'Dokumentensystem noch nicht bereit.', 'error'); return end
    if not isNearPickupType(src, 'police', (Config.Documents.PickupInteractionDistance or 2.0) + 1.0) then notify(src, 'Du musst an einer Polizei-Ausgabestelle stehen.', 'error'); return end
    local identifier = charId(src)
    if not identifier then return end
    local row
    if adminTestCollector then
        row = MySQL.single.await([[SELECT * FROM ui_universal_documents WHERE issued_by = ? AND owner_identifier = ? AND document_type = 'weapon_permit' AND status = 'pending_handover' ORDER BY id ASC LIMIT 1]], { identifier, identifier })
    else
        row = MySQL.single.await([[SELECT * FROM ui_universal_documents WHERE issued_by = ? AND document_type = 'weapon_permit' AND status = 'pending_handover' ORDER BY id ASC LIMIT 1]], { identifier })
    end
    if not row then notify(src, 'Du hast keinen Waffenschein zur Abholung.', 'error'); return end
    local claimed = MySQL.update.await("UPDATE ui_universal_documents SET status = 'processing' WHERE id = ? AND status = 'pending_handover'", { row.id })
    if not claimed or claimed < 1 then notify(src, 'Dieser Waffenschein wird bereits abgeholt.', 'error'); return end
    local itemName = (Config.Documents.OtherTypes and Config.Documents.OtherTypes.weapon_permit and Config.Documents.OtherTypes.weapon_permit.item) or 'universal_weapon_permit'
    local player = QBCore.Functions.GetPlayer(src)
    local metadata = { documentId = row.id, documentNumber = row.document_number, ownerIdentifier = row.owner_identifier, ownerName = row.owner_name, issuerIdentifier = row.issued_by or identifier, issuerName = row.issued_by_name or playerName(src), status = 'collected_by_issuer' }
    local added = player and player.Functions.AddItem(itemName, 1, false, metadata)
    if not added then MySQL.update.await("UPDATE ui_universal_documents SET status = 'pending_handover' WHERE id = ? AND status = 'processing'", { row.id }); notify(src, ('Inventar voll oder Item "%s" fehlt.'):format(itemName), 'error'); return end
    MySQL.update.await("UPDATE ui_universal_documents SET status = 'collected_by_issuer' WHERE id = ? AND status = 'processing'", { row.id })
    auditDocument(row, 'collected_by_issuer', src, 'Waffenschein an der Ausgabestelle abgeholt.', nil)
    notify(src, ('Waffenschein %s abgeholt.'):format(row.document_number), 'success')
end)

-- Übergibt einen abgeholten Dienstausweis ausschließlich an den vorgesehenen Mitarbeiter.
local function giveOrgDocumentToPlayer(src, targetId)
    targetId = tonumber(targetId)
    if not targetId then notify(src, 'Bitte gib eine gültige Server-ID des Mitarbeiters an.', 'error'); return end
    local issuer = QBCore.Functions.GetPlayer(src)
    local target = QBCore.Functions.GetPlayer(targetId)
    if not issuer or not target then notify(src, 'Aussteller oder Mitarbeiter ist nicht online.', 'error'); return end
    local itemName = Config.Documents.OrganisationIdItem or 'universal_org_id'
    local item = issuer.Functions.GetItemByName(itemName)
    local info = item and (item.info or item.metadata)
    if not item or not info or not tonumber(info.documentId) then notify(src, 'Du hast keinen abgeholten Dienstausweis im Inventar.', 'error'); return end
    local doc = MySQL.single.await("SELECT * FROM ui_universal_documents WHERE id = ? AND document_type = 'organisation_id' AND status = 'collected_by_issuer' LIMIT 1", { tonumber(info.documentId) })
    if not doc or doc.issued_by ~= charId(src) or doc.owner_identifier ~= target.PlayerData.citizenid then
        notify(src, 'Dieser Dienstausweis ist nicht für diesen Mitarbeiter bestimmt oder gehört nicht zu dir.', 'error'); return
    end
    local adminSelfHandover = targetId == src and adminAllowed(src) and isPoliceTestMode(tostring(doc.organisation_key or '')) and Config.Documents.AllowSelfIssueForTesting == true and doc.owner_identifier == target.PlayerData.citizenid
    if targetId == src and not adminSelfHandover then
        notify(src, 'Eine Selbstübergabe ist ausschließlich Serveradmins im aktivierten Polizei-Testmodus erlaubt.', 'error'); return
    end
    local access = getOrgAccess(src, tostring(doc.organisation_key or ''))
    if not access or (not adminSelfHandover and not hasOrgPermission(src, tostring(doc.organisation_key or ''), 'issue_org_document', access.leader or access.deputy)) then
        notify(src, 'Du bist nicht mehr berechtigt, diesen Dienstausweis zu übergeben.', 'error'); return
    end
    local org = Config.Documents.Organisations[doc.organisation_key] or {}
    local targetCurrentJob = tostring((target.PlayerData.job or {}).name or 'unemployed')
    if not adminSelfHandover and targetCurrentJob ~= tostring(org.job or '') then
        notify(src, 'Der Spieler hat den Polizeijob nicht mehr. Bitte prüfe den Einstellungsstatus vor der Übergabe.', 'error')
        return
    end
    -- Job und Rang wurden bei einer Neueinstellung bereits beim Klick auf „Ausweis ausstellen“ gesetzt.
    -- Bei der Übergabe wird nur noch geprüft, ob der gespeicherte Rang weiterhin aktiv ist.
    local rankLabel = tostring(doc.rank_label or '')
    local targetGradeLevel = tonumber(doc.rank_level)
    local targetGradeKey, targetGradeData, resolvedGradeLevel = resolveSharedJobGrade(org.job, targetGradeLevel)
    if not adminSelfHandover and (not targetGradeKey or not resolvedGradeLevel) then
        notify(src, ('Der gespeicherte Rang "%s" ist in QBCore nicht mehr vorhanden.'):format(rankLabel), 'error')
        return
    end
    local actualJob = target.PlayerData and target.PlayerData.job or {}
    local actualGrade = actualJob.grade or {}
    local actualLevel = type(actualGrade) == 'table' and tonumber(actualGrade.level or actualGrade.grade) or tonumber(actualGrade)
    local actualGradeName = type(actualGrade) == 'table' and tostring(actualGrade.name or actualGrade.label or '') or ''
    local expectedGradeName = type(targetGradeData) == 'table' and tostring(targetGradeData.name or targetGradeData.label or '') or ''
    local gradeApplied = actualLevel ~= nil and actualLevel == resolvedGradeLevel or actualLevel == nil and expectedGradeName ~= '' and actualGradeName == expectedGradeName
    if not adminSelfHandover and (tostring(actualJob.name or '') ~= tostring(org.job or '') or not gradeApplied) then
        notify(src, 'Die Übergabe wurde gestoppt: Der Mitarbeiter hat nicht mehr den bei der Ausstellung festgelegten Polizei-Jobrang.', 'error')
        return
    end
    -- Der Job wurde bereits bei der Ausstellung gesetzt. Jetzt wird ausschließlich das Item übergeben.
    local removed = issuer.Functions.RemoveItem(itemName, 1, item.slot)
    if not removed then notify(src, 'Dienstausweis konnte nicht aus deinem Inventar genommen werden.', 'error'); return end
    local targetInfo = {}
    for k, v in pairs(info) do targetInfo[k] = v end
    targetInfo.status = 'issued'
    local added = target.Functions.AddItem(itemName, 1, false, targetInfo)
    if not added then
        issuer.Functions.AddItem(itemName, 1, false, info)
        notify(src, 'Inventar des Mitarbeiters ist voll. Der Dienstausweis bleibt bei dir.', 'error')
        return
    end
    local updated = MySQL.update.await("UPDATE ui_universal_documents SET status = 'issued', handed_over_at = CURRENT_TIMESTAMP WHERE id = ? AND status = 'collected_by_issuer'", { doc.id })
    if not updated or updated < 1 then
        target.Functions.RemoveItem(itemName, 1)
        issuer.Functions.AddItem(itemName, 1, false, info)
        notify(src, 'Datenbank konnte die Übergabe nicht bestätigen. Der Ausweis bleibt bei dir.', 'error')
        return
    end
    if not adminSelfHandover then syncEmployeeServiceCards(target) end
    auditDocument(doc, 'handed_to_owner', src, (adminSelfHandover and 'Admin-Test-Selbstausstellung; QBCore-Job unverändert. ' or '') .. ('Dienstausweis persönlich übergeben. Job: %s; Rang: %s (Grade %s).'):format(tostring(org.job), rankLabel, tostring(resolvedGradeLevel)), targetId)
    notify(src, ('Dienstausweis %s wurde an %s übergeben. Job %s, Rang %s bleibt aktiv.'):format(doc.document_number, doc.owner_name, tostring(org.job), rankLabel), 'success')
    notify(targetId, ('Du hast deinen Dienstausweis %s erhalten.'):format(doc.document_number), 'success')
end

RegisterNetEvent('universal_identity:giveOrgDocument', function(targetId)
    giveOrgDocumentToPlayer(source, targetId)
end)

RegisterCommand('uidgiveorg', function(src, args)
    if src == 0 then
        print('[Universal Identity] /uidgiveorg kann nur von einem Spieler ausgeführt werden.')
        return
    end
    giveOrgDocumentToPlayer(src, args[1])
end, false)

RegisterNetEvent('universal_identity:collectPersonalId', function()
    local src = source
    if not waitReady() then notify(src, 'Dokumentensystem noch nicht bereit.', 'error'); return end
    if not isNearPickupType(src, 'personal', (Config.Documents.PickupInteractionDistance or 2.0) + 1.0) then notify(src, 'Du musst an einer Personalausweis-Abholstation stehen.', 'error'); return end
    local identifier = charId(src)
    if not identifier or not hasPhoto(identifier) then notify(src, 'Bitte beantrage zuerst deinen Personalausweis.', 'error'); return end
    local row = MySQL.single.await("SELECT * FROM ui_universal_documents WHERE owner_identifier = ? AND document_type = 'personal_id' AND status = 'ready' LIMIT 1", { identifier })
    if not row then notify(src, 'Dein Personalausweis ist noch nicht abholbereit.', 'error'); return end
    local claimed = MySQL.update.await("UPDATE ui_universal_documents SET status = 'processing' WHERE id = ? AND status = 'ready'", { row.id })
    if not claimed or claimed < 1 then notify(src, 'Wird bereits abgeholt.', 'error'); return end
    local itemName = Config.Documents.PersonalIdItem or 'universal_personal_id'
    local metadata = { documentId = row.id, documentNumber = row.document_number, ownerIdentifier = identifier, ownerName = row.owner_name, issuerIdentifier = 'system', issuerName = 'Universal Identity / Ausgabestelle', status = 'issued' }
    local ownerPlayer = QBCore.Functions.GetPlayer(src)
    local added = ownerPlayer and ownerPlayer.Functions.AddItem(itemName, 1, false, metadata)
    if not added then
        MySQL.update.await("UPDATE ui_universal_documents SET status = 'ready' WHERE id = ? AND status = 'processing'", { row.id })
        notify(src, ('Inventar voll oder Item "%s" fehlt.'):format(itemName), 'error'); return
    end
    MySQL.update.await("UPDATE ui_universal_documents SET status = 'issued', issued_by = 'system', issued_by_name = 'Universal Identity / Ausgabestelle', handed_over_at = CURRENT_TIMESTAMP WHERE id = ? AND status = 'processing'", { row.id })
    auditDocument(row, 'collected', 0, 'Personalausweis ausgegeben.', src)
    notify(src, ('Personalausweis %s abgeholt.'):format(row.document_number), 'success')
end)

-- Die Inventar-Items lassen sich benutzen und öffnen die echte Dokumentenansicht.
-- Die Vorschau aller Kartentypen bleibt ausschließlich unter /uidpreview.
CreateThread(function()
    Wait(0)
    local personalItem = Config.Documents.PersonalIdItem or 'universal_personal_id'
    local orgItem = Config.Documents.OrganisationIdItem or 'universal_org_id'
    QBCore.Functions.CreateUseableItem(personalItem, function(src)
        TriggerClientEvent('universal_identity:openMyDocuments', src)
    end)
    if orgItem ~= personalItem then
        QBCore.Functions.CreateUseableItem(orgItem, function(src)
            TriggerClientEvent('universal_identity:openMyDocuments', src)
        end)
    end
    for _, typeName in ipairs({ 'weapon_permit', 'fishing_license', 'boat_license', 'pilot_license' }) do
        local typeConfig = Config.Documents.OtherTypes and Config.Documents.OtherTypes[typeName]
        local itemName = typeConfig and typeConfig.item
        if itemName and itemName ~= personalItem and itemName ~= orgItem then
            QBCore.Functions.CreateUseableItem(itemName, function(src)
                TriggerClientEvent('universal_identity:openMyDocuments', src)
            end)
        end
    end
end)

RegisterNetEvent('universal_identity:showDocumentToPlayer', function(targetId, requestedType)
    local src = source; targetId = tonumber(targetId); requestedType = tostring(requestedType or ''):lower()
    local aliases = { personalausweis = 'personal_id', personal_id = 'personal_id', dienstausweis = 'organisation_id', organisation_id = 'organisation_id', waffenschein = 'weapon_permit', weapon_permit = 'weapon_permit', angelschein = 'fishing_license', fishing_license = 'fishing_license', bootsfuehrerschein = 'boat_license', boat_license = 'boat_license', pilotenschein = 'pilot_license', pilot_license = 'pilot_license' }
    local docType = aliases[requestedType]
    if not targetId or not docType then notify(src, 'Verwendung: /uidzeigen [Server-ID] [personalausweis|dienstausweis|waffenschein]', 'error'); return end
    local owner = QBCore.Functions.GetPlayer(src)
    if not owner then notify(src, 'Spieler nicht gefunden.', 'error'); return end
    local target = QBCore.Functions.GetPlayer(targetId)
    local testShow = Config.Documents.AllowRemoteDocumentShowForTesting == true
    -- Testmodus: wenn keine zweite Person online ist, wird die Karte dem eigenen Client gezeigt.
    if testShow and (not target or targetId == src) then target = owner; targetId = src end
    if not target then notify(src, 'Empfänger nicht online. Im Testmodus kannst du eine beliebige ID angeben, um die Karte selbst zu öffnen.', 'error'); return end
    if not testShow then
        if targetId == src then notify(src, 'Du kannst einen Ausweis nur einem anderen Spieler vorzeigen.', 'error'); return end
        local a, b = GetPlayerPed(src), GetPlayerPed(targetId)
        if not a or a == 0 or not b or b == 0 or #(GetEntityCoords(a) - GetEntityCoords(b)) > 3.0 then notify(src, 'Der Spieler muss höchstens 3 Meter entfernt sein.', 'error'); return end
    end
    local identifier = owner.PlayerData.citizenid
    if docType == 'organisation_id' then pcall(function() syncEmployeeServiceCards(owner) end) end
    local doc = MySQL.single.await("SELECT id,document_number,document_type,owner_name,organisation_key,rank_label,rank_level,status,created_at,issued_by_name,handed_over_at FROM ui_universal_documents WHERE owner_identifier = ? AND document_type = ? AND status IN ('issued','collected_by_issuer') ORDER BY id DESC LIMIT 1", { identifier, docType })
    if not doc then notify(src, 'Du hast keinen gültigen ausgestellten Ausweis dieses Typs in deiner Dokumentenmappe.', 'error'); return end
    if doc.document_type == 'organisation_id' then
        local documentOrg = Config.Documents.Organisations[tostring(doc.organisation_key or '')]
        doc.organisation_label = documentOrg and documentOrg.label or tostring(doc.organisation_key or 'Organisation')
    end
    local photo = photoDataUri(identifier)
    local ownerChar = owner.PlayerData and owner.PlayerData.charinfo or {}
    local birthdate = tostring(ownerChar.birthdate or ownerChar.dateofbirth or ownerChar.dob or '')
    if birthdate == '' then
        local row = MySQL.single.await('SELECT charinfo FROM players WHERE citizenid = ? LIMIT 1', { identifier })
        if row and row.charinfo then
            local ok, info = pcall(json.decode, row.charinfo)
            if ok and type(info) == 'table' then birthdate = tostring(info.birthdate or info.dateofbirth or info.dob or '') end
        end
    end
    doc.birthdate = birthdate ~= '' and birthdate or '—'
    TriggerClientEvent('universal_identity:openShownDocument', targetId, { documents = { doc }, photo = photo, preview = false, presentation = true })
    if targetId == src then notify(src, 'Testansicht des Dokuments geöffnet.', 'success') else notify(src, ('Du hast %s deinen %s vorgezeigt.'):format(playerName(targetId), ({ personal_id='Personalausweis', organisation_id='Dienstausweis', weapon_permit='Waffenschein', fishing_license='Angelschein', boat_license='Bootsführerschein', pilot_license='Pilotenschein' })[docType]), 'success') end
end)

RegisterNetEvent('universal_identity:requestMyDocuments', function()
    local src = source
    local identifier = charId(src)
    if not identifier then return end
    local docs = MySQL.query.await("SELECT id, document_number, document_type, owner_name, organisation_key, rank_label, status, created_at, issued_by_name FROM ui_universal_documents WHERE owner_identifier = ? AND status <> 'revoked'", { identifier }) or {}
    for _, doc in ipairs(docs) do
        if doc.document_type == 'organisation_id' then
            local documentOrg = Config.Documents.Organisations[tostring(doc.organisation_key or '')]
            doc.organisation_label = documentOrg and documentOrg.label or tostring(doc.organisation_key or 'Organisation')
        end
    end
    local player = QBCore.Functions.GetPlayer(src)
    local charinfo = player and player.PlayerData and player.PlayerData.charinfo or {}
    local birthdate = tostring(charinfo.birthdate or charinfo.dateofbirth or charinfo.dob or '')
    if birthdate == '' then local row = MySQL.single.await('SELECT charinfo FROM players WHERE citizenid = ? LIMIT 1', { identifier }); if row and row.charinfo then local ok, info = pcall(json.decode, row.charinfo); if ok and type(info) == 'table' then birthdate = tostring(info.birthdate or info.dateofbirth or info.dob or '') end end end
    for _, doc in ipairs(docs) do doc.birthdate = birthdate end
    local photoData
    if hasPhoto(identifier) then
        local bytes = LoadResourceFile(RESOURCE, ('photos/%s.jpg'):format(identifier))
        if bytes then
            local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
            local out = {}
            for i = 1, #bytes, 3 do
                local a,b,c = bytes:byte(i,i+2); local n=((a or 0)<<16)|((b or 0)<<8)|(c or 0)
                local x1=((n>>18)&63)+1; local x2=((n>>12)&63)+1; local x3=((n>>6)&63)+1; local x4=(n&63)+1
                out[#out+1]=chars:sub(x1,x1)..chars:sub(x2,x2)..(b and chars:sub(x3,x3) or '=')..(c and chars:sub(x4,x4) or '=')
            end
            photoData = 'data:image/jpeg;base64,' .. table.concat(out)
        end
    end
    TriggerClientEvent('universal_identity:myDocumentsData', src, { documents = docs, photo = photoData, preview = false })
end)

RegisterNetEvent('universal_identity:requestOwnServiceCard', function()
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if not player or not player.PlayerData or not player.PlayerData.citizenid then return end
    local identifier = player.PlayerData.citizenid
    pcall(function() syncEmployeeServiceCards(player) end)
    local doc = MySQL.single.await([[SELECT id, document_number, document_type, owner_name, organisation_key,
        rank_label, rank_level, status, created_at, issued_by_name, handed_over_at
        FROM ui_universal_documents
        WHERE owner_identifier = ? AND document_type = 'organisation_id'
          AND status IN ('pending_handover', 'processing', 'issued', 'collected_by_issuer')
        ORDER BY id DESC LIMIT 1]], { identifier })
    if not doc then
        notify(src, 'Du hast noch keinen gültigen Dienstausweis erhalten. Nutze /uidpreview für die reine Designvorschau.', 'error')
        return
    end
    local org = Config.Documents.Organisations[tostring(doc.organisation_key or '')]
    doc.organisation_label = org and org.label or tostring(doc.organisation_key or 'Organisation')
    local charinfo = player.PlayerData.charinfo or {}
    local birthdate = tostring(charinfo.birthdate or charinfo.dateofbirth or charinfo.dob or '')
    if birthdate == '' then
        local row = MySQL.single.await('SELECT charinfo FROM players WHERE citizenid = ? LIMIT 1', { identifier })
        if row and row.charinfo then
            local ok, info = pcall(json.decode, row.charinfo)
            if ok and type(info) == 'table' then birthdate = tostring(info.birthdate or info.dateofbirth or info.dob or '') end
        end
    end
    doc.birthdate = birthdate ~= '' and birthdate or '—'
    TriggerClientEvent('universal_identity:openShownDocument', src, {
        documents = { doc }, photo = photoDataUri(identifier), preview = false, presentation = true
    })
end)

RegisterNetEvent('universal_identity:requestOwnDocumentView', function(requestedType)
    local src = source
    local aliases = {
        personalausweis = 'personal_id', personal_id = 'personal_id',
        dienstausweis = 'organisation_id', organisation_id = 'organisation_id',
        waffenschein = 'weapon_permit', weapon_permit = 'weapon_permit',
        angelschein = 'fishing_license', fishing_license = 'fishing_license',
        bootsfuehrerschein = 'boat_license', boat_license = 'boat_license',
        pilotenschein = 'pilot_license', pilot_license = 'pilot_license'
    }
    local docType = aliases[tostring(requestedType or ''):lower()]
    if not docType then notify(src, 'Ungültiger Dokumenttyp.', 'error'); return end
    if not waitReady() then notify(src, 'Dokumentensystem ist noch nicht bereit.', 'error'); return end

    local player = QBCore.Functions.GetPlayer(src)
    local identifier = player and player.PlayerData and player.PlayerData.citizenid
    if not identifier then notify(src, 'Dein Charakter konnte nicht ermittelt werden.', 'error'); return end
    if docType == 'organisation_id' then pcall(function() syncEmployeeServiceCards(player) end) end

    local doc = MySQL.single.await([[SELECT id, document_number, document_type, owner_name,
        organisation_key, rank_label, rank_level, status, created_at, issued_by_name, handed_over_at
        FROM ui_universal_documents
        WHERE owner_identifier = ? AND document_type = ? AND status = 'issued'
        ORDER BY id DESC LIMIT 1]], { identifier, docType })
    if not doc then
        notify(src, 'Du besitzt kein gültiges Dokument dieses Typs. Prüfe deine Dokumentenmappe mit /uiddocuments.', 'error')
        return
    end

    if doc.document_type == 'organisation_id' then
        local org = Config.Documents.Organisations[tostring(doc.organisation_key or '')]
        doc.organisation_label = org and org.label or tostring(doc.organisation_key or 'Organisation')
    end
    local charinfo = player.PlayerData.charinfo or {}
    local birthdate = tostring(charinfo.birthdate or charinfo.dateofbirth or charinfo.dob or '')
    if birthdate == '' then
        local row = MySQL.single.await('SELECT charinfo FROM players WHERE citizenid = ? LIMIT 1', { identifier })
        if row and row.charinfo then
            local ok, decoded = pcall(json.decode, row.charinfo)
            if ok and type(decoded) == 'table' then birthdate = tostring(decoded.birthdate or decoded.dateofbirth or decoded.dob or '') end
        end
    end
    doc.birthdate = birthdate ~= '' and birthdate or '—'
    TriggerClientEvent('universal_identity:openShownDocument', src, {
        documents = { doc }, photo = photoDataUri(identifier), preview = false, presentation = true
    })
end)

RegisterNetEvent('universal_identity:requestCardPreview', function(onlyType)
    local src = source
    if not adminAllowed(src) then
        notify(src, 'Die Kartendesign-Vorschau ist nur für Serveradministratoren verfügbar.', 'error')
        return
    end
    local identifier = charId(src)
    local owner = playerName(src)
    local player = QBCore.Functions.GetPlayer(src)
    local charinfo = player and player.PlayerData and player.PlayerData.charinfo or {}
    local birthdate = tostring(charinfo.birthdate or charinfo.dateofbirth or charinfo.dob or '')
    if birthdate == '' and identifier then
        local row = MySQL.single.await('SELECT charinfo FROM players WHERE citizenid = ? LIMIT 1', { identifier })
        if row and row.charinfo then
            local ok, info = pcall(json.decode, row.charinfo)
            if ok and type(info) == 'table' then
                birthdate = tostring(info.birthdate or info.dateofbirth or info.dob or '')
            end
        end
    end
    if birthdate == '' then birthdate = '—' end
    local previewDocs = {
        { id = -1, document_number = 'PREVIEW-ID-0001', document_type = 'personal_id', owner_name = owner, birthdate = birthdate, status = 'issued', created_at = os.date('%Y-%m-%d %H:%M:%S'), issued_by_name = 'Vorschau / System' },
        { id = -2, document_number = 'PREVIEW-ORG-0002', document_type = 'organisation_id', owner_name = owner, birthdate = birthdate, organisation_key = 'Polizei', rank_label = 'Officer', status = 'issued', created_at = os.date('%Y-%m-%d %H:%M:%S'), issued_by_name = 'Vorschau / Polizeileitung' },
        { id = -3, document_number = 'PREVIEW-WP-0003', document_type = 'weapon_permit', owner_name = owner, birthdate = birthdate, status = 'issued', created_at = os.date('%Y-%m-%d %H:%M:%S'), issued_by_name = 'Vorschau / Verwaltung' },
        { id = -4, document_number = 'PREVIEW-FISH-0004', document_type = 'fishing_license', owner_name = owner, birthdate = birthdate, status = 'issued', created_at = os.date('%Y-%m-%d %H:%M:%S'), issued_by_name = 'Vorschau / Verwaltung' },
        { id = -5, document_number = 'PREVIEW-SEA-0005', document_type = 'boat_license', owner_name = owner, birthdate = birthdate, status = 'issued', created_at = os.date('%Y-%m-%d %H:%M:%S'), issued_by_name = 'Vorschau / Verwaltung' },
        { id = -6, document_number = 'PREVIEW-AIR-0006', document_type = 'pilot_license', owner_name = owner, birthdate = birthdate, status = 'issued', created_at = os.date('%Y-%m-%d %H:%M:%S'), issued_by_name = 'Vorschau / Verwaltung' }
    }

    if onlyType then
        local requested = tostring(onlyType):lower()
        local previewIndex = ({
            personal_id = 1, personalausweis = 1,
            organisation_id = 2, dienstausweis = 2,
            weapon_permit = 3, waffenschein = 3,
            fishing_license = 4, angelschein = 4,
            boat_license = 5, bootsfuehrerschein = 5,
            pilot_license = 6, pilotenschein = 6
        })[requested]
        previewDocs = previewIndex and { previewDocs[previewIndex] } or {}
    end

    local photoData
    if identifier and hasPhoto(identifier) then
        local bytes = LoadResourceFile(RESOURCE, ('photos/%s.jpg'):format(identifier))
        if bytes then
            local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
            local out = {}
            for i = 1, #bytes, 3 do
                local a,b,c = bytes:byte(i,i+2); local n=((a or 0)<<16)|((b or 0)<<8)|(c or 0)
                local x1=((n>>18)&63)+1; local x2=((n>>12)&63)+1; local x3=((n>>6)&63)+1; local x4=(n&63)+1
                out[#out+1]=chars:sub(x1,x1)..chars:sub(x2,x2)..(b and chars:sub(x3,x3) or '=')..(c and chars:sub(x4,x4) or '=')
            end
            photoData = 'data:image/jpeg;base64,' .. table.concat(out)
        end
    end

    TriggerClientEvent('universal_identity:openShownDocument', src, { documents = previewDocs, photo = photoData, preview = true, presentation = false })
end)

-- Polizeinotizen: nur echte Mitglieder der konfigurierten Organisation dürfen senden.
RegisterNetEvent('universal_identity:submitOrgNote', function(orgKey, enteredServerId, enteredName, noteText)
    local src = source
    local orgKeyString = tostring(orgKey or '')
    local org = Config.Documents.Organisations[orgKeyString]
    local player = QBCore.Functions.GetPlayer(src)
    if not org or not player or (player.PlayerData.job or {}).name ~= org.job or not hasValidConfiguredJobRank(src, orgKeyString) then
        TriggerClientEvent('universal_identity:orgNoteResult', src, { success = false, message = 'Nur aktive Mitglieder der Polizei dürfen Notizen senden.' })
        return
    end
    local realName = playerName(src)
    if tonumber(enteredServerId) ~= tonumber(src) then
        TriggerClientEvent('universal_identity:orgNoteResult', src, { success = false, message = 'Die Server-ID stimmt nicht mit deiner aktuellen Sitzung überein.' })
        return
    end
    noteText = tostring(noteText or ''):gsub('^%s*(.-)%s*$', '%1')
    if noteText == '' then
        TriggerClientEvent('universal_identity:orgNoteResult', src, { success = false, message = 'Bitte schreibe eine Notiz, bevor du sie sendest.' })
        return
    end
    if #noteText > 2000 then
        TriggerClientEvent('universal_identity:orgNoteResult', src, { success = false, message = 'Die Notiz darf höchstens 2000 Zeichen lang sein.' })
        return
    end
    local insertedId
    local ok, err = pcall(function()
        insertedId = MySQL.insert.await('INSERT INTO ui_org_notes (org_key, author_identifier, author_name, author_server_id, note_text) VALUES (?, ?, ?, ?, ?)', {
            orgKeyString, player.PlayerData.citizenid, realName, tonumber(src), noteText
        })
    end)
    if not ok then
        log(('Polizeinotiz konnte nicht gespeichert werden: %s'):format(tostring(err)))
        TriggerClientEvent('universal_identity:orgNoteResult', src, { success = false, message = 'Notiz konnte nicht gespeichert werden. Bitte Serverkonsole prüfen.' })
        return
    end
    TriggerClientEvent('universal_identity:orgNoteResult', src, { success = true, message = 'Deine Notiz wurde an die Administration übermittelt.' })
    local saved = MySQL.single.await('SELECT id, author_name, author_server_id, note_text, status, created_at FROM ui_org_notes WHERE id = ? LIMIT 1', { insertedId })
    if saved then
        for _, playerId in ipairs(GetPlayers()) do
            local adminSrc = tonumber(playerId)
            if adminSrc and adminAllowed(adminSrc) then
                TriggerClientEvent('universal_identity:adminOrgNoteAdded', adminSrc, saved)
            end
        end
    end
end)

-- =========================================================

-- Interne Polizeibekanntmachungen: Lesen für alle Mitglieder, Veröffentlichen nur Leitung/Stellvertretung.
local function getAnnouncementRows(orgKey)
    return MySQL.query.await('SELECT id,title,body,author_name,created_at FROM ui_org_announcements WHERE org_key = ? ORDER BY id DESC LIMIT 50', { orgKey }) or {}
end

local function getUnreadAnnouncementCount(orgKey, identifier)
    if not identifier then return 0 end
    local count = MySQL.scalar.await([[SELECT COUNT(*) FROM (
        SELECT id, org_key FROM ui_org_announcements WHERE org_key = ? ORDER BY id DESC LIMIT 50
    ) a LEFT JOIN ui_org_announcement_reads r
        ON r.org_key = a.org_key AND r.announcement_id = a.id AND r.identifier = ?
        WHERE r.announcement_id IS NULL]], { orgKey, identifier })
    return tonumber(count) or 0
end

local function sendAnnouncementsToPlayer(targetId, orgKey, rows, published)
    local target = QBCore.Functions.GetPlayer(targetId)
    if not target then return end
    local access = getOrgAccess(targetId, orgKey)
    if not access then return end
    local canPublish = hasOrgPermission(targetId, orgKey, 'publish_announcements', access.leader == true or access.deputy == true)
    local identifier = target.PlayerData and target.PlayerData.citizenid
    local unreadCount = getUnreadAnnouncementCount(orgKey, identifier)
    TriggerClientEvent('universal_identity:orgAnnouncementsData', targetId, rows, canPublish, published == true, unreadCount)
end

RegisterNetEvent('universal_identity:requestOrgAnnouncements', function(orgKey)
    local src = source; orgKey = tostring(orgKey or '')
    local access = getOrgAccess(src, orgKey)
    if not access then notify(src, 'Du hast keinen Zugriff auf diese Organisation.', 'error'); return end
    local rows = getAnnouncementRows(orgKey)
    sendAnnouncementsToPlayer(src, orgKey, rows, false)
end)

RegisterNetEvent('universal_identity:markOrgAnnouncementsRead', function(orgKey)
    local src = source; orgKey = tostring(orgKey or '')
    local access = getOrgAccess(src, orgKey)
    if not access then notify(src, 'Du hast keinen Zugriff auf diese Organisation.', 'error'); return end
    local identifier = charId(src)
    if not identifier then return end
    local ok, err = pcall(function()
        MySQL.query.await([[INSERT IGNORE INTO ui_org_announcement_reads (org_key, announcement_id, identifier)
            SELECT org_key, id, ? FROM ui_org_announcements WHERE org_key = ? ORDER BY id DESC LIMIT 50]], { identifier, orgKey })
    end)
    if not ok then
        log(('Lesestatus der Bekanntmachungen konnte nicht gespeichert werden: %s'):format(tostring(err)))
        notify(src, 'Lesestatus konnte nicht gespeichert werden. Bitte Serverkonsole prüfen.', 'error')
        return
    end
    sendAnnouncementsToPlayer(src, orgKey, getAnnouncementRows(orgKey), false)
end)

RegisterNetEvent('universal_identity:deleteOrgAnnouncement', function(orgKey, announcementId)
    local src = source
    orgKey = tostring(orgKey or '')
    announcementId = tonumber(announcementId)
    local access = getOrgAccess(src, orgKey)
    if not access or not hasOrgPermission(src, orgKey, 'delete_announcements', access.leader or access.deputy) then
        notifyOrgPermissionDenied(src, 'Du hast keine Berechtigung, Bekanntmachungen zu löschen.')
        TriggerClientEvent('universal_identity:orgAnnouncementDeleteResult', src, false, announcementId, 'Keine Berechtigung zum Löschen.')
        return
    end
    if not announcementId or announcementId < 1 then
        notify(src, 'Ungültige Bekanntmachung.', 'error')
        TriggerClientEvent('universal_identity:orgAnnouncementDeleteResult', src, false, announcementId, 'Ungültige Bekanntmachung.')
        return
    end

    -- Zuerst den eigentlichen Eintrag löschen. Keine SELECT-Abfrage und kein browserseitiges
    -- window.confirm: beide waren unnötige Fehlerquellen für die blockierende Tablet-Aktion.
    local ok, deletedOrError = pcall(function()
        return MySQL.update.await('DELETE FROM ui_org_announcements WHERE id = ? AND org_key = ?', { announcementId, orgKey })
    end)
    if not ok then
        log(('Bekanntmachung #%s konnte nicht gelöscht werden: %s'):format(tostring(announcementId), tostring(deletedOrError)))
        notify(src, 'Bekanntmachung konnte nicht gelöscht werden. Bitte Serverkonsole prüfen.', 'error')
        TriggerClientEvent('universal_identity:orgAnnouncementDeleteResult', src, false, announcementId, 'Datenbankfehler beim Löschen.')
        return
    end
    local affected = tonumber(deletedOrError) or 0
    if affected < 1 then
        notify(src, 'Bekanntmachung wurde nicht gefunden oder bereits gelöscht.', 'error')
        TriggerClientEvent('universal_identity:orgAnnouncementDeleteResult', src, false, announcementId, 'Bekanntmachung nicht gefunden.')
        return
    end

    -- Lesestatus bereinigen; ein Fehler hierbei darf das Tablet nicht blockieren.
    local readOk, readErr = pcall(function()
        MySQL.update.await('DELETE FROM ui_org_announcement_reads WHERE org_key = ? AND announcement_id = ?', { orgKey, announcementId })
    end)
    if not readOk then log(('Lesestatus für gelöschte Bekanntmachung #%s konnte nicht bereinigt werden: %s'):format(tostring(announcementId), tostring(readErr))) end

    local rowsOk, rows = pcall(getAnnouncementRows, orgKey)
    if not rowsOk then
        log(('Bekanntmachungen konnten nach dem Löschen nicht neu geladen werden: %s'):format(tostring(rows)))
        rows = {}
    end
    for _, playerId in ipairs(GetPlayers()) do
        local targetId = tonumber(playerId)
        local target = targetId and QBCore.Functions.GetPlayer(targetId)
        if target and (((target.PlayerData.job or {}).name == access.org.job)) then
            -- Direkt antworten, damit die Liste auch im Testzugriff neu aufgebaut wird.
            local targetAccess = getOrgAccess(targetId, orgKey)
            local canPublish = targetAccess and (targetAccess.leader == true or targetAccess.deputy == true) or false
            local identifier = target.PlayerData and target.PlayerData.citizenid
            local unreadCount = 0
            if identifier then
                local countOk, count = pcall(getUnreadAnnouncementCount, orgKey, identifier)
                if countOk then unreadCount = tonumber(count) or 0 end
            end
            TriggerClientEvent('universal_identity:orgAnnouncementsData', targetId, rows, canPublish, false, unreadCount)
        end
    end
    notify(src, 'Bekanntmachung erfolgreich gelöscht.', 'success')
    TriggerClientEvent('universal_identity:orgAnnouncementDeleteResult', src, true, announcementId, 'Bekanntmachung erfolgreich gelöscht.')
end)

RegisterNetEvent('universal_identity:publishOrgAnnouncement', function(orgKey, title, body)
    local src = source; orgKey = tostring(orgKey or '')
    local access = getOrgAccess(src, orgKey)
    if not access or not hasOrgPermission(src, orgKey, 'publish_announcements', access.leader or access.deputy) then
        notifyOrgPermissionDenied(src, 'Du hast keine Berechtigung, Bekanntmachungen zu veröffentlichen.')
        return
    end
    title = tostring(title or ''):gsub('[\r\n]', ' '):sub(1, 140)
    body = tostring(body or ''):sub(1, 3000)
    if title:gsub('%s', '') == '' or body:gsub('%s', '') == '' then notify(src, 'Bitte Überschrift und Text ausfüllen.', 'error'); return end
    local player = QBCore.Functions.GetPlayer(src)
    if not player then return end
    local authorIdentifier = tostring(player.PlayerData.citizenid or '')
    local authorDisplayName = tostring(playerName(src) or GetPlayerName(src) or 'Unbekannt')
    local params = { orgKey, title, body, authorIdentifier, authorDisplayName }
    local insertOk, insertResult = pcall(function()
        return MySQL.insert.await('INSERT INTO ui_org_announcements (org_key,title,body,author_identifier,author_name) VALUES (?, ?, ?, ?, ?)', params)
    end)
    if not insertOk or not insertResult then
        log(('Bekanntmachung konnte nicht gespeichert werden: %s'):format(tostring(insertResult or 'kein Insert-Ergebnis')))
        notify(src, 'Bekanntmachung konnte nicht gespeichert werden. Bitte Serverkonsole prüfen.', 'error')
        return
    end
    local rows = getAnnouncementRows(orgKey)
    for _, playerId in ipairs(GetPlayers()) do
        local targetId = tonumber(playerId)
        local target = targetId and QBCore.Functions.GetPlayer(targetId)
        if target and (target.PlayerData.job or {}).name == access.org.job then
            sendAnnouncementsToPlayer(targetId, orgKey, rows, targetId == src)
        end
    end
    notify(src, 'Interne Bekanntmachung veröffentlicht.', 'success')
end)

-- UNIVERSAL IDENTITY: ADMIN-TABLET UND STANDORTVERWALTUNG
-- =========================================================

local function adminFeedback(src, message, success)
    TriggerClientEvent(
        'universal_identity:adminTabletFeedback',
        src,
        tostring(message or ''),
        success == true
    )
end

local function adminPlayerAllowed(src)
    if src == 0 then return true end

    if not adminAllowed(src) then
        notifyOrgPermissionDenied(src, 'Du hast keine Berechtigung für diese Aktion.')
        return false
    end

    return true
end

local function getPlayerPosition(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end

    local coords = GetEntityCoords(ped)
    return {
        x = coords.x,
        y = coords.y,
        z = coords.z,
        heading = GetEntityHeading(ped)
    }
end

RegisterNetEvent('universal_identity:requestOrgPoliceMembers', function(orgKey)
    local src = source
    orgKey = tostring(orgKey or '')
    local access = getOrgAccess(src, orgKey)
    if not access or orgKey ~= 'police' or not hasOrgPermission(src, orgKey, 'view_employee', access.leader or access.deputy) then
        TriggerClientEvent('universal_identity:orgPoliceMembersData', src, {}, false, 'Du hast keine Berechtigung, Polizeimitglieder anzusehen. Bitte wende dich an deinen Vorgesetzten.')
        return
    end
    local org = Config.Documents.Organisations.police
    if not org then
        TriggerClientEvent('universal_identity:orgPoliceMembersData', src, {}, false, 'Die Polizeiorganisation ist nicht korrekt konfiguriert.')
        return
    end
    local members, seen, onlineByCitizen, liveByCitizen = {}, {}, {}, {}
    local hireDates = {}
    for _, hireRow in ipairs(MySQL.query.await('SELECT identifier, hired_at FROM ui_org_employment_dates WHERE org_key = ?', {'police'}) or {}) do
        hireDates[hireRow.identifier] = hireRow.hired_at
    end
    for _, playerId in ipairs(GetPlayers()) do
        local sid = tonumber(playerId); local player = sid and QBCore.Functions.GetPlayer(sid)
        if player and player.PlayerData and player.PlayerData.citizenid then
            onlineByCitizen[player.PlayerData.citizenid] = sid
            liveByCitizen[player.PlayerData.citizenid] = player
        end
    end
    local rows = MySQL.query.await("SELECT citizenid, charinfo, job FROM players WHERE JSON_VALID(job) AND JSON_UNQUOTE(JSON_EXTRACT(job, '$.name')) = ?", { org.job }) or {}
    for _, row in ipairs(rows) do
        local okJob, job = pcall(json.decode, row.job or '{}')
        if okJob and type(job) == 'table' and job.name == org.job and row.citizenid then
            local okChar, char = pcall(json.decode, row.charinfo or '{}'); if not okChar or type(char) ~= 'table' then char = {} end
            local live = liveByCitizen[row.citizenid]
            if live and live.PlayerData and live.PlayerData.job then job = live.PlayerData.job; char = live.PlayerData.charinfo or char end
            local grade = job.grade or {}; local rank = type(grade) == 'table' and (grade.name or grade.label or grade.level) or grade; local gradeLevel = tonumber(type(grade) == 'table' and grade.level or grade) or -1
            local sid = onlineByCitizen[row.citizenid]
            local fullName = ((char.firstname or '') .. ' ' .. (char.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
            if fullName == '' then fullName = row.citizenid end
            local hire = hireDates[row.citizenid]
            members[#members + 1] = { citizenid = row.citizenid, name = fullName, rank = tostring(rank or 'Unbekannt'), gradeLevel = gradeLevel, serverId = sid, online = sid ~= nil, hiredAt = hire, photo = photoDataUri(row.citizenid) }
            seen[row.citizenid] = true
        end
    end
    for _, playerId in ipairs(GetPlayers()) do
        local sid = tonumber(playerId); local player = sid and QBCore.Functions.GetPlayer(sid)
        if player and player.PlayerData and player.PlayerData.citizenid and (player.PlayerData.job or {}).name == org.job and not seen[player.PlayerData.citizenid] then
            local d = player.PlayerData; local grade = (d.job or {}).grade or {}; local gradeLevel = tonumber(type(grade) == 'table' and grade.level or grade) or -1; local hire = hireDates[d.citizenid]
            members[#members + 1] = { citizenid = d.citizenid, name = playerName(sid), rank = tostring(type(grade) == 'table' and (grade.name or grade.label or grade.level) or grade), gradeLevel = gradeLevel, serverId = sid, online = true, hiredAt = hire, photo = photoDataUri(d.citizenid) }
        end
    end
    table.sort(members, function(a, b) return tostring(a.name):lower() < tostring(b.name):lower() end)
    TriggerClientEvent('universal_identity:orgPoliceMembersData', src, members, true)
end)

local function sendAdminTabletData(src)
    if not adminPlayerAllowed(src) then return end

    if not waitReady() then
        adminFeedback(src, 'Das Dokumentensystem ist noch nicht bereit.', false)
        return
    end

    local result = {
        photo = {},
        pickup = {},
        pc = {},
        history = {},
        notes = {},
        policeMembers = {},
        permissionOrganizations = {}, permissionJobs = {}, permissionSettings = {}, systemSettings = { weaponPermitTabletFee = WeaponPermitTabletFee, policeTestMode = PoliceTestModeEnabled }
    }

    local ok, err = pcall(function()
        result.photo = MySQL.query.await(
            'SELECT id, name, x, y, z, heading FROM ui_photo_stations ORDER BY id DESC',
            {}
        ) or {}

        result.pickup = MySQL.query.await(
            "SELECT id, name, x, y, z, heading, station_type FROM ui_document_pickups WHERE station_type = 'personal' ORDER BY id DESC",
            {}
        ) or {}

        result.policePickup = MySQL.query.await(
            "SELECT id, name, x, y, z, heading, station_type FROM ui_document_pickups WHERE station_type = 'police' ORDER BY id DESC",
            {}
        ) or {}

        result.pc = MySQL.query.await(
            "SELECT id, org_key, name, x, y, z, heading FROM ui_org_pcs WHERE org_key = 'police' ORDER BY id DESC",
            {}
        ) or {}

        for orgKey, org in pairs(Config.Documents.Organisations or {}) do
            result.permissionOrganizations[#result.permissionOrganizations + 1] = { key = orgKey, label = tostring(org.label or orgKey), job = tostring(org.job or orgKey) }
            local job = (QBCore.Shared and QBCore.Shared.Jobs or {})[org.job]
            local grades = {}
            for key, gradeData in pairs((job and job.grades) or {}) do
                if type(gradeData) == 'table' then
                    local level = tonumber(gradeData.level) or tonumber(key)
                    if level then grades[#grades + 1] = { level = level, label = tostring(gradeData.name or gradeData.label or ('Rang ' .. level)) } end
                end
            end
            table.sort(grades, function(a,b) return a.level < b.level end)
            result.permissionJobs[orgKey] = { job = org.job, grades = grades }
        end
        result.permissionSettings = MySQL.query.await('SELECT org_key, grade_level, permissions, updated_by, updated_at FROM ui_org_rank_permissions', {}) or {}
        for _, setting in ipairs(result.permissionSettings) do
            local okPerm, decoded = pcall(json.decode, setting.permissions or '{}')
            setting.permissions = okPerm and type(decoded) == 'table' and decoded or {}
        end

        result.history = MySQL.query.await([[
            SELECT id, document_id, document_number, document_type,
                   owner_name, action, actor_name, target_name,
                   details, created_at
            FROM ui_document_audit
            ORDER BY id DESC
            LIMIT 50
        ]], {}) or {}
        result.notes = MySQL.query.await([[
            SELECT id, author_name, author_server_id, note_text, status, created_at
            FROM ui_org_notes
            WHERE org_key = 'police'
            ORDER BY id DESC
            LIMIT 100
        ]], {}) or {}
        -- Vollständige Polizeiliste aus QBCore-Spielerdaten (online und offline).
        local org = Config.Documents.Organisations.police
        if org then
            local hireDates = {}
            for _, hireRow in ipairs(MySQL.query.await('SELECT identifier, hired_at FROM ui_org_employment_dates WHERE org_key = ?', {'police'}) or {}) do
                hireDates[hireRow.identifier] = hireRow.hired_at
            end
            local onlineByCitizen, livePlayerByCitizen = {}, {}
            for _, playerId in ipairs(GetPlayers()) do
                local sid = tonumber(playerId); local member = sid and QBCore.Functions.GetPlayer(sid)
                if member and member.PlayerData.citizenid then
                    onlineByCitizen[member.PlayerData.citizenid] = sid
                    livePlayerByCitizen[member.PlayerData.citizenid] = member
                end
            end
            local rows = MySQL.query.await("SELECT citizenid, charinfo, job FROM players WHERE JSON_VALID(job) AND JSON_UNQUOTE(JSON_EXTRACT(job, '$.name')) = ?", { org.job }) or {}
            local seen = {}
            for _, row in ipairs(rows) do
                local okJob, job = pcall(json.decode, row.job or '{}')
                if okJob and type(job) == 'table' and job.name == org.job and row.citizenid then
                    local okChar, char = pcall(json.decode, row.charinfo or '{}'); if not okChar or type(char) ~= 'table' then char = {} end
                    local sid = onlineByCitizen[row.citizenid]
                    -- Online-Ränge immer aus QBCore PlayerData lesen; players.job kann bis zum Speichern veraltet sein.
                    local live = livePlayerByCitizen[row.citizenid]
                    if live and live.PlayerData and live.PlayerData.job then job = live.PlayerData.job end
                    local grade = job.grade or {}; local rank = type(grade) == 'table' and (grade.name or grade.label or grade.level) or grade; local gradeLevel = tonumber(type(grade) == 'table' and grade.level or grade) or -1
                    local hire = hireDates[row.citizenid]
                    -- Inline-Bilddaten umgehen NUI-Resource-URL-/Dateizugriffsprobleme im Admin-Tablet.
                    local photo = photoDataUri(row.citizenid)
                    local fullName = ((char.firstname or '') .. ' ' .. (char.lastname or '')):gsub('^%s*(.-)%s*$', '%1')
                    if fullName == '' then fullName = row.citizenid end
                    result.policeMembers[#result.policeMembers + 1] = { citizenid = row.citizenid, name = fullName, rank = tostring(rank or 'Unbekannt'), gradeLevel = gradeLevel, serverId = sid, online = sid ~= nil, hiredAt = hire, photo = photo }
                    seen[row.citizenid] = true
                end
            end
            -- Include current online police even if a server uses a custom players table layout.
            for _, playerId in ipairs(GetPlayers()) do
                local sid=tonumber(playerId); local member=sid and QBCore.Functions.GetPlayer(sid)
                if member and (member.PlayerData.job or {}).name == org.job and not seen[member.PlayerData.citizenid] then
                    local d=member.PlayerData; local g=(d.job or {}).grade or {}; local gradeLevel=tonumber(type(g)=='table' and g.level or g) or -1; local h=hireDates[d.citizenid]
                    local photo = photoDataUri(d.citizenid)
                    result.policeMembers[#result.policeMembers+1]={citizenid=d.citizenid,name=playerName(sid),rank=tostring(type(g)=='table' and (g.name or g.label or g.level) or g),gradeLevel=gradeLevel,serverId=sid,online=true,hiredAt=h,photo=photo}
                end
            end
            table.sort(result.policeMembers, function(a,b) return a.name:lower() < b.name:lower() end)
        end
    end)

    if not ok then
        log(('Admin-Tablet-Daten konnten nicht geladen werden: %s'):format(tostring(err)))
        adminFeedback(src, 'Fehler beim Laden der Tablet-Daten. Serverkonsole prüfen.', false)
        return
    end

    TriggerClientEvent('universal_identity:adminTabletData', src, result)
end

-- Admin-Tablet öffnen und Daten laden
RegisterCommand('uidadmin', function(src)
    if src == 0 then
        log('/uidadmin muss im Spiel ausgeführt werden.')
        return
    end

    if not adminPlayerAllowed(src) then return end

    log(('/uidadmin aufgerufen von Spieler %s'):format(src))
    TriggerClientEvent('universal_identity:openAdminTablet', src)
end, false)

RegisterNetEvent('universal_identity:adminTabletRequest', function()
    local src = source
    if not adminPlayerAllowed(src) then return end
    sendAdminTabletData(src)
end)

RegisterNetEvent('universal_identity:requestOpenAdminTablet', function()
    local src = source
    if not adminPlayerAllowed(src) then
        adminFeedback(src, 'Zugriff verweigert: Nur Serveradministratoren dürfen die Organisationsverwaltung öffnen.', false)
        return
    end
    TriggerClientEvent('universal_identity:openAdminTablet', src)
end)

local function adminIsWithinOneMeterOfLocation(src, tableName, id)
    if src == 0 then return true end
    local allowedTables = { ui_photo_stations = true, ui_document_pickups = true, ui_org_pcs = true }
    if not allowedTables[tableName] then return false end
    local row = MySQL.single.await(('SELECT x, y, z FROM `%s` WHERE id = ? LIMIT 1'):format(tableName), { id })
    if not row then return false, 'Kein Standort mit dieser ID gefunden.' end
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return false, 'Spielerposition konnte nicht gelesen werden.' end
    local coords = GetEntityCoords(ped)
    local pos = vector3(tonumber(row.x) or 0, tonumber(row.y) or 0, tonumber(row.z) or 0)
    if #(coords - pos) > 1.0 then return false, 'Zum Löschen musst du dich innerhalb von 1 Meter genau an diesem Standort befinden.' end
    return true
end

-- Standortaktionen aus der NUI
RegisterNetEvent('universal_identity:adminTabletAction', function(data)
    local src = source
    data = type(data) == 'table' and data or {}

    if not adminPlayerAllowed(src) then return end
    if not waitReady() then
        adminFeedback(src, 'Das Dokumentensystem ist noch nicht bereit.', false)
        return
    end

    local action = tostring(data.action or '')
    local name = tostring(data.name or '')
    local orgKey = tostring(data.orgKey or '')
    if action == 'create-pc' and orgKey ~= 'police' then
        adminFeedback(src, 'In dieser Version werden nur Polizei-Organisations-PCs unterstützt.', false)
        return
    end
    local id = tonumber(data.id)

    if action == 'refresh' then
        sendAdminTabletData(src)
        adminFeedback(src, 'Daten aktualisiert.', true)
        return
    end

    if action == 'save-rank-permissions' then
        local selectedOrg = tostring(data.orgKey or '')
        local gradeLevel = tonumber(data.gradeLevel)
        local org = Config.Documents.Organisations[selectedOrg]
        if not org or not gradeLevel or (gradeLevel < 0 and gradeLevel ~= -1) or gradeLevel % 1 ~= 0 then
            adminFeedback(src, 'Ungültige Organisation oder Rangstufe.', false); return
        end
        local job = (QBCore.Shared and QBCore.Shared.Jobs or {})[org.job]
        local validGrade = gradeLevel == -1 -- reservierte Sonderrolle: Stellvertretung
        if not validGrade then
            for key, gradeData in pairs((job and job.grades) or {}) do
                local level = type(gradeData) == 'table' and (tonumber(gradeData.level) or tonumber(key)) or tonumber(key)
                if level == gradeLevel then validGrade = true; break end
            end
        end
        if not validGrade then adminFeedback(src, 'Dieser Rang ist nicht in QBCore.Shared.Jobs vorhanden.', false); return end
        local incoming = type(data.permissions) == 'table' and data.permissions or {}
        local safePermissions = {}
        for permissionKey in pairs(VALID_ORG_PERMISSIONS) do safePermissions[permissionKey] = incoming[permissionKey] == true end
        local encoded = json.encode(safePermissions)
        local okSave, saveErr = pcall(function()
            MySQL.insert.await('INSERT INTO ui_org_rank_permissions (org_key, grade_level, permissions, updated_by) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE permissions = VALUES(permissions), updated_by = VALUES(updated_by), updated_at = CURRENT_TIMESTAMP', { selectedOrg, gradeLevel, encoded, charId(src) or ('server:' .. tostring(src)) })
        end)
        if not okSave then
            log(('Rangberechtigungen konnten nicht gespeichert werden: %s'):format(tostring(saveErr)))
            adminFeedback(src, 'Speichern fehlgeschlagen. Bitte Datenbank und Serverkonsole prüfen.', false); return
        end
        adminFeedback(src, ('Berechtigungen für %s – Rang %s gespeichert.'):format(org.label or selectedOrg, gradeLevel), true)
        sendAdminTabletData(src)
        return
    end

    if action == 'save-police-test-mode' then
        local enabled = data.enabled == true
        local okSave, saveErr = pcall(function()
            MySQL.insert.await('INSERT INTO ui_system_settings (setting_key, setting_value, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by), updated_at = CURRENT_TIMESTAMP',
                { 'police_test_mode', enabled and '1' or '0', charId(src) or ('server:' .. tostring(src)) })
        end)
        if not okSave then
            log(('Polizei-Testmodus konnte nicht gespeichert werden: %s'):format(tostring(saveErr)))
            adminFeedback(src, 'Testmodus konnte nicht gespeichert werden. Serverkonsole prüfen.', false); return
        end
        PoliceTestModeEnabled = enabled
        PoliceFreelancerTestAccessEnabled = false
        TriggerClientEvent('universal_identity:policeTestModeState', -1, PoliceTestModeEnabled == true, PoliceFreelancerTestAccessEnabled == true)
        adminFeedback(src, enabled and 'Polizei-Testmodus aktiviert. Ausschließlich Serveradmins dürfen eigene Dokumente testen.' or 'Polizei-Testmodus deaktiviert. Es gelten reguläre Job- und Rangrechte.', true)
        sendAdminTabletData(src)
        return
    end

    if action == 'save-police-freelancer-test-access' then
        PoliceFreelancerTestAccessEnabled = false
        adminFeedback(src, 'Die Freelancer-Testrolle ist in Version 1.0.0 nicht verfügbar.', false)
        sendAdminTabletData(src)
        return
    end

    if action == 'save-weapon-permit-fee' then
        local fee = tonumber(data.amount)
        if not fee or fee < 0 or fee > 1000000 or fee % 1 ~= 0 then
            adminFeedback(src, 'Bitte einen ganzen Betrag zwischen 0 und 1.000.000 $ eingeben.', false); return
        end
        local okSave, saveErr = pcall(function()
            MySQL.insert.await('INSERT INTO ui_system_settings (setting_key, setting_value, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by), updated_at = CURRENT_TIMESTAMP',
                { 'weapon_permit_tablet_fee', tostring(fee), charId(src) or ('server:' .. tostring(src)) })
        end)
        if not okSave then
            log(('Waffenscheingebühr konnte nicht gespeichert werden: %s'):format(tostring(saveErr)))
            adminFeedback(src, 'Gebühr konnte nicht gespeichert werden. Serverkonsole prüfen.', false); return
        end
        WeaponPermitTabletFee = fee
        adminFeedback(src, ('Neue Waffenscheingebühr gespeichert: $%s.'):format(fee), true)
        sendAdminTabletData(src)
        return
    end

    if action == 'note-accept' or action == 'note-delete' then
        if not id or id < 1 or id % 1 ~= 0 then adminFeedback(src, 'Ungültige Notiz-ID.', false); return end
        if action == 'note-accept' then
            local changed = MySQL.update.await("UPDATE ui_org_notes SET status = 'accepted' WHERE id = ? AND org_key = 'police'", { id })
            if not changed or changed < 1 then adminFeedback(src, 'Notiz nicht gefunden oder bereits entfernt.', false); return end
            adminFeedback(src, 'Notiz als akzeptiert markiert.', true)
        else
            local changed = MySQL.update.await("DELETE FROM ui_org_notes WHERE id = ? AND org_key = 'police'", { id })
            if not changed or changed < 1 then adminFeedback(src, 'Notiz nicht gefunden.', false); return end
            adminFeedback(src, 'Notiz gelöscht.', true)
        end
        sendAdminTabletData(src)
        return
    end


    -- Alle neuen Standorte verwenden die aktuelle Spielerposition.
    if action == 'create-photo'
        or action == 'create-pickup'
        or action == 'create-police-pickup'
        or action == 'create-pc' then

        local pos = getPlayerPosition(src)
        if not pos then
            adminFeedback(src, 'Spielerposition konnte nicht gelesen werden.', false)
            return
        end

        if name == '' then
            if action == 'create-photo' then
                name = 'Fotostation'
            elseif action == 'create-pickup' then
                name = 'Personalausweis Abholstation'
            elseif action == 'create-police-pickup' then
                name = 'Polizei-Ausgabestelle'
            else
                name = 'Organisations-PC'
            end
        end

        if #name > 100 then name = name:sub(1, 100) end

        local ok, insertId = pcall(function()
            if action == 'create-photo' then
                return MySQL.insert.await([[
                    INSERT INTO ui_photo_stations
                        (name, x, y, z, heading)
                    VALUES (?, ?, ?, ?, ?)
                ]], { name, pos.x, pos.y, pos.z, pos.heading })

            elseif action == 'create-pickup' or action == 'create-police-pickup' then
                local stationType = action == 'create-pickup' and 'personal' or 'police'
                return MySQL.insert.await([[
                    INSERT INTO ui_document_pickups
                        (name, x, y, z, heading, station_type)
                    VALUES (?, ?, ?, ?, ?, ?)
                ]], { name, pos.x, pos.y, pos.z, pos.heading, stationType })

            else
                local org = Config.Documents.Organisations[orgKey]
                if not org then
                    error('Unbekannter Organisationsschlüssel: ' .. orgKey)
                end

                return MySQL.insert.await([[
                    INSERT INTO ui_org_pcs
                        (org_key, name, x, y, z, heading)
                    VALUES (?, ?, ?, ?, ?, ?)
                ]], {
                    orgKey, name,
                    pos.x, pos.y, pos.z, pos.heading
                })
            end
        end)

        if not ok or not insertId then
            log(('Admin-Standort konnte nicht erstellt werden: %s'):format(tostring(insertId)))
            adminFeedback(src, 'Standort konnte nicht gespeichert werden. Serverkonsole prüfen.', false)
            return
        end

        loadLocations()
        if action == 'create-photo' then TriggerEvent('universal_identity:refreshPhotoStationsInternal') end

        local label = action == 'create-photo' and 'Fotostation'
            or action == 'create-pickup' and 'Personalausweis-Abholstation'
            or action == 'create-police-pickup' and 'Polizei-Ausgabestelle'
            or 'Organisations-PC'

        adminFeedback(src, label .. ' erstellt.', true)
        sendAdminTabletData(src)
        return
    end

    -- Standort löschen
    if action == 'delete-photo'
        or action == 'delete-pickup'
        or action == 'delete-police-pickup'
        or action == 'delete-pc' then

        if not id or id < 1 or id % 1 ~= 0 then
            adminFeedback(src, 'Ungültige Standort-ID.', false)
            return
        end

        local tableName
        if action == 'delete-photo' then
            tableName = 'ui_photo_stations'
        elseif action == 'delete-pickup' or action == 'delete-police-pickup' then
            tableName = 'ui_document_pickups'
        else
            tableName = 'ui_org_pcs'
        end

        -- Sicherheitsprüfung: Löschen ist nur innerhalb von 1 m zum ausgewählten Standort erlaubt.
        local near, nearError = adminIsWithinOneMeterOfLocation(src, tableName, id)
        if near and action == 'delete-pickup' then near = (MySQL.scalar.await('SELECT station_type FROM ui_document_pickups WHERE id = ?', { id }) == 'personal') end
        if near and action == 'delete-police-pickup' then near = (MySQL.scalar.await('SELECT station_type FROM ui_document_pickups WHERE id = ?', { id }) == 'police') end
        if not near then adminFeedback(src, nearError or 'Du bist zu weit vom Standort entfernt.', false); return end

        -- Tabellenname kommt ausschließlich aus der festen Auswahl oben.
        local ok, affected = pcall(function()
            return MySQL.update.await(
                ('DELETE FROM `%s` WHERE id = ?'):format(tableName),
                { id }
            )
        end)

        if not ok then
            log(('Standort %s konnte nicht gelöscht werden: %s'):format(
                tostring(id), tostring(affected)
            ))
            adminFeedback(src, 'Löschen fehlgeschlagen. Serverkonsole prüfen.', false)
            return
        end

        if not affected or affected < 1 then
            adminFeedback(src, 'Kein Standort mit dieser ID gefunden.', false)
            return
        end

        loadLocations()
        if action == 'delete-photo' then TriggerEvent('universal_identity:refreshPhotoStationsInternal') end
        adminFeedback(src, 'Standort ' .. tostring(id) .. ' gelöscht.', true)
        sendAdminTabletData(src)
        return
    end

    adminFeedback(src, 'Unbekannte Admin-Aktion: ' .. action, false)
end)

-- =========================================================
-- ADMIN-BEFEHLE FÜR STANDORTE
-- =========================================================

RegisterCommand('setidpickup', function(src, args)
    if src == 0 then
        log('/setidpickup muss im Spiel ausgeführt werden.')
        return
    end

    if not adminPlayerAllowed(src) then return end

    local pos = getPlayerPosition(src)
    if not pos then return end

    local name = table.concat(args or {}, ' ')
    if name == '' then name = 'Ausweis-Ausgabe' end
    if #name > 100 then name = name:sub(1, 100) end

    local ok, result = pcall(function()
        return MySQL.insert.await([[
            INSERT INTO ui_document_pickups (name, x, y, z, heading, station_type)
            VALUES (?, ?, ?, ?, ?, 'personal')
        ]], { name, pos.x, pos.y, pos.z, pos.heading })
    end)

    if not ok or not result then
        log(('Ausgabestelle konnte nicht erstellt werden: %s'):format(tostring(result)))
        notify(src, 'Ausgabestelle konnte nicht gespeichert werden.', 'error')
        return
    end

    loadLocations()
    notify(src, 'Personalausweis-Abholstation erstellt.', 'success')
end, false)

RegisterCommand('setorgpc', function(src, args)
    if src == 0 then
        log('/setorgpc muss im Spiel ausgeführt werden.')
        return
    end

    if not adminPlayerAllowed(src) then return end

    local orgKey = tostring(args and args[1] or '')
    local org = Config.Documents.Organisations[orgKey]

    if not org then
        notify(src, 'Unbekannter Organisationsschlüssel. Prüfe Config.Documents.Organisations.', 'error')
        return
    end

    local pos = getPlayerPosition(src)
    if not pos then return end

    local name = table.concat(args or {}, ' ', 2)
    if name == '' then name = 'Organisations-PC' end
    if #name > 100 then name = name:sub(1, 100) end

    local ok, result = pcall(function()
        return MySQL.insert.await([[
            INSERT INTO ui_org_pcs (org_key, name, x, y, z, heading)
            VALUES (?, ?, ?, ?, ?, ?)
        ]], { orgKey, name, pos.x, pos.y, pos.z, pos.heading })
    end)

    if not ok or not result then
        log(('Organisations-PC konnte nicht erstellt werden: %s'):format(tostring(result)))
        notify(src, 'Organisations-PC konnte nicht gespeichert werden.', 'error')
        return
    end

    loadLocations()
    notify(src, 'Organisations-PC erstellt.', 'success')
end, false)

RegisterCommand('uidlocations', function(src)
    if not adminPlayerAllowed(src) then return end
    if not waitReady() then
        if src > 0 then notify(src, 'Dokumentensystem ist noch nicht bereit.', 'error') end
        return
    end

    local ok, result = pcall(function()
        return {
            photos = MySQL.query.await(
                'SELECT id, name, x, y, z FROM ui_photo_stations ORDER BY id', {}
            ) or {},
            pickups = MySQL.query.await(
                'SELECT id, name, x, y, z FROM ui_document_pickups ORDER BY id', {}
            ) or {},
            pcs = MySQL.query.await(
                'SELECT id, org_key, name, x, y, z FROM ui_org_pcs ORDER BY id', {}
            ) or {}
        }
    end)

    if not ok then
        log(('Standortliste konnte nicht geladen werden: %s'):format(tostring(result)))
        return
    end

    local function printRows(title, rows)
        log('--- ' .. title .. ' ---')
        for _, row in ipairs(rows) do
            log(('%s | %s | %.2f, %.2f, %.2f'):format(
                tostring(row.id),
                tostring(row.name or row.org_key or 'Standort'),
                tonumber(row.x) or 0,
                tonumber(row.y) or 0,
                tonumber(row.z) or 0
            ))
        end
    end

    printRows('Fotostationen', result.photos)
    printRows('Personalausweis-Ausgabestellen', result.pickups)
    printRows('Organisations-PCs', result.pcs)

    if src > 0 then
        notify(src, 'Standortliste wurde in der Serverkonsole ausgegeben.', 'success')
    end
end, false)

RegisterCommand('uiddeletelocation', function(src, args)
    if not adminPlayerAllowed(src) then return end

    local kind = tostring(args and args[1] or ''):lower()
    local id = tonumber(args and args[2])

    local tables = {
        photo = 'ui_photo_stations',
        pickup = 'ui_document_pickups',
        pc = 'ui_org_pcs'
    }

    local tableName = tables[kind]
    if not tableName or not id or id < 1 or id % 1 ~= 0 then
        local message = 'Verwendung: /uiddeletelocation photo|pickup|pc ID'
        if src > 0 then notify(src, message, 'error') else log(message) end
        return
    end

    local near, nearError = adminIsWithinOneMeterOfLocation(src, tableName, id)
    if not near then
        if src > 0 then notify(src, nearError or 'Du bist zu weit vom Standort entfernt.', 'error') else log(nearError or 'Standort nicht in Reichweite.') end
        return
    end

    local ok, affected = pcall(function()
        return MySQL.update.await(
            ('DELETE FROM `%s` WHERE id = ?'):format(tableName),
            { id }
        )
    end)

    if not ok then
        log(('Standort konnte nicht gelöscht werden: %s'):format(tostring(affected)))
        if src > 0 then notify(src, 'Löschen fehlgeschlagen. Serverkonsole prüfen.', 'error') end
        return
    end

    if not affected or affected < 1 then
        if src > 0 then notify(src, 'Standort-ID nicht gefunden.', 'error') end
        return
    end

    loadLocations()

    if src > 0 then
        notify(src, ('Standort %s (%s) gelöscht.'):format(kind, id), 'success')
    else
        log(('Standort %s (%s) gelöscht.'):format(kind, id))
    end
end, false)

print('^2[Universal Identity DEBUG] Admin-Tablet und Standortbefehle registriert.^7')


-- Entwickler-Testbefehl: löscht ausschließlich die Dokumente des eigenen Charakters
-- sowie passende Dokument-Items aus dem eigenen QBCore-Inventar. Das Charakterfoto bleibt erhalten.
RegisterCommand('uidresetmydocs', function(src)
    if src == 0 then
        print('[Universal Identity] /uidresetmydocs muss von einem eingeloggten Admin-Charakter ausgeführt werden.')
        return
    end
    if not adminAllowed(src) then
        log(('/uidresetmydocs verweigert: Spieler %s (%s) ist kein Serveradmin.'):format(tostring(src), tostring(GetPlayerName(src) or 'unbekannt')))
        notify(src, 'Zugriff verweigert: Dieser Befehl ist ausschließlich Serveradministratoren vorbehalten.', 'error')
        return
    end
    local player = QBCore.Functions.GetPlayer(src)
    local identifier = player and player.PlayerData and player.PlayerData.citizenid
    if not identifier then
        notify(src, 'Dein Charakter konnte nicht ermittelt werden.', 'error')
        return
    end
    if not waitReady() then
        notify(src, 'Das Dokumentensystem ist noch nicht bereit.', 'error')
        return
    end

    local ok, result = pcall(function()
        local rows = MySQL.query.await('SELECT id FROM ui_universal_documents WHERE owner_identifier = ?', { identifier }) or {}
        for _, row in ipairs(rows) do
            MySQL.update.await('DELETE FROM ui_document_audit WHERE document_id = ?', { row.id })
        end
        local deleted = MySQL.update.await('DELETE FROM ui_universal_documents WHERE owner_identifier = ?', { identifier }) or 0

        local itemNames = {
            [Config.Documents.PersonalIdItem or 'universal_personal_id'] = true,
            [Config.Documents.OrganisationIdItem or 'universal_org_id'] = true,
            universal_personal_id = true,
            universal_org_id = true
        }
        for _, docType in pairs(Config.Documents.OtherTypes or {}) do
            if type(docType) == 'table' and type(docType.item) == 'string' and docType.item ~= '' then
                itemNames[docType.item] = true
            end
        end
        local slots = {}
        for slot, item in pairs(player.PlayerData.items or {}) do
            if item and itemNames[item.name] then
                slots[#slots + 1] = { name = item.name, slot = item.slot or slot, amount = tonumber(item.amount) or 1 }
            end
        end
        local removedItems = 0
        for _, item in ipairs(slots) do
            local removed = player.Functions.RemoveItem(item.name, item.amount, item.slot)
            if removed then removedItems = removedItems + item.amount end
        end
        return { documents = tonumber(deleted) or #rows, items = removedItems }
    end)

    if not ok then
        log(('Reset eigener Dokumente fehlgeschlagen (%s): %s'):format(tostring(identifier), tostring(result)))
        notify(src, 'Zurücksetzen fehlgeschlagen. Bitte Serverkonsole prüfen.', 'error')
        return
    end
    notify(src, ('Test-Reset abgeschlossen: %s Dokumentdatensätze und %s Inventar-Items entfernt. Dein Foto bleibt erhalten. Nimm am besten an der Fotostation ein neues Foto auf, um den Personalausweis neu zu erstellen.'):format(result.documents, result.items), 'success')
    log(('Test-Reset eigener Dokumente für %s: %s Datensätze, %s Items.'):format(tostring(identifier), result.documents, result.items))
end, false)
