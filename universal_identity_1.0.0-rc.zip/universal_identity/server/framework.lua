Bridge = Bridge or {}
Bridge.Framework = nil
Bridge.Ready = false

CreateThread(function()
    for attempt = 1, 30 do
        if GetResourceState('qb-core') == 'started'
            and type(Bridge.GetIdentifier) == 'function' then
            Bridge.Framework = 'qbcore'
            Bridge.Ready = true
            print('[Universal Photos] QBCore bridge ready.')
            return
        end

        Wait(1000)
    end

    print('[Universal Photos] ERROR: QBCore bridge did not become ready. Check qb-core start order.')
end)
