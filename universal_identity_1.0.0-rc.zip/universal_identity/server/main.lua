-- Database bootstrap. No manual SQL import is required.
PhotoSystemDatabaseReady = false

local QBCore = exports['qb-core']:GetCoreObject()

local function isServerAdmin(src)
    if src == 0 then return true end
    if IsPlayerAceAllowed(src, Config.AdminAcePermission or 'universal_identity.admin') or IsPlayerAceAllowed(src, 'group.admin') then return true end
    for _, permission in ipairs({ 'god', 'admin' }) do
        local ok, allowed = pcall(function() return QBCore.Functions.HasPermission(src, permission) end)
        if ok and allowed then return true end
    end
    return false
end

CreateThread(function()
    local ok, err = pcall(function()
        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS `ui_character_photos` (
                `identifier` VARCHAR(100) NOT NULL,
                `photo_path` VARCHAR(255) NOT NULL,
                `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                    ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`identifier`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ]])

        MySQL.query.await([[
            CREATE TABLE IF NOT EXISTS `ui_photo_stations` (
                `id` INT NOT NULL AUTO_INCREMENT,
                `name` VARCHAR(100) NOT NULL DEFAULT 'Fotostation',
                `x` DOUBLE NOT NULL,
                `y` DOUBLE NOT NULL,
                `z` DOUBLE NOT NULL,
                `heading` DOUBLE NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ]])
    end)

    if not ok then
        print(('[Universal Photos] ERROR creating database tables: %s'):format(tostring(err)))
        return
    end

    PhotoSystemDatabaseReady = true
    print('[Universal Photos] Database ready (ui_character_photos, ui_photo_stations).')
end)

RegisterNetEvent('universal_identity:requestPhotoStatus', function()
    local playerId = source
    if not isServerAdmin(playerId) then
        TriggerClientEvent('universal_identity:stationCommandResult', playerId, 'Keine Berechtigung. Dieser Befehl ist nur für Serveradmins.')
        return
    end
    local message

    if not Bridge or not Bridge.Ready then
        message = 'QBCore-Bridge ist noch nicht bereit.'
    elseif not PhotoSystemDatabaseReady then
        message = 'Datenbank wird noch eingerichtet oder ist nicht erreichbar.'
    else
        message = 'Fotosystem bereit: QBCore-Bridge und Datenbank sind aktiv.'
    end

    TriggerClientEvent('universal_identity:stationCommandResult', playerId, message)
end)

print('[Universal Photos] Server bootstrap loaded.')
