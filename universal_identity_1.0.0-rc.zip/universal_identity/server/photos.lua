local RESOURCE_NAME = GetCurrentResourceName()
local BASE64_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'

local lastSaveAt = {}

local function Log(message)
    print(('[Universal Photos] %s'):format(message))
end

local function NotifySaveResult(source, success, message)
    TriggerClientEvent('universal_identity:photoSaveResult', source, success, message)
end

local function ValidateIdentifier(identifier)
    if type(identifier) ~= 'string' or identifier == '' or #identifier > 100 then
        return nil
    end

    -- Reject unsafe identifiers instead of silently changing them (avoids collisions).
    if identifier:find('[^%w_-]') then
        return nil
    end

    return identifier
end

local function DecodeBase64(input)
    if type(input) ~= 'string' or input == '' or #input % 4 ~= 0 then
        return nil
    end
    if input:find('[^A-Za-z0-9+/=]') then
        return nil
    end
    if input:find('=') and not input:match('^[A-Za-z0-9+/]*=?=?$') then
        return nil
    end

    local output, buffer, bits = {}, 0, 0
    for i = 1, #input do
        local char = input:sub(i, i)
        if char == '=' then break end

        local value = BASE64_CHARS:find(char, 1, true)
        if not value then return nil end

        buffer = (buffer << 6) | (value - 1)
        bits = bits + 6

        if bits >= 8 then
            bits = bits - 8
            output[#output + 1] = string.char((buffer >> bits) & 0xFF)
            buffer = buffer & ((1 << bits) - 1)
        end
    end

    return table.concat(output)
end

local function EncodeBase64(input)
    local output = {}

    for i = 1, #input, 3 do
        local a, b, c = input:byte(i, i + 2)
        local n = ((a or 0) << 16) | ((b or 0) << 8) | (c or 0)

        local c1 = ((n >> 18) & 63) + 1
        local c2 = ((n >> 12) & 63) + 1
        local c3 = ((n >> 6) & 63) + 1
        local c4 = (n & 63) + 1

        output[#output + 1] =
            BASE64_CHARS:sub(c1, c1)
            .. BASE64_CHARS:sub(c2, c2)
            .. (b and BASE64_CHARS:sub(c3, c3) or '=')
            .. (c and BASE64_CHARS:sub(c4, c4) or '=')
    end

    return table.concat(output)
end

local function GetPlayerIdentifier(source)
    if not Bridge or not Bridge.Ready or type(Bridge.GetIdentifier) ~= 'function' then
        return nil
    end

    return ValidateIdentifier(Bridge.GetIdentifier(source))
end

local function WaitForDatabase()
    local attempts = 0
    while not PhotoSystemDatabaseReady and attempts < 100 do
        Wait(100)
        attempts = attempts + 1
    end
    return PhotoSystemDatabaseReady == true
end

local function LoadPhotoData(identifier, callback)
    identifier = ValidateIdentifier(identifier)
    if not identifier then
        callback(nil, nil)
        return
    end

    CreateThread(function()
        if not WaitForDatabase() then
            Log('Photo request refused: database is not ready.')
            callback(nil, nil)
            return
        end

        local ok, row = pcall(function()
            return MySQL.single.await(
                'SELECT photo_path FROM ui_character_photos WHERE identifier = ? LIMIT 1',
                { identifier }
            )
        end)

        if not ok or not row or type(row.photo_path) ~= 'string' then
            callback(nil, nil)
            return
        end

        -- Never trust a path read from the database.
        local expectedPath = ('photos/%s.jpg'):format(identifier)
        if row.photo_path ~= expectedPath then
            Log(('Rejected unexpected photo path for identifier %s.'):format(identifier))
            callback(nil, nil)
            return
        end

        local imageBytes = LoadResourceFile(RESOURCE_NAME, expectedPath)
        if not imageBytes or #imageBytes == 0 then
            callback(nil, nil)
            return
        end

        callback('data:image/jpeg;base64,' .. EncodeBase64(imageBytes), expectedPath)
    end)
end

-- Public server exports for existing ID/document resources.
-- Callback receives (dataUrl, resourceRelativePath); dataUrl is nil if no photo exists.
exports('GetCharacterPhoto', function(identifier, callback)
    if type(callback) ~= 'function' then return end
    LoadPhotoData(identifier, callback)
end)

exports('GetCharacterPhotoForPlayer', function(playerSource, callback)
    if type(callback) ~= 'function' then return end
    local identifier = GetPlayerIdentifier(tonumber(playerSource))
    if not identifier then
        callback(nil, nil)
        return
    end
    LoadPhotoData(identifier, callback)
end)

RegisterNetEvent('universal_identity:saveCharacterPhoto', function(photoData)
    local src = source
    local now = os.time()
    local cooldown = (Config.Photo and Config.Photo.SaveCooldownSeconds) or 5

    if lastSaveAt[src] and now - lastSaveAt[src] < cooldown then
        NotifySaveResult(src, false, 'Bitte warte kurz, bevor du erneut speicherst.')
        return
    end
    lastSaveAt[src] = now

    if type(photoData) ~= 'string'
        or #photoData > ((Config.Photo and Config.Photo.MaxDataUrlBytes) or 1500000) then
        NotifySaveResult(src, false, 'Die Fotodaten sind ungültig oder zu groß.')
        return
    end

    local base64 = photoData:match('^data:image/jpeg;base64,(.+)$')
        or photoData:match('^data:image/jpg;base64,(.+)$')

    if not base64 then
        NotifySaveResult(src, false, 'Ungültiges Fotoformat. Bitte erneut aufnehmen.')
        return
    end

    local identifier = GetPlayerIdentifier(src)
    if not identifier then
        NotifySaveResult(src, false, 'Charakter-Identifier konnte nicht ermittelt werden.')
        return
    end

    local imageBytes = DecodeBase64(base64)
    local maxImageBytes = (Config.Photo and Config.Photo.MaxImageBytes) or 1100000

    if not imageBytes or #imageBytes < 4 or #imageBytes > maxImageBytes then
        NotifySaveResult(src, false, 'Das Foto ist beschädigt oder zu groß.')
        return
    end

    -- Basic JPEG signature validation.
    if imageBytes:byte(1) ~= 0xFF
        or imageBytes:byte(2) ~= 0xD8
        or imageBytes:byte(-2) ~= 0xFF
        or imageBytes:byte(-1) ~= 0xD9 then
        NotifySaveResult(src, false, 'Die Bilddaten sind kein gültiges JPEG.')
        return
    end

    if not WaitForDatabase() then
        NotifySaveResult(src, false, 'Datenbank ist nicht bereit. Bitte Admin informieren.')
        return
    end

    local photoPath = ('photos/%s.jpg'):format(identifier)
    local writeOk, writeError = pcall(function()
        local written = SaveResourceFile(RESOURCE_NAME, photoPath, imageBytes, #imageBytes)
        if not written then
            error('SaveResourceFile returned false')
        end
    end)

    if not writeOk then
        Log(('Could not write photo for %s: %s'):format(identifier, tostring(writeError)))
        NotifySaveResult(src, false, 'Die Fotodatei konnte nicht gespeichert werden.')
        return
    end

    local verify = LoadResourceFile(RESOURCE_NAME, photoPath)
    if not verify or #verify ~= #imageBytes then
        NotifySaveResult(src, false, 'Die gespeicherte Fotodatei konnte nicht überprüft werden.')
        return
    end
    if UIDPhotoDataUriCache then UIDPhotoDataUriCache[identifier] = nil end

    local dbOk, dbError = pcall(function()
        MySQL.update.await([[
            INSERT INTO ui_character_photos (identifier, photo_path)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE photo_path = VALUES(photo_path)
        ]], { identifier, photoPath })
    end)

    if not dbOk then
        Log(('Could not update photo database for %s: %s'):format(identifier, tostring(dbError)))
        NotifySaveResult(src, false, 'Foto gespeichert, aber Datenbankeintrag fehlgeschlagen.')
        return
    end

    Log(('Character photo saved for %s.'):format(identifier))
    if type(CreatePersonalIdentityDocument) == 'function' then
        local created, createError = pcall(CreatePersonalIdentityDocument, identifier)
        if not created then Log(('Could not create personal ID for %s: %s'):format(identifier, tostring(createError))) end
    end
    NotifySaveResult(src, true, photoPath)
end)

RegisterNetEvent('universal_identity:requestSavedPhoto', function()
    local src = source
    local identifier = GetPlayerIdentifier(src)

    if not identifier then
        TriggerClientEvent('universal_identity:savedPhotoLoaded', src, nil)
        return
    end

    LoadPhotoData(identifier, function(dataUrl)
        TriggerClientEvent('universal_identity:savedPhotoLoaded', src, dataUrl)
    end)
end)

AddEventHandler('playerDropped', function()
    lastSaveAt[source] = nil
end)

Log('Photo storage and public exports loaded.')
