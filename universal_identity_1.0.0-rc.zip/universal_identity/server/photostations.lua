
local function Log(message)
    print(('[Universal Photos] %s'):format(message))
end

-- =========================================================
-- BERECHTIGUNGEN
-- =========================================================

local function HasStationAdminPermission(playerId)
    if playerId == 0 then
        return true
    end

    local acePermission = Config.AdminAcePermission
        or 'universal_identity.admin'

    if IsPlayerAceAllowed(playerId, acePermission)
        or IsPlayerAceAllowed(playerId, 'group.admin') then
        return true
    end

    if GetResourceState('qb-core') == 'started' then
        local ok, QBCore = pcall(function()
            return exports['qb-core']:GetCoreObject()
        end)

        if ok and QBCore and QBCore.Functions
            and type(QBCore.Functions.HasPermission) == 'function' then

            for _, permission in ipairs({ 'god', 'admin' }) do
                local checked, allowed = pcall(function()
                    return QBCore.Functions.HasPermission(
                        playerId,
                        permission
                    )
                end)

                if checked and allowed then
                    return true
                end
            end
        end
    end

    return false
end

local function SendResult(playerId, message)
    if playerId == 0 then
        Log(message)
    else
        TriggerClientEvent(
            'universal_identity:stationCommandResult',
            playerId,
            message
        )
    end
end

local function RequirePermission(playerId)
    if HasStationAdminPermission(playerId) then
        return true
    end

    SendResult(
        playerId,
        'Keine Berechtigung: Diese Aktion ist Admins vorbehalten.'
    )

    return false
end

-- =========================================================
-- DATENBANK BEREITSCHAFT
-- =========================================================

local function WaitForDatabase()
    local attempts = 0

    while not PhotoSystemDatabaseReady and attempts < 100 do
        Wait(100)
        attempts = attempts + 1
    end

    return PhotoSystemDatabaseReady == true
end

-- =========================================================
-- FOTOSTATIONEN LADEN
-- =========================================================

local function LoadPhotoStations()
    if not WaitForDatabase() then
        Log('Datenbank nicht bereit; Fotostationen konnten nicht geladen werden.')
        return {}
    end

    local ok, rows = pcall(function()
        return MySQL.query.await([[
            SELECT id, name, x, y, z, heading
            FROM ui_photo_stations
            ORDER BY id ASC
        ]])
    end)

    if not ok then
        Log(('Fehler beim Laden der Fotostationen: %s'):format(
            tostring(rows)
        ))
        return {}
    end

    return rows or {}
end

-- =========================================================
-- ALLE CLIENTS AKTUALISIEREN
-- =========================================================

local function RefreshAllPhotoStations()
    local stations = LoadPhotoStations()

    print(('[Universal Photos DEBUG] Aktualisiere Fotostationen: %s gefunden.'):format(
        #stations
    ))

    TriggerClientEvent(
        'universal_identity:receivePhotoStations',
        -1,
        stations
    )

    Log(('Photo stations refreshed: %s'):format(#stations))
end

-- Wird vom Admin-Tablet nach Erstellen/Löschen ausgelöst, damit
-- Fotostationen sofort auf allen Clients aktualisiert werden.
AddEventHandler('universal_identity:refreshPhotoStationsInternal', function()
    -- Rein internes Server-Event: absichtlich KEIN RegisterNetEvent, damit
    -- Clients keinen Refresh-Spam über ein direktes Server-Event auslösen können.
    RefreshAllPhotoStations()
end)

-- =========================================================
-- FEHLENDER ANFRAGE-HANDLER
-- CLIENT FORDERT FOTOSTATIONEN AN
-- =========================================================

RegisterNetEvent('universal_identity:requestPhotoStations', function()
    local playerId = source

    print(('[Universal Photos DEBUG] Stationsanfrage von Spieler %s'):format(
        tostring(playerId)
    ))

    local stations = LoadPhotoStations()

    print(('[Universal Photos DEBUG] Sende %s Station(en) an Spieler %s'):format(
        #stations,
        tostring(playerId)
    ))

    TriggerClientEvent(
        'universal_identity:receivePhotoStations',
        playerId,
        stations
    )
end)

-- =========================================================
-- FOTOSTATION ERSTELLEN
-- =========================================================

RegisterNetEvent('universal_identity:adminSetPhotoStation', function()
    local playerId = source

    if not RequirePermission(playerId) then
        return
    end

    if not WaitForDatabase() then
        SendResult(playerId, 'Datenbank ist noch nicht bereit.')
        return
    end

    local ped = GetPlayerPed(playerId)

    if not ped or ped == 0 or not DoesEntityExist(ped) then
        SendResult(playerId, 'Spielerposition konnte nicht ermittelt werden.')
        return
    end

    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)

    local ok, stationId = pcall(function()
        return MySQL.insert.await([[
            INSERT INTO ui_photo_stations
                (name, x, y, z, heading)
            VALUES (?, ?, ?, ?, ?)
        ]], {
            'Fotostation',
            coords.x,
            coords.y,
            coords.z,
            heading
        })
    end)

    if not ok or not stationId then
        Log(('Fotostation konnte nicht erstellt werden: %s'):format(
            tostring(stationId)
        ))

        SendResult(
            playerId,
            'Fotostation konnte nicht gespeichert werden.'
        )

        return
    end

    SendResult(
        playerId,
        'Fotostation erstellt.'
    )

    TriggerClientEvent(
        'universal_identity:photoStationCreated',
        playerId,
        stationId
    )

    -- Direkt nach dem Speichern die Liste neu laden und
    -- an alle aktuell verbundenen Clients senden.
    RefreshAllPhotoStations()
end)

-- =========================================================
-- FOTOSTATIONEN AUFLISTEN
-- =========================================================

RegisterNetEvent('universal_identity:adminListPhotoStations', function()
    local playerId = source

    if not RequirePermission(playerId) then
        return
    end

    local stations = LoadPhotoStations()

    if #stations == 0 then
        SendResult(playerId, 'Es sind keine Fotostationen gespeichert.')
        return
    end

    SendResult(
        playerId,
        ('Gespeicherte Fotostationen: %s'):format(#stations)
    )

    for _, station in ipairs(stations) do
        SendResult(
            playerId,
            ('ID %s | %s | X: %.2f | Y: %.2f | Z: %.2f'):format(
                tostring(station.id),
                tostring(station.name or 'Fotostation'),
                tonumber(station.x) or 0.0,
                tonumber(station.y) or 0.0,
                tonumber(station.z) or 0.0
            )
        )
    end
end)

-- =========================================================
-- FOTOSTATION LÖSCHEN
-- =========================================================

RegisterNetEvent('universal_identity:adminDeletePhotoStation', function(stationId)
    local playerId = source

    if not RequirePermission(playerId) then
        return
    end

    stationId = tonumber(stationId)

    if not stationId or stationId < 1 or stationId % 1 ~= 0 then
        SendResult(
            playerId,
            'Ungültige Stations-ID. Verwendung: /deletephotostation ID'
        )
        return
    end

    if not WaitForDatabase() then
        SendResult(playerId, 'Datenbank ist noch nicht bereit.')
        return
    end

    local ok, station = pcall(function()
        return MySQL.single.await(
            'SELECT x, y, z FROM ui_photo_stations WHERE id = ? LIMIT 1',
            { stationId }
        )
    end)

    if not ok then
        Log(('Fehler beim Abrufen der Fotostation: %s'):format(
            tostring(station)
        ))

        SendResult(playerId, 'Datenbankfehler beim Abrufen der Fotostation.')
        return
    end

    if not station then
        SendResult(
            playerId,
            ('Keine Fotostation mit ID %s gefunden.'):format(stationId)
        )
        return
    end

    local ped = GetPlayerPed(playerId)

    if not ped or ped == 0 then
        SendResult(playerId, 'Spielerposition konnte nicht ermittelt werden.')
        return
    end

    local pos = GetEntityCoords(ped)

    local dx = pos.x - (tonumber(station.x) or 0.0)
    local dy = pos.y - (tonumber(station.y) or 0.0)
    local dz = pos.z - (tonumber(station.z) or 0.0)

    local distance = math.sqrt(dx * dx + dy * dy + dz * dz)

    local allowedDistance = tonumber(
        Config.Documents and Config.Documents.DeleteLocationDistance
    ) or 1.5

    if distance > allowedDistance then
        SendResult(
            playerId,
            ('Du musst direkt an der Fotostation stehen (max. %.1f m), um sie zu löschen.'):format(
                allowedDistance
            )
        )
        return
    end

    local deleteOk, affected = pcall(function()
        return MySQL.update.await(
            'DELETE FROM ui_photo_stations WHERE id = ?',
            { stationId }
        )
    end)

    if not deleteOk then
        Log(('Fehler beim Löschen der Fotostation: %s'):format(
            tostring(affected)
        ))

        SendResult(playerId, 'Datenbankfehler beim Löschen der Fotostation.')
        return
    end

    if not affected or affected < 1 then
        SendResult(
            playerId,
            ('Keine Fotostation mit ID %s gefunden.'):format(stationId)
        )
        return
    end

    SendResult(
        playerId,
        ('Fotostation %s wurde gelöscht.'):format(stationId)
    )

    RefreshAllPhotoStations()
end)

Log('Photo station management loaded.')
