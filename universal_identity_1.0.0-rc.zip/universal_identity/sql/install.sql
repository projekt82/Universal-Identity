-- Universal Identity: additive schema. Existing photo tables are preserved.
CREATE TABLE IF NOT EXISTS `ui_character_photos` (
    `identifier` VARCHAR(100) NOT NULL,
    `photo_path` VARCHAR(255) NOT NULL,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `ui_photo_stations` (
    `id` INT NOT NULL AUTO_INCREMENT, `name` VARCHAR(100) NOT NULL DEFAULT 'Fotostation',
    `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL, `heading` DOUBLE NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `ui_universal_documents` (
    `id` INT NOT NULL AUTO_INCREMENT, `document_number` VARCHAR(40) NOT NULL,
    `document_type` VARCHAR(40) NOT NULL, `owner_identifier` VARCHAR(100) NOT NULL,
    `owner_name` VARCHAR(120) NOT NULL, `organisation_key` VARCHAR(60) NULL,
    `rank_label` VARCHAR(100) NULL, `rank_level` INT NULL, `status` VARCHAR(32) NOT NULL DEFAULT 'ready',
    `issued_by` VARCHAR(100) NULL, `issued_by_name` VARCHAR(120) NULL, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `handed_over_at` TIMESTAMP NULL DEFAULT NULL, PRIMARY KEY (`id`),
    UNIQUE KEY `uq_ui_doc_number` (`document_number`), KEY `idx_ui_doc_owner` (`owner_identifier`),
    KEY `idx_ui_doc_type` (`document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `ui_document_audit` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `document_id` INT NULL,
    `document_number` VARCHAR(40) NULL,
    `document_type` VARCHAR(40) NOT NULL,
    `owner_identifier` VARCHAR(100) NOT NULL,
    `owner_name` VARCHAR(120) NOT NULL,
    `action` VARCHAR(40) NOT NULL,
    `actor_identifier` VARCHAR(100) NULL,
    `actor_name` VARCHAR(120) NULL,
    `target_identifier` VARCHAR(100) NULL,
    `target_name` VARCHAR(120) NULL,
    `details` VARCHAR(255) NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_ui_audit_owner` (`owner_identifier`),
    KEY `idx_ui_audit_document` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `ui_document_pickups` (
    `id` INT NOT NULL AUTO_INCREMENT, `name` VARCHAR(100) NOT NULL DEFAULT 'Ausweis-Ausgabe',
    `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL, `heading` DOUBLE NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `ui_org_deputies` (
    `org_key` VARCHAR(60) NOT NULL, `identifier` VARCHAR(100) NOT NULL, `appointed_by` VARCHAR(100) NOT NULL,
    `appointed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`org_key`),
    UNIQUE KEY `uq_ui_org_deputy` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `ui_org_pcs` (
    `id` INT NOT NULL AUTO_INCREMENT, `org_key` VARCHAR(60) NOT NULL,
    `name` VARCHAR(100) NOT NULL DEFAULT 'Organisations-PC', `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL,
    `z` DOUBLE NOT NULL, `heading` DOUBLE NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `idx_ui_org_pc` (`org_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Protokolliert Mitarbeiterkündigungen mit Grund, Verantwortlichem und Zeitstempel.
CREATE TABLE IF NOT EXISTS `ui_org_termination_logs` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `org_key` VARCHAR(60) NOT NULL,
    `employee_identifier` VARCHAR(100) NOT NULL,
    `employee_name` VARCHAR(120) NOT NULL,
    `terminated_by_identifier` VARCHAR(100) NULL,
    `terminated_by_name` VARCHAR(120) NULL,
    `reason` VARCHAR(1000) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`), KEY `idx_ui_term_org` (`org_key`), KEY `idx_ui_term_employee` (`employee_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Migration for existing installations (safe to run repeatedly on MariaDB):
ALTER TABLE `ui_universal_documents` ADD COLUMN IF NOT EXISTS `rank_level` INT NULL;
ALTER TABLE `ui_universal_documents` ADD COLUMN IF NOT EXISTS `is_recruitment` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `ui_org_employment_dates` ADD COLUMN IF NOT EXISTS `employee_name` VARCHAR(120) NOT NULL DEFAULT '';
ALTER TABLE `ui_org_employment_dates` ADD COLUMN IF NOT EXISTS `hired_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;


-- Rangbasierte Berechtigungen für das Admin-Tablet (optional, wird auch automatisch angelegt).
CREATE TABLE IF NOT EXISTS `ui_org_rank_permissions` (
    `org_key` VARCHAR(60) NOT NULL,
    `grade_level` INT NOT NULL,
    `permissions` LONGTEXT NOT NULL,
    `updated_by` VARCHAR(100) NULL,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`org_key`, `grade_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Dauerhafte, vom Admin-Tablet änderbare Systemeinstellungen.
-- INSERT IGNORE bewahrt einen bereits vom Admin gespeicherten Betrag.
CREATE TABLE IF NOT EXISTS `ui_system_settings` (
    `setting_key` VARCHAR(80) NOT NULL,
    `setting_value` VARCHAR(255) NOT NULL,
    `updated_by` VARCHAR(100) NULL,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT IGNORE INTO `ui_system_settings` (`setting_key`, `setting_value`, `updated_by`)
VALUES ('weapon_permit_tablet_fee', '6500', 'system');
